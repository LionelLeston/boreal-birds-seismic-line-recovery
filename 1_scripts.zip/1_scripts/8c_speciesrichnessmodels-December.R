#The purpose of this script is to run mixed-effects models of species 
#richness observed within upland and lowland forest and seismic line 
#point counts, with separate analyses using observations within 50 m, 
#within 100 m, or unlimited distance point counts. 

library(tidyverse)
library(ggplot2)
library(MuMIn)
library(lme4)
library(AICcmodavg)
library(grid)
library(gridExtra)
my.theme <- theme_classic() +
  theme(text=element_text(size=24, family="Arial"),
        axis.text.x=element_text(size=24),
        axis.text.y=element_text(size=24),
        axis.title.x=element_text(margin=margin(24,0,0,0)),
        axis.title.y=element_text(margin=margin(0,24,0,0)),
        axis.line.x=element_line(linetype=1),
        axis.line.y=element_line(linetype=1))



#Uplands
#50-m analysis
counts<-read.csv("0_data/1_processed/point counts/50mJoinEverything_MoreLatLong.csv", header=TRUE)
#convert species counts to 1's and 0's, then calculate species richness just for territorial passerines
countsBin<-counts%>%
  mutate(across(ALFL:YWAR, ~ ifelse(.x>0, 1, 0)))%>%
  mutate(SpeciesRichness=ALFL+AMRE+AMRO+BAWW+BBWA+BCCH+BHVI+
           BLPW+BOCH+BRCR+CAWA+CCSP+CHSP+CMWA+COYE+DEJU+FOSP+
           GCKI+GRAJ+HAFL+HETH+LCSP+LEFL+LISP+MAWA+MOWA+NOWA+
           OCWA+OSFL+OVEN+PAWA+PHVI+RBGR+RBNU+RCKI+REVI+SOSP+
           SWSP+SWTH+TEWA+WAVI+WBNU+WCSP+WETA+WIWA+WIWR+WTSP+
           WWCR+YBFL+YRWA+YWAR)

#This file appears to have the PCA scores and RI values needed for bird models.
vegBird<-read.csv("0_data/1_processed/point counts/vegBirdDataHedwigUsed.csv", header=TRUE)
vegBird$PKEY<-vegBird$pkey
vegBird$pkey<-NULL
vegBirdF<-vegBird%>%
  dplyr::select(PKEY,landtype2,F1all4,F2all4,riall,ritree1,rishrub1,riground1,riwoody1)
  #vegBirdF PKEYs: replace string "HEDW" with string "NWTSLR"
vegBirdF$PKEY<-gsub("HEDW","NWTSLR",vegBirdF$PKEY)
  
setdiff(countsBin$PKEY, vegBirdF$PKEY)#41 PKEYs
setdiff(vegBirdF$PKEY, countsBin$PKEY)#0
  
m2<-merge(countsBin, vegBirdF, by=c("PKEY"), all.x=TRUE)
m2<-m2[m2$landtype2=="Upland",]#just use upland point counts
m2<-m2[!is.na(m2$OBSERVER),]
  
mean(m2$SpeciesRichness)#2.311897
var(m2$SpeciesRichness)#2.873374 Poisson error distribution
m2$Julian.s<-(m2$JULIAN_DAY-mean(m2$JULIAN_DAY))/sd(m2$JULIAN_DAY)
m2$Time.s<-(m2$Time-mean(m2$Time))/sd(m2$Time)
 
m2$Seismic<-as.factor(ifelse(m2$Veg_Plot.Type=="Interior",0,1))
m2$Seismic.n<-ifelse(m2$Veg_Plot.Type=="Interior",0,1)
m2$riall.c<-m2$riall-mean(m2$riall)
m2$riall.q<-m2$riall.c^2
m2$rishrub1.c<-m2$rishrub1-mean(m2$rishrub1)
m2$rishrub1.q<-m2$rishrub1.c^2
m2$ritree1.c<-m2$ritree1-mean(m2$ritree1)
m2$ritree1.q<-m2$ritree1.c^2
m2$riwoody1.c<-m2$riwoody1-mean(m2$riwoody1)
m2$riwoody1.q<-m2$riwoody1.c^2
m2$riground1.c<-m2$riground1-mean(m2$riground1)
m2$riground1.q<-m2$riground1.c^2

if (var(m2$SpeciesRichness,na.rm=TRUE)/mean(m2$SpeciesRichness,na.rm=TRUE)<2) {
    FOREST.50<-glmer(SpeciesRichness~F1all4+F2all4+Julian.s+Time.s + (1|OBSERVER), data=m2, family=poisson)
    summary(FOREST.50)
    
    LINE.50<-glmer(SpeciesRichness~F1all4+F2all4+Seismic+Julian.s+Time.s + (1|OBSERVER), data=m2, family=poisson)
    summary(LINE.50)

    RIALL.Lin.50<-glmer(SpeciesRichness~F1all4+F2all4+Seismic.n+riall+Seismic.n*riall+Julian.s+Time.s + (1|OBSERVER), data=m2, family=poisson)
    summary(RIALL.Lin.50)
    RIALL.Quad.50<-glmer(SpeciesRichness~F1all4+F2all4+Seismic.n+riall.c+riall.q+Seismic.n*riall.c+Seismic.n*riall.q+Julian.s+Time.s + (1|OBSERVER), data=m2, family=poisson)
    summary(RIALL.Quad.50)
    
    RISHRUB.Lin.50<-glmer(SpeciesRichness~F1all4+F2all4+Seismic.n+rishrub1+Seismic.n*rishrub1+Julian.s+Time.s + (1|OBSERVER), data=m2, family=poisson)
    summary(RISHRUB.Lin.50)
    RISHRUB.Quad.50<-glmer(SpeciesRichness~F1all4+F2all4+Seismic.n+rishrub1.c+rishrub1.q+Seismic.n*rishrub1.c+Seismic.n*rishrub1.q+Julian.s+Time.s + (1|OBSERVER), data=m2, family=poisson)
    summary(RISHRUB.Quad.50)
    
    RITREE.Lin.50<-glmer(SpeciesRichness~F1all4+F2all4+Seismic.n+ritree1+Seismic.n*ritree1+Julian.s+Time.s + (1|OBSERVER), data=m2, family=poisson)
    summary(RITREE.Lin.50)
    RITREE.Quad.50<-glmer(SpeciesRichness~F1all4+F2all4+Seismic.n+ritree1.c+ritree1.q+Seismic.n*ritree1.c+Seismic.n*ritree1.q+Julian.s+Time.s + (1|OBSERVER), data=m2, family=poisson)
    summary(RITREE.Quad.50)
    
    RIGROUND.Lin.50<-glmer(SpeciesRichness~F1all4+F2all4+Seismic.n+riground1+Seismic.n*riground1+Julian.s+Time.s + (1|OBSERVER), data=m2, family=poisson)
    summary(RIGROUND.Lin.50)
    RIGROUND.Quad.50<-glmer(SpeciesRichness~F1all4+F2all4+Seismic.n+riground1.c+riground1.q+Seismic.n*riground1.c+Seismic.n*riground1.q+Julian.s+Time.s + (1|OBSERVER), data=m2, family=poisson)
    summary(RIGROUND.Quad.50)
}
  
if (!var(m2$SpeciesRichness,na.rm=TRUE)/mean(m2$SpeciesRichness,na.rm=TRUE)<2) {
    FOREST.50<-glmer.nb(SpeciesRichness~F1all4+F2all4+Julian.s+Time.s + (1|OBSERVER), data=m2)
    summary(FOREST.50)
    
    LINE.50<-glmer.nb(SpeciesRichness~F1all4+F2all4+Seismic+Julian.s+Time.s + (1|OBSERVER), data=m2)
    summary(LINE.50)
    
    RIALL.Lin.50<-glmer.nb(SpeciesRichness~F1all4+F2all4+Seismic.n+riall+Seismic.n*riall+Julian.s+Time.s + (1|OBSERVER), data=m2)
    summary(RIALL.Lin.50)
    RIALL.Quad.50<-glmer.nb(SpeciesRichness~F1all4+F2all4+Seismic.n+riall.c+riall.q+Seismic.n*riall.c+Seismic.n*riall.q+Julian.s+Time.s + (1|OBSERVER), data=m2)
    summary(RIALL.Quad.50)
    
    RISHRUB.Lin.50<-glmer.nb(SpeciesRichness~F1all4+F2all4+Seismic.n+rishrub1+Seismic.n*rishrub1+Julian.s+Time.s + (1|OBSERVER), data=m2)
    summary(RISHRUB.Lin.50)
    RISHRUB.Quad.50<-glmer.nb(SpeciesRichness~F1all4+F2all4+Seismic.n+rishrub1.c+rishrub1.q+Seismic.n*rishrub1.c+Seismic.n*rishrub1.q+Julian.s+Time.s + (1|OBSERVER), data=m2)
    summary(RISHRUB.Quad.50)
    
    RITREE.Lin.50<-glmer.nb(SpeciesRichness~F1all4+F2all4+Seismic.n+ritree1+Seismic.n*ritree1+Julian.s+Time.s + (1|OBSERVER), data=m2)
    summary(RITREE.Lin.50)
    RITREE.Quad.50<-glmer.nb(SpeciesRichness~F1all4+F2all4+Seismic.n+ritree1.c+ritree1.q+Seismic.n*ritree1.c+Seismic.n*ritree1.q+Julian.s+Time.s + (1|OBSERVER), data=m2)
    summary(RITREE.Quad.50)
    
    RIGROUND.Lin.50<-glmer.nb(SpeciesRichness~F1all4+F2all4+Seismic.n+riground1+Seismic.n*riground1+Julian.s+Time.s + (1|OBSERVER), data=m2)
    summary(RIGROUND.Lin.50)
    RIGROUND.Quad.50<-glmer.nb(SpeciesRichness~F1all4+F2all4+Seismic.n+riground1.c+riground1.q+Seismic.n*riground1.c+Seismic.n*riground1.q+Julian.s+Time.s + (1|OBSERVER), data=m2)
    summary(RIGROUND.Quad.50)
    
}

#Get prediction counts from best model when Hedwig is the observer
newdat <- data.frame(F1all4=mean(m2$F1all4, na.rm=TRUE),#older, taller deciduous forest
                       F2all4=mean(m2$F2all4, na.rm=TRUE),#greater canopy cover, dbh, stem density
                       Julian.s=-0.09831949,#June 15
                       Time.s=-1.232137,#5 AM
                       rishrub1=c(-1,-0.9,-0.8,-0.7,-0.6,-0.5,-0.4,-0.3,-0.2,-0.1,0,0),
                       ritree1=c(seq(from=-0.9744162,to=0,by=(0-(-0.9744162))/10),0),
                       riwoody1=c(seq(from=-0.897608,to=0,by=(0-(-0.897608))/10),0),
                       riground1=c(seq(from=-0.6666667,to=0,by=(0-(-0.6666667))/10),0),
                       riall=c(seq(from=-0.7545604,to=0,by=(0-(-0.7545604))/10),0),
                       Seismic.n=c(1,1,1,1,1,1,1,1,1,1,1,0),
                       Seismic=c("1","1","1","1","1","1","1","1","1","1","1","0"))

newdat$riall.c<-newdat$riall-mean(m2$riall)
newdat$riall.q<-newdat$riall.c^2
newdat$rishrub1.c<-newdat$rishrub1-mean(m2$rishrub1)
newdat$rishrub1.q<-newdat$rishrub1.c^2
newdat$riwoody1.c<-newdat$riwoody1-mean(m2$riwoody1)
newdat$riwoody1.q<-newdat$riwoody1.c^2
newdat$ritree1.c<-newdat$ritree1-mean(m2$ritree1)
newdat$ritree1.q<-newdat$ritree1.c^2
newdat$riground1.c<-newdat$riground1-mean(m2$riground1)
newdat$riground1.q<-newdat$riground1.c^2

#Best Model
dd0 <- model.sel(RIALL.Lin.50,RIALL.Quad.50, 
                 RITREE.Lin.50,RITREE.Quad.50, 
                 RISHRUB.Lin.50,RISHRUB.Quad.50, 
                 RIGROUND.Lin.50,RIGROUND.Quad.50, 
                 #RIWOODY.Lin.50,RIWOODY.Quad.50, #dropped
                 FOREST.50, 
                 LINE.50, rank=AIC) 
bestModel<-get.models(dd0, subset = 1)[[1]]
#gets best model in terms of lowest AICc, highest Akaike weight
#bestModel=RITREE.Lin.50
  
fits<-predictSE(bestModel, newdata=newdat, type="link", se.fit=TRUE)
newdat$bestModelFit<-exp(fits$fit)
newdat$bestModelFitLCL<-exp(fits$fit-1.96*fits$se.fit)
newdat$bestModelFitUCL<-exp(fits$fit+1.96*fits$se.fit)

newdat$bestModelFitUCL<-ifelse(newdat$bestModelFitUCL=="Inf",10,newdat$bestModelFitUCL)

#Best Model = RItree linear  
p1a<-ggplot(data=newdat, aes(x=ritree1, y=bestModelFit)) +
    #geom_ribbon(aes(ymin=bestModelFitLCL, ymax=bestModelFitUCL, col=Seismic), alpha=0.2)+
    geom_point(aes(x=ritree1, y=bestModelFit, col=Seismic, shape=Seismic), size=4)+
    geom_line(aes(x=ritree1, y=bestModelFit, col=Seismic))+
    geom_ribbon(aes(ymin=bestModelFitLCL, ymax=bestModelFitUCL, col=Seismic, fill=Seismic), alpha=0.3)+
    labs(x="Recovery Index (Trees)", y="Richness (50)")+ggtitle("Upland")+
    theme_classic(base_family = "serif") +                        #theme_minimal Apply a minimalistic theme with serif font
    theme(plot.title = element_text(size = 24, family = "serif"),
          axis.title = element_text(size = 24, family = "serif"),  # Increase axis title font size and use serif font
          axis.text = element_text(size = 24, family = "serif"),   # Increase axis label font size and use serif font
          legend.position = "none")+
    geom_segment(aes(x = 0, 
                   xend = 0, 
                   y = 1.23, 
                   yend = 2.98), color = "red")
ggsave(p1a, file=paste0("2_outputs/December 2023/species richness models/UplandSpeciesRichnesspred_bestmodel_50m.png"), units="in", width=10, height=8)


#get coefficients from best model for each species/point count size
mydataFrame<-data.frame(summary(bestModel)$coefficients)
mydataFrame$PCradius<-50
mydataFrame$BestModelName<-row.names(dd0)[1]
mydataFrame$Predictor<-row.names(mydataFrame)
mydataFrame$AIC<-AIC(bestModel)
mydataFrame$AICweight<-dd0$weight[1]
mydataFrame$marginalR2<-r.squaredGLMM(bestModel)[2,1]
mydataFrame$condR2<-r.squaredGLMM(bestModel)[2,2]
mydataFrame$LCL<-mydataFrame$Estimate-1.96*mydataFrame$Std..Error
mydataFrame$UCL<-mydataFrame$Estimate+1.96*mydataFrame$Std..Error
#reorder data frame
mydataFrame2<-mydataFrame%>%
    dplyr::select(PCradius,BestModelName,Predictor,Estimate,Std..Error,LCL,UCL,z.value,Pr...z..,AIC,AICweight,marginalR2,condR2)
write.csv(mydataFrame2, file="2_outputs/December 2023/species richness models/UplandSpeciesRichness.50mbestmodelcoefs.csv")
mydataFrame3<-data.frame(dd0)  
write.csv(mydataFrame3, file="2_outputs/December 2023/species richness models/UplandSpeciesRichness.50mbestmodeltable.csv")

#100-m analysis
counts<-read.csv("0_data/1_processed/point counts/100mJoinEverything_MoreLatLong.csv", header=TRUE)
#convert species counts to 1's and 0's, then calculate species richness just for territorial passerines
countsBin<-counts%>%
  mutate(across(ALFL:YWAR, ~ ifelse(.x>0, 1, 0)))%>%
  mutate(SpeciesRichness=ALFL+AMRE+AMRO+BAWW+BBWA+BCCH+BHVI+
           BLPW+BOCH+BRCR+CAWA+CCSP+CHSP+CMWA+COYE+DEJU+FOSP+
           GCKI+GRAJ+HAFL+HETH+LCSP+LEFL+LISP+MAWA+MOWA+NOWA+
           OCWA+OSFL+OVEN+PAWA+PHVI+PIGR+RBGR+RBNU+RCKI+REVI+RUBL+SOSP+
           SWSP+SWTH+TEWA+WAVI+WBNU+WCSP+WETA+WIWA+WIWR+WTSP+
           WWCR+YBFL+YRWA+YWAR)

#This file appears to have the PCA scores and RI values needed for bird models.
vegBird<-read.csv("0_data/1_processed/point counts/vegBirdDataHedwigUsed.csv", header=TRUE)
vegBird$PKEY<-vegBird$pkey
vegBird$pkey<-NULL
vegBirdF<-vegBird%>%
  dplyr::select(PKEY,landtype2,F1all4,F2all4,riall,ritree1,rishrub1,riground1,riwoody1)
#vegBirdF PKEYs: replace string "HEDW" with string "NWTSLR"
vegBirdF$PKEY<-gsub("HEDW","NWTSLR",vegBirdF$PKEY)

setdiff(countsBin$PKEY, vegBirdF$PKEY)#41 PKEYs
setdiff(vegBirdF$PKEY, countsBin$PKEY)#0

m2<-merge(countsBin, vegBirdF, by=c("PKEY"), all.x=TRUE)
m2<-m2[m2$landtype2=="Upland",]#just use upland point counts
m2<-m2[!is.na(m2$OBSERVER),]

mean(m2$SpeciesRichness)#4.954984
var(m2$SpeciesRichness)#7.01087 Poisson error distribution
m2$Julian.s<-(m2$JULIAN_DAY-mean(m2$JULIAN_DAY))/sd(m2$JULIAN_DAY)
m2$Time.s<-(m2$Time-mean(m2$Time))/sd(m2$Time)

m2$Seismic<-as.factor(ifelse(m2$Veg_Plot.Type=="Interior",0,1))
m2$Seismic.n<-ifelse(m2$Veg_Plot.Type=="Interior",0,1)
m2$riall.c<-m2$riall-mean(m2$riall)
m2$riall.q<-m2$riall.c^2
m2$rishrub1.c<-m2$rishrub1-mean(m2$rishrub1)
m2$rishrub1.q<-m2$rishrub1.c^2
m2$ritree1.c<-m2$ritree1-mean(m2$ritree1)
m2$ritree1.q<-m2$ritree1.c^2
m2$riwoody1.c<-m2$riwoody1-mean(m2$riwoody1)
m2$riwoody1.q<-m2$riwoody1.c^2
m2$riground1.c<-m2$riground1-mean(m2$riground1)
m2$riground1.q<-m2$riground1.c^2

if (var(m2$SpeciesRichness,na.rm=TRUE)/mean(m2$SpeciesRichness,na.rm=TRUE)<2) {
  FOREST.100<-glmer(SpeciesRichness~F1all4+F2all4+Julian.s+Time.s + (1|OBSERVER), data=m2, family=poisson)
  summary(FOREST.100)
  
  LINE.100<-glmer(SpeciesRichness~F1all4+F2all4+Seismic+Julian.s+Time.s + (1|OBSERVER), data=m2, family=poisson)
  summary(LINE.100)
  
  RIALL.Lin.100<-glmer(SpeciesRichness~F1all4+F2all4+Seismic.n+riall+Seismic.n*riall+Julian.s+Time.s + (1|OBSERVER), data=m2, family=poisson)
  summary(RIALL.Lin.100)
  RIALL.Quad.100<-glmer(SpeciesRichness~F1all4+F2all4+Seismic.n+riall.c+riall.q+Seismic.n*riall.c+Seismic.n*riall.q+Julian.s+Time.s + (1|OBSERVER), data=m2, family=poisson)
  summary(RIALL.Quad.100)
  
  RISHRUB.Lin.100<-glmer(SpeciesRichness~F1all4+F2all4+Seismic.n+rishrub1+Seismic.n*rishrub1+Julian.s+Time.s + (1|OBSERVER), data=m2, family=poisson)
  summary(RISHRUB.Lin.100)
  RISHRUB.Quad.100<-glmer(SpeciesRichness~F1all4+F2all4+Seismic.n+rishrub1.c+rishrub1.q+Seismic.n*rishrub1.c+Seismic.n*rishrub1.q+Julian.s+Time.s + (1|OBSERVER), data=m2, family=poisson)
  summary(RISHRUB.Quad.100)
  
  RITREE.Lin.100<-glmer(SpeciesRichness~F1all4+F2all4+Seismic.n+ritree1+Seismic.n*ritree1+Julian.s+Time.s + (1|OBSERVER), data=m2, family=poisson)
  summary(RITREE.Lin.100)
  RITREE.Quad.100<-glmer(SpeciesRichness~F1all4+F2all4+Seismic.n+ritree1.c+ritree1.q+Seismic.n*ritree1.c+Seismic.n*ritree1.q+Julian.s+Time.s + (1|OBSERVER), data=m2, family=poisson)
  summary(RITREE.Quad.100)
  
  RIGROUND.Lin.100<-glmer(SpeciesRichness~F1all4+F2all4+Seismic.n+riground1+Seismic.n*riground1+Julian.s+Time.s + (1|OBSERVER), data=m2, family=poisson)
  summary(RIGROUND.Lin.100)
  RIGROUND.Quad.100<-glmer(SpeciesRichness~F1all4+F2all4+Seismic.n+riground1.c+riground1.q+Seismic.n*riground1.c+Seismic.n*riground1.q+Julian.s+Time.s + (1|OBSERVER), data=m2, family=poisson)
  summary(RIGROUND.Quad.100)
}

if (!var(m2$SpeciesRichness,na.rm=TRUE)/mean(m2$SpeciesRichness,na.rm=TRUE)<2) {
  FOREST.100<-glmer.nb(SpeciesRichness~F1all4+F2all4+Julian.s+Time.s + (1|OBSERVER), data=m2)
  summary(FOREST.100)
  
  LINE.100<-glmer.nb(SpeciesRichness~F1all4+F2all4+Seismic+Julian.s+Time.s + (1|OBSERVER), data=m2)
  summary(LINE.100)
  
  RIALL.Lin.100<-glmer.nb(SpeciesRichness~F1all4+F2all4+Seismic.n+riall+Seismic.n*riall+Julian.s+Time.s + (1|OBSERVER), data=m2)
  summary(RIALL.Lin.100)
  RIALL.Quad.100<-glmer.nb(SpeciesRichness~F1all4+F2all4+Seismic.n+riall.c+riall.q+Seismic.n*riall.c+Seismic.n*riall.q+Julian.s+Time.s + (1|OBSERVER), data=m2)
  summary(RIALL.Quad.100)
  
  RISHRUB.Lin.100<-glmer.nb(SpeciesRichness~F1all4+F2all4+Seismic.n+rishrub1+Seismic.n*rishrub1+Julian.s+Time.s + (1|OBSERVER), data=m2)
  summary(RISHRUB.Lin.100)
  RISHRUB.Quad.100<-glmer.nb(SpeciesRichness~F1all4+F2all4+Seismic.n+rishrub1.c+rishrub1.q+Seismic.n*rishrub1.c+Seismic.n*rishrub1.q+Julian.s+Time.s + (1|OBSERVER), data=m2)
  summary(RISHRUB.Quad.100)
  
  RITREE.Lin.100<-glmer.nb(SpeciesRichness~F1all4+F2all4+Seismic.n+ritree1+Seismic.n*ritree1+Julian.s+Time.s + (1|OBSERVER), data=m2)
  summary(RITREE.Lin.100)
  RITREE.Quad.100<-glmer.nb(SpeciesRichness~F1all4+F2all4+Seismic.n+ritree1.c+ritree1.q+Seismic.n*ritree1.c+Seismic.n*ritree1.q+Julian.s+Time.s + (1|OBSERVER), data=m2)
  summary(RITREE.Quad.100)
  
  RIGROUND.Lin.100<-glmer.nb(SpeciesRichness~F1all4+F2all4+Seismic.n+riground1+Seismic.n*riground1+Julian.s+Time.s + (1|OBSERVER), data=m2)
  summary(RIGROUND.Lin.100)
  RIGROUND.Quad.100<-glmer.nb(SpeciesRichness~F1all4+F2all4+Seismic.n+riground1.c+riground1.q+Seismic.n*riground1.c+Seismic.n*riground1.q+Julian.s+Time.s + (1|OBSERVER), data=m2)
  summary(RIGROUND.Quad.100)
  
}

#Get prediction counts from best model when Hedwig is the observer
newdat <- data.frame(F1all4=mean(m2$F1all4, na.rm=TRUE),#older, taller deciduous forest
                     F2all4=mean(m2$F2all4, na.rm=TRUE),#greater canopy cover, dbh, stem density
                     Julian.s=-0.09831949,#June 15
                     Time.s=-1.232137,#5 AM
                     rishrub1=c(-1,-0.9,-0.8,-0.7,-0.6,-0.5,-0.4,-0.3,-0.2,-0.1,0,0),
                     ritree1=c(seq(from=-0.9744162,to=0,by=(0-(-0.9744162))/10),0),
                     riwoody1=c(seq(from=-0.897608,to=0,by=(0-(-0.897608))/10),0),
                     riground1=c(seq(from=-0.6666667,to=0,by=(0-(-0.6666667))/10),0),
                     riall=c(seq(from=-0.7545604,to=0,by=(0-(-0.7545604))/10),0),
                     Seismic.n=c(1,1,1,1,1,1,1,1,1,1,1,0),
                     Seismic=c("1","1","1","1","1","1","1","1","1","1","1","0"))

newdat$riall.c<-newdat$riall-mean(m2$riall)
newdat$riall.q<-newdat$riall.c^2
newdat$rishrub1.c<-newdat$rishrub1-mean(m2$rishrub1)
newdat$rishrub1.q<-newdat$rishrub1.c^2
newdat$riwoody1.c<-newdat$riwoody1-mean(m2$riwoody1)
newdat$riwoody1.q<-newdat$riwoody1.c^2
newdat$ritree1.c<-newdat$ritree1-mean(m2$ritree1)
newdat$ritree1.q<-newdat$ritree1.c^2
newdat$riground1.c<-newdat$riground1-mean(m2$riground1)
newdat$riground1.q<-newdat$riground1.c^2

#Best Model
dd0 <- model.sel(RIALL.Lin.100,RIALL.Quad.100, 
                 RITREE.Lin.100,RITREE.Quad.100, 
                 RISHRUB.Lin.100,RISHRUB.Quad.100, 
                 RIGROUND.Lin.100,RIGROUND.Quad.100, 
                 #RIWOODY.Lin.100,RIWOODY.Quad.100, 
                 FOREST.100, 
                 LINE.100, rank=AIC) 
bestModel<-get.models(dd0, subset = 1)[[1]]
#gets best model in terms of lowest AICc, highest Akaike weight
#bestModel=RITREE.Lin.50

fits<-predictSE(bestModel, newdata=newdat, type="link", se.fit=TRUE)
newdat$bestModelFit<-exp(fits$fit)
newdat$bestModelFitLCL<-exp(fits$fit-1.96*fits$se.fit)
newdat$bestModelFitUCL<-exp(fits$fit+1.96*fits$se.fit)

newdat$bestModelFitUCL<-ifelse(newdat$bestModelFitUCL=="Inf",10,newdat$bestModelFitUCL)

p1b<-ggplot(data=newdat, aes(x=ritree1, y=bestModelFit)) +
  geom_point(aes(x=ritree1, y=bestModelFit, col=Seismic, shape=Seismic), size=4)+
  geom_line(aes(x=ritree1, y=bestModelFit, col=Seismic))+
  geom_ribbon(aes(ymin=bestModelFitLCL, ymax=bestModelFitUCL, col=Seismic, fill=Seismic), alpha=0.3)+
  ylim(0,(1.1*max(newdat$bestModelFitUCL)))+
  labs(x="Recovery Index (Trees)", y="Richness (100)")+
  theme_classic(base_family = "serif") +                        #theme_minimal Apply a minimalistic theme with serif font
  theme(axis.title = element_text(size = 24, family = "serif"),  # Increase axis title font size and use serif font
        axis.text = element_text(size = 24, family = "serif"),   # Increase axis label font size and use serif font
        plot.title = element_blank(),
        legend.position = "none")+
  geom_segment(aes(x = 0, 
                   xend = 0, 
                   y = 3.30, 
                   yend = 5.58), color = "red")

ggsave(p1b, file=paste0("2_outputs/December 2023/species richness models/UplandSpeciesRichnesspred_bestmodel_100m.png"), units="in", width=10, height=8)

#get coefficients from best model for each species/point count size
mydataFrame<-data.frame(summary(bestModel)$coefficients)
mydataFrame$PCradius<-100
mydataFrame$BestModelName<-row.names(dd0)[1]
mydataFrame$Predictor<-row.names(mydataFrame)
mydataFrame$AIC<-AIC(bestModel)
mydataFrame$AICweight<-dd0$weight[1]
mydataFrame$marginalR2<-r.squaredGLMM(bestModel)[2,1]
mydataFrame$condR2<-r.squaredGLMM(bestModel)[2,2]
mydataFrame$LCL<-mydataFrame$Estimate-1.96*mydataFrame$Std..Error
mydataFrame$UCL<-mydataFrame$Estimate+1.96*mydataFrame$Std..Error
#reorder data frame
mydataFrame2<-mydataFrame%>%
  dplyr::select(PCradius,BestModelName,Predictor,Estimate,Std..Error,LCL,UCL,z.value,Pr...z..,AIC,AICweight,marginalR2,condR2)
write.csv(mydataFrame2, file="2_outputs/December 2023/species richness models/UplandSpeciesRichness.100mbestmodelcoefs.csv")
mydataFrame3<-data.frame(dd0)  
write.csv(mydataFrame3, file="2_outputs/December 2023/species richness models/UplandSpeciesRichness.100mbestmodeltable.csv")


#Unlimited distance analysis
counts<-read.csv("0_data/1_processed/point counts/UnlimJoinEverything_MoreLatLong.csv", header=TRUE)
#convert species counts to 1's and 0's, then calculate species richness just for territorial passerines
countsBin<-counts%>%
  mutate(across(ALFL:YWAR, ~ ifelse(.x>0, 1, 0)))%>%
  mutate(SpeciesRichness=ALFL+AMRE+AMRO+BAWW+BBWA+BCCH+BHVI+
           BLPW+BOCH+BRCR+CAWA+CCSP+CHSP+CMWA+COYE+DEJU+EAPH+FOSP+
           GCKI+GRAJ+HAFL+HETH+LCSP+LEFL+LISP+MAWA+MOWA+NOWA+
           OCWA+OSFL+OVEN+PAWA+PHVI+PIGR+PUFI+RBGR+RBNU+RCKI+
           RECR+REVI+RUBL+RWBL+SOSP+SWSP+SWTH+TEWA+VATH+WAVI+
           WBNU+WCSP+WETA+WEWP+WIWA+WIWR+WTSP+
           WWCR+YBFL+YRWA+YWAR)


#This file appears to have the PCA scores and RI values needed for bird models.
vegBird<-read.csv("0_data/1_processed/point counts/vegBirdDataHedwigUsed.csv", header=TRUE)
vegBird$PKEY<-vegBird$pkey
vegBird$pkey<-NULL
vegBirdF<-vegBird%>%
  dplyr::select(PKEY,landtype2,F1all4,F2all4,riall,ritree1,rishrub1,riground1,riwoody1)
#vegBirdF PKEYs: replace string "HEDW" with string "NWTSLR"
vegBirdF$PKEY<-gsub("HEDW","NWTSLR",vegBirdF$PKEY)

setdiff(countsBin$PKEY, vegBirdF$PKEY)#41 PKEYs
setdiff(vegBirdF$PKEY, countsBin$PKEY)#0

m2<-merge(countsBin, vegBirdF, by=c("PKEY"), all.x=TRUE)
m2<-m2[m2$landtype2=="Upland",]#just use upland point counts
m2<-m2[!is.na(m2$OBSERVER),]

mean(m2$SpeciesRichness)#6.009434
var(m2$SpeciesRichness)#7.100857 Poisson error distribution
m2$Julian.s<-(m2$JULIAN_DAY-mean(m2$JULIAN_DAY))/sd(m2$JULIAN_DAY)
m2$Time.s<-(m2$Time-mean(m2$Time))/sd(m2$Time)

m2$Seismic<-as.factor(ifelse(m2$Veg_Plot.Type=="Interior",0,1))
m2$Seismic.n<-ifelse(m2$Veg_Plot.Type=="Interior",0,1)
m2$riall.c<-m2$riall-mean(m2$riall)
m2$riall.q<-m2$riall.c^2
m2$rishrub1.c<-m2$rishrub1-mean(m2$rishrub1)
m2$rishrub1.q<-m2$rishrub1.c^2
m2$ritree1.c<-m2$ritree1-mean(m2$ritree1)
m2$ritree1.q<-m2$ritree1.c^2
m2$riwoody1.c<-m2$riwoody1-mean(m2$riwoody1)
m2$riwoody1.q<-m2$riwoody1.c^2
m2$riground1.c<-m2$riground1-mean(m2$riground1)
m2$riground1.q<-m2$riground1.c^2

if (var(m2$SpeciesRichness,na.rm=TRUE)/mean(m2$SpeciesRichness,na.rm=TRUE)<2) {
  FOREST.UNL<-glmer(SpeciesRichness~F1all4+F2all4+Julian.s+Time.s + (1|OBSERVER), data=m2, family=poisson)
  summary(FOREST.UNL)
  
  LINE.UNL<-glmer(SpeciesRichness~F1all4+F2all4+Seismic+Julian.s+Time.s + (1|OBSERVER), data=m2, family=poisson)
  summary(LINE.UNL)
  
  RIALL.Lin.UNL<-glmer(SpeciesRichness~F1all4+F2all4+Seismic.n+riall+Seismic.n*riall+Julian.s+Time.s + (1|OBSERVER), data=m2, family=poisson)
  summary(RIALL.Lin.UNL)
  RIALL.Quad.UNL<-glmer(SpeciesRichness~F1all4+F2all4+Seismic.n+riall.c+riall.q+Seismic.n*riall.c+Seismic.n*riall.q+Julian.s+Time.s + (1|OBSERVER), data=m2, family=poisson)
  summary(RIALL.Quad.UNL)
  
  RISHRUB.Lin.UNL<-glmer(SpeciesRichness~F1all4+F2all4+Seismic.n+rishrub1+Seismic.n*rishrub1+Julian.s+Time.s + (1|OBSERVER), data=m2, family=poisson)
  summary(RISHRUB.Lin.UNL)
  RISHRUB.Quad.UNL<-glmer(SpeciesRichness~F1all4+F2all4+Seismic.n+rishrub1.c+rishrub1.q+Seismic.n*rishrub1.c+Seismic.n*rishrub1.q+Julian.s+Time.s + (1|OBSERVER), data=m2, family=poisson)
  summary(RISHRUB.Quad.UNL)
  
  RITREE.Lin.UNL<-glmer(SpeciesRichness~F1all4+F2all4+Seismic.n+ritree1+Seismic.n*ritree1+Julian.s+Time.s + (1|OBSERVER), data=m2, family=poisson)
  summary(RITREE.Lin.UNL)
  RITREE.Quad.UNL<-glmer(SpeciesRichness~F1all4+F2all4+Seismic.n+ritree1.c+ritree1.q+Seismic.n*ritree1.c+Seismic.n*ritree1.q+Julian.s+Time.s + (1|OBSERVER), data=m2, family=poisson)
  summary(RITREE.Quad.UNL)
  
  RIGROUND.Lin.UNL<-glmer(SpeciesRichness~F1all4+F2all4+Seismic.n+riground1+Seismic.n*riground1+Julian.s+Time.s + (1|OBSERVER), data=m2, family=poisson)
  summary(RIGROUND.Lin.UNL)
  RIGROUND.Quad.UNL<-glmer(SpeciesRichness~F1all4+F2all4+Seismic.n+riground1.c+riground1.q+Seismic.n*riground1.c+Seismic.n*riground1.q+Julian.s+Time.s + (1|OBSERVER), data=m2, family=poisson)
  summary(RIGROUND.Quad.UNL)
}

if (!var(m2$SpeciesRichness,na.rm=TRUE)/mean(m2$SpeciesRichness,na.rm=TRUE)<2) {
  FOREST.UNL<-glmer.nb(SpeciesRichness~F1all4+F2all4+Julian.s+Time.s + (1|OBSERVER), data=m2)
  summary(FOREST.UNL)
  
  LINE.UNL<-glmer.nb(SpeciesRichness~F1all4+F2all4+Seismic+Julian.s+Time.s + (1|OBSERVER), data=m2)
  summary(LINE.UNL)
  
  RIALL.Lin.UNL<-glmer.nb(SpeciesRichness~F1all4+F2all4+Seismic.n+riall+Seismic.n*riall+Julian.s+Time.s + (1|OBSERVER), data=m2)
  summary(RIALL.Lin.UNL)
  RIALL.Quad.UNL<-glmer.nb(SpeciesRichness~F1all4+F2all4+Seismic.n+riall.c+riall.q+Seismic.n*riall.c+Seismic.n*riall.q+Julian.s+Time.s + (1|OBSERVER), data=m2)
  summary(RIALL.Quad.UNL)
  
  RISHRUB.Lin.UNL<-glmer.nb(SpeciesRichness~F1all4+F2all4+Seismic.n+rishrub1+Seismic.n*rishrub1+Julian.s+Time.s + (1|OBSERVER), data=m2)
  summary(RISHRUB.Lin.UNL)
  RISHRUB.Quad.UNL<-glmer.nb(SpeciesRichness~F1all4+F2all4+Seismic.n+rishrub1.c+rishrub1.q+Seismic.n*rishrub1.c+Seismic.n*rishrub1.q+Julian.s+Time.s + (1|OBSERVER), data=m2)
  summary(RISHRUB.Quad.UNL)
  
  RITREE.Lin.UNL<-glmer.nb(SpeciesRichness~F1all4+F2all4+Seismic.n+ritree1+Seismic.n*ritree1+Julian.s+Time.s + (1|OBSERVER), data=m2)
  summary(RITREE.Lin.UNL)
  RITREE.Quad.UNL<-glmer.nb(SpeciesRichness~F1all4+F2all4+Seismic.n+ritree1.c+ritree1.q+Seismic.n*ritree1.c+Seismic.n*ritree1.q+Julian.s+Time.s + (1|OBSERVER), data=m2)
  summary(RITREE.Quad.UNL)
  
  RIGROUND.Lin.UNL<-glmer.nb(SpeciesRichness~F1all4+F2all4+Seismic.n+riground1+Seismic.n*riground1+Julian.s+Time.s + (1|OBSERVER), data=m2)
  summary(RIGROUND.Lin.UNL)
  RIGROUND.Quad.UNL<-glmer.nb(SpeciesRichness~F1all4+F2all4+Seismic.n+riground1.c+riground1.q+Seismic.n*riground1.c+Seismic.n*riground1.q+Julian.s+Time.s + (1|OBSERVER), data=m2)
  summary(RIGROUND.Quad.UNL)
  
}

#Get prediction counts from best model when Hedwig is the observer
newdat <- data.frame(F1all4=mean(m2$F1all4, na.rm=TRUE),#older, taller deciduous forest
                     F2all4=mean(m2$F2all4, na.rm=TRUE),#greater canopy cover, dbh, stem density
                     Julian.s=-0.09831949,#June 15
                     Time.s=-1.232137,#5 AM
                     rishrub1=c(-1,-0.9,-0.8,-0.7,-0.6,-0.5,-0.4,-0.3,-0.2,-0.1,0,0),
                     ritree1=c(seq(from=-0.9744162,to=0,by=(0-(-0.9744162))/10),0),
                     riwoody1=c(seq(from=-0.897608,to=0,by=(0-(-0.897608))/10),0),
                     riground1=c(seq(from=-0.6666667,to=0,by=(0-(-0.6666667))/10),0),
                     riall=c(seq(from=-0.7545604,to=0,by=(0-(-0.7545604))/10),0),
                     Seismic.n=c(1,1,1,1,1,1,1,1,1,1,1,0),
                     Seismic=c("1","1","1","1","1","1","1","1","1","1","1","0"))

newdat$riall.c<-newdat$riall-mean(m2$riall)
newdat$riall.q<-newdat$riall.c^2
newdat$rishrub1.c<-newdat$rishrub1-mean(m2$rishrub1)
newdat$rishrub1.q<-newdat$rishrub1.c^2
newdat$riwoody1.c<-newdat$riwoody1-mean(m2$riwoody1)
newdat$riwoody1.q<-newdat$riwoody1.c^2
newdat$ritree1.c<-newdat$ritree1-mean(m2$ritree1)
newdat$ritree1.q<-newdat$ritree1.c^2
newdat$riground1.c<-newdat$riground1-mean(m2$riground1)
newdat$riground1.q<-newdat$riground1.c^2

#Best Model
dd0 <- model.sel(RIALL.Lin.UNL,RIALL.Quad.UNL, 
                 RITREE.Lin.UNL,RITREE.Quad.UNL, 
                 RISHRUB.Lin.UNL,RISHRUB.Quad.UNL, 
                 RIGROUND.Lin.UNL,RIGROUND.Quad.UNL, 
                 #RIWOODY.Lin.UNL,RIWOODY.Quad.UNL, 
                 FOREST.UNL, 
                 LINE.UNL, rank=AIC) 
bestModel<-get.models(dd0, subset = 1)[[1]]
secondbestModel<-get.models(dd0, subset = 2)[[1]]
thirdbestModel<-get.models(dd0, subset = 3)[[1]]
#gets best model in terms of lowest AICc, highest Akaike weight
#best Model=RIALL.Quad.50
#second best Model=RITREE.Lin.50
#third best Model=RIALL.Lin.50

fits<-predictSE(bestModel, newdata=newdat, type="link", se.fit=TRUE)
newdat$bestModelFit<-exp(fits$fit)
newdat$bestModelFitLCL<-exp(fits$fit-1.96*fits$se.fit)
newdat$bestModelFitUCL<-exp(fits$fit+1.96*fits$se.fit)

newdat$bestModelFitUCL<-ifelse(newdat$bestModelFitUCL=="Inf",10,newdat$bestModelFitUCL)

p1c<-ggplot(data=newdat, aes(x=riall, y=bestModelFit)) +
  geom_point(aes(x=riall, y=bestModelFit, col=Seismic, shape=Seismic), size=4)+
  geom_line(aes(x=riall, y=bestModelFit, col=Seismic))+
  geom_ribbon(aes(ymin=bestModelFitLCL, ymax=bestModelFitUCL, col=Seismic, fill=Seismic), alpha=0.3)+
  labs(x="Recovery Index (All veg)", y="Richness (Unlim.)")+
  theme_classic(base_family = "serif") +                        #theme_minimal Apply a minimalistic theme with serif font
  theme(axis.title = element_text(size = 24, family = "serif"),  # Increase axis title font size and use serif font
        axis.text = element_text(size = 24, family = "serif"),   # Increase axis label font size and use serif font
        plot.title = element_blank(),
        legend.position = "none")+
  geom_segment(aes(x = 0, 
                   xend = 0, 
                   y = 4.82, 
                   yend = 6.82), color = "red")    
ggsave(p1c, file=paste0("2_outputs/December 2023/species richness models/UplandSpeciesRichnesspred_bestmodel_Unlim.png"), units="in", width=10, height=8)

fits<-predictSE(secondbestModel, newdata=newdat, type="link", se.fit=TRUE)
newdat$bestModelFit<-exp(fits$fit)
newdat$bestModelFitLCL<-exp(fits$fit-1.96*fits$se.fit)
newdat$bestModelFitUCL<-exp(fits$fit+1.96*fits$se.fit)

newdat$bestModelFitUCL<-ifelse(newdat$bestModelFitUCL=="Inf",10,newdat$bestModelFitUCL)

p1d<-ggplot(data=newdat, aes(x=ritree1, y=bestModelFit)) +
  geom_point(aes(x=ritree1, y=bestModelFit, col=Seismic, shape=Seismic))+
  geom_line(aes(x=ritree1, y=bestModelFit, col=Seismic))+
  geom_ribbon(aes(ymin=bestModelFitLCL, ymax=bestModelFitUCL, col=Seismic, fill=Seismic), alpha=0.3)+
  ylim(0,(1.1*max(newdat$bestModelFitUCL)))+
  labs(x="Recovery Index (Trees)", y="Upland Species Richness (Unlim.)")+
  theme_classic(base_family = "serif") +                        #theme_minimal Apply a minimalistic theme with serif font
  theme(axis.title = element_text(size = 24, family = "serif"),  # Increase axis title font size and use serif font
        axis.text = element_text(size = 20, family = "serif"),   # Increase axis label font size and use serif font
        plot.title = element_blank(),
        legend.position = "none")    
ggsave(p1d, file=paste0("2_outputs/December 2023/species richness models/UplandSpeciesRichnesspred_secondbestmodel_Unlim.png"), units="in", width=10, height=8)

fits<-predictSE(thirdbestModel, newdata=newdat, type="link", se.fit=TRUE)
newdat$bestModelFit<-exp(fits$fit)
newdat$bestModelFitLCL<-exp(fits$fit-1.96*fits$se.fit)
newdat$bestModelFitUCL<-exp(fits$fit+1.96*fits$se.fit)

newdat$bestModelFitUCL<-ifelse(newdat$bestModelFitUCL=="Inf",10,newdat$bestModelFitUCL)

p1e<-ggplot(data=newdat, aes(x=riall, y=bestModelFit)) +
  geom_point(aes(x=riall, y=bestModelFit, col=Seismic, shape=Seismic))+
  geom_line(aes(x=riall, y=bestModelFit, col=Seismic))+
  geom_ribbon(aes(ymin=bestModelFitLCL, ymax=bestModelFitUCL, col=Seismic, fill=Seismic), alpha=0.3)+
  ylim(0,(1.1*max(newdat$bestModelFitUCL)))+
  labs(x="Recovery Index (All veg.)", y="Upland Species Richness (Unlim.)")+
  theme_classic(base_family = "serif") +                        #theme_minimal Apply a minimalistic theme with serif font
  theme(axis.title = element_text(size = 24, family = "serif"),  # Increase axis title font size and use serif font
        axis.text = element_text(size = 20, family = "serif"),   # Increase axis label font size and use serif font
        plot.title = element_blank(),
        legend.position = "none")    
ggsave(p1e, file=paste0("2_outputs/December 2023/species richness models/UplandSpeciesRichnesspred_thirdbestmodel_Unlim.png"), units="in", width=10, height=8)

#get coefficients from best model for each species/point count size
mydataFrame<-data.frame(summary(bestModel)$coefficients)
mydataFrame$PCradius<-"Unlim"
mydataFrame$BestModelName<-row.names(dd0)[1]
mydataFrame$Predictor<-row.names(mydataFrame)
mydataFrame$AIC<-AIC(bestModel)
mydataFrame$AICweight<-dd0$weight[1]
mydataFrame$marginalR2<-r.squaredGLMM(bestModel)[2,1]
mydataFrame$condR2<-r.squaredGLMM(bestModel)[2,2]
mydataFrame$LCL<-mydataFrame$Estimate-1.96*mydataFrame$Std..Error
mydataFrame$UCL<-mydataFrame$Estimate+1.96*mydataFrame$Std..Error
#reorder data frame
mydataFrame2<-mydataFrame%>%
  dplyr::select(PCradius,BestModelName,Predictor,Estimate,Std..Error,LCL,UCL,z.value,Pr...z..,AIC,AICweight,marginalR2,condR2)
write.csv(mydataFrame2, file="2_outputs/December 2023/species richness models/UplandSpeciesRichness.UNLbestmodelcoefs.csv")
mydataFrame3<-data.frame(dd0)
write.csv(mydataFrame3, file="2_outputs/December 2023/species richness models/UplandSpeciesRichness.UNLbestmodeltable.csv")


#Lowland Species Richness
#50-m analysis
counts<-read.csv("0_data/1_processed/point counts/50mJoinEverything_MoreLatLong.csv", header=TRUE)
#convert species counts to 1's and 0's, then calculate species richness just for territorial passerines
countsBin<-counts%>%
  mutate(across(ALFL:YWAR, ~ ifelse(.x>0, 1, 0)))%>%
  mutate(SpeciesRichness=ALFL+AMRE+AMRO+BAWW+BBWA+BCCH+BHVI+
           BLPW+BOCH+BRCR+CAWA+CCSP+CHSP+CMWA+COYE+DEJU+FOSP+
           GCKI+GRAJ+HAFL+HETH+LCSP+LEFL+LISP+MAWA+MOWA+NOWA+
           OCWA+OSFL+OVEN+PAWA+PHVI+RBGR+RBNU+RCKI+REVI+SOSP+
           SWSP+SWTH+TEWA+WAVI+WBNU+WCSP+WETA+WIWA+WIWR+WTSP+
           WWCR+YBFL+YRWA+YWAR)


#This file appears to have the PCA scores and RI values needed for bird models.
vegBird<-read.csv("0_data/1_processed/point counts/vegBirdDataHedwigUsed.csv", header=TRUE)
vegBird$PKEY<-vegBird$pkey
vegBird$pkey<-NULL
vegBirdF<-vegBird%>%
  dplyr::select(PKEY,landtype2,F1all4,F2all4,riall,ritree1,rishrub1,riground1,riwoody1)
#vegBirdF PKEYs: replace string "HEDW" with string "NWTSLR"
vegBirdF$PKEY<-gsub("HEDW","NWTSLR",vegBirdF$PKEY)

setdiff(countsBin$PKEY, vegBirdF$PKEY)#41 PKEYs
setdiff(vegBirdF$PKEY, countsBin$PKEY)#0

m2<-merge(countsBin, vegBirdF, by=c("PKEY"), all.x=TRUE)
m2<-m2[m2$landtype2=="Lowland",]#just use Lowland point counts
m2<-m2[!is.na(m2$OBSERVER),]

mean(m2$SpeciesRichness)#1.764706
var(m2$SpeciesRichness)#2.850654 Poisson error distribution
m2$Julian.s<-(m2$JULIAN_DAY-mean(m2$JULIAN_DAY))/sd(m2$JULIAN_DAY)
m2$Time.s<-(m2$Time-mean(m2$Time))/sd(m2$Time)


m2$Seismic<-as.factor(ifelse(m2$Veg_Plot.Type=="Interior",0,1))
m2$Seismic.n<-ifelse(m2$Veg_Plot.Type=="Interior",0,1)
m2$riall.c<-m2$riall-mean(m2$riall)
m2$riall.q<-m2$riall.c^2
m2$rishrub1.c<-m2$rishrub1-mean(m2$rishrub1)
m2$rishrub1.q<-m2$rishrub1.c^2
m2$ritree1.c<-m2$ritree1-mean(m2$ritree1)
m2$ritree1.q<-m2$ritree1.c^2
m2$riwoody1.c<-m2$riwoody1-mean(m2$riwoody1)
m2$riwoody1.q<-m2$riwoody1.c^2
m2$riground1.c<-m2$riground1-mean(m2$riground1)
m2$riground1.q<-m2$riground1.c^2

if (var(m2$SpeciesRichness,na.rm=TRUE)/mean(m2$SpeciesRichness,na.rm=TRUE)<2) {
  FOREST.50<-glmer(SpeciesRichness~F1all4+F2all4+Julian.s+Time.s + (1|OBSERVER), data=m2, family=poisson)
  summary(FOREST.50)
  
  LINE.50<-glmer(SpeciesRichness~F1all4+F2all4+Seismic+Julian.s+Time.s + (1|OBSERVER), data=m2, family=poisson)
  summary(LINE.50)
  
  RIALL.Lin.50<-glmer(SpeciesRichness~F1all4+F2all4+Seismic.n+riall+Seismic.n*riall+Julian.s+Time.s + (1|OBSERVER), data=m2, family=poisson)
  summary(RIALL.Lin.50)
  RIALL.Quad.50<-glmer(SpeciesRichness~F1all4+F2all4+Seismic.n+riall.c+riall.q+Seismic.n*riall.c+Seismic.n*riall.q+Julian.s+Time.s + (1|OBSERVER), data=m2, family=poisson)
  summary(RIALL.Quad.50)
  
  RISHRUB.Lin.50<-glmer(SpeciesRichness~F1all4+F2all4+Seismic.n+rishrub1+Seismic.n*rishrub1+Julian.s+Time.s + (1|OBSERVER), data=m2, family=poisson)
  summary(RISHRUB.Lin.50)
  RISHRUB.Quad.50<-glmer(SpeciesRichness~F1all4+F2all4+Seismic.n+rishrub1.c+rishrub1.q+Seismic.n*rishrub1.c+Seismic.n*rishrub1.q+Julian.s+Time.s + (1|OBSERVER), data=m2, family=poisson)
  summary(RISHRUB.Quad.50)
  
  RITREE.Lin.50<-glmer(SpeciesRichness~F1all4+F2all4+Seismic.n+ritree1+Seismic.n*ritree1+Julian.s+Time.s + (1|OBSERVER), data=m2, family=poisson)
  summary(RITREE.Lin.50)
  RITREE.Quad.50<-glmer(SpeciesRichness~F1all4+F2all4+Seismic.n+ritree1.c+ritree1.q+Seismic.n*ritree1.c+Seismic.n*ritree1.q+Julian.s+Time.s + (1|OBSERVER), data=m2, family=poisson)
  summary(RITREE.Quad.50)
  
  RIGROUND.Lin.50<-glmer(SpeciesRichness~F1all4+F2all4+Seismic.n+riground1+Seismic.n*riground1+Julian.s+Time.s + (1|OBSERVER), data=m2, family=poisson)
  summary(RIGROUND.Lin.50)
  RIGROUND.Quad.50<-glmer(SpeciesRichness~F1all4+F2all4+Seismic.n+riground1.c+riground1.q+Seismic.n*riground1.c+Seismic.n*riground1.q+Julian.s+Time.s + (1|OBSERVER), data=m2, family=poisson)
  summary(RIGROUND.Quad.50)
}

if (!var(m2$SpeciesRichness,na.rm=TRUE)/mean(m2$SpeciesRichness,na.rm=TRUE)<2) {
  FOREST.50<-glmer.nb(SpeciesRichness~F1all4+F2all4+Julian.s+Time.s + (1|OBSERVER), data=m2)
  summary(FOREST.50)
  
  LINE.50<-glmer.nb(SpeciesRichness~F1all4+F2all4+Seismic+Julian.s+Time.s + (1|OBSERVER), data=m2)
  summary(LINE.50)
  
  RIALL.Lin.50<-glmer.nb(SpeciesRichness~F1all4+F2all4+Seismic.n+riall+Seismic.n*riall+Julian.s+Time.s + (1|OBSERVER), data=m2)
  summary(RIALL.Lin.50)
  RIALL.Quad.50<-glmer.nb(SpeciesRichness~F1all4+F2all4+Seismic.n+riall.c+riall.q+Seismic.n*riall.c+Seismic.n*riall.q+Julian.s+Time.s + (1|OBSERVER), data=m2)
  summary(RIALL.Quad.50)
  
  RISHRUB.Lin.50<-glmer.nb(SpeciesRichness~F1all4+F2all4+Seismic.n+rishrub1+Seismic.n*rishrub1+Julian.s+Time.s + (1|OBSERVER), data=m2)
  summary(RISHRUB.Lin.50)
  RISHRUB.Quad.50<-glmer.nb(SpeciesRichness~F1all4+F2all4+Seismic.n+rishrub1.c+rishrub1.q+Seismic.n*rishrub1.c+Seismic.n*rishrub1.q+Julian.s+Time.s + (1|OBSERVER), data=m2)
  summary(RISHRUB.Quad.50)
  
  RITREE.Lin.50<-glmer.nb(SpeciesRichness~F1all4+F2all4+Seismic.n+ritree1+Seismic.n*ritree1+Julian.s+Time.s + (1|OBSERVER), data=m2)
  summary(RITREE.Lin.50)
  RITREE.Quad.50<-glmer.nb(SpeciesRichness~F1all4+F2all4+Seismic.n+ritree1.c+ritree1.q+Seismic.n*ritree1.c+Seismic.n*ritree1.q+Julian.s+Time.s + (1|OBSERVER), data=m2)
  summary(RITREE.Quad.50)
  
  RIGROUND.Lin.50<-glmer.nb(SpeciesRichness~F1all4+F2all4+Seismic.n+riground1+Seismic.n*riground1+Julian.s+Time.s + (1|OBSERVER), data=m2)
  summary(RIGROUND.Lin.50)
  RIGROUND.Quad.50<-glmer.nb(SpeciesRichness~F1all4+F2all4+Seismic.n+riground1.c+riground1.q+Seismic.n*riground1.c+Seismic.n*riground1.q+Julian.s+Time.s + (1|OBSERVER), data=m2)
  summary(RIGROUND.Quad.50)
  
}

#Get prediction counts from best model when Hedwig is the observer
newdat <- data.frame(F1all4=mean(m2$F1all4, na.rm=TRUE),#older, taller deciduous forest
                     F2all4=mean(m2$F2all4, na.rm=TRUE),#greater canopy cover, dbh, stem density
                     Julian.s=-0.09831949,#June 15
                     Time.s=-1.232137,#5 AM
                     rishrub1=c(-1,-0.9,-0.8,-0.7,-0.6,-0.5,-0.4,-0.3,-0.2,-0.1,0,0),
                     ritree1=c(seq(from=-0.9744162,to=0,by=(0-(-0.9744162))/10),0),
                     riwoody1=c(seq(from=-0.897608,to=0,by=(0-(-0.897608))/10),0),
                     riground1=c(seq(from=-0.6666667,to=0,by=(0-(-0.6666667))/10),0),
                     riall=c(seq(from=-0.7545604,to=0,by=(0-(-0.7545604))/10),0),
                     Seismic.n=c(1,1,1,1,1,1,1,1,1,1,1,0),
                     Seismic=c("1","1","1","1","1","1","1","1","1","1","1","0"))

newdat$riall.c<-newdat$riall-mean(m2$riall)
newdat$riall.q<-newdat$riall.c^2
newdat$rishrub1.c<-newdat$rishrub1-mean(m2$rishrub1)
newdat$rishrub1.q<-newdat$rishrub1.c^2
newdat$riwoody1.c<-newdat$riwoody1-mean(m2$riwoody1)
newdat$riwoody1.q<-newdat$riwoody1.c^2
newdat$ritree1.c<-newdat$ritree1-mean(m2$ritree1)
newdat$ritree1.q<-newdat$ritree1.c^2
newdat$riground1.c<-newdat$riground1-mean(m2$riground1)
newdat$riground1.q<-newdat$riground1.c^2

#Best Model
dd0 <- model.sel(RIALL.Lin.50,RIALL.Quad.50, 
                 RITREE.Lin.50,RITREE.Quad.50, 
                 RISHRUB.Lin.50,RISHRUB.Quad.50, 
                 RIGROUND.Lin.50,RIGROUND.Quad.50, 
                 #RIWOODY.Lin.50,RIWOODY.Quad.50, 
                 FOREST.50, 
                 LINE.50, rank=AIC) 
bestModel<-get.models(dd0, subset = 1)[[1]]
#gets best model in terms of lowest AICc, highest Akaike weight
#best Model=RIGROUND.Lin.50
secondbestModel<-get.models(dd0, subset = 2)[[1]]
#second best Model=LINE.50
thirdbestModel<-get.models(dd0, subset = 3)[[1]]
#third best Model=RIALL.Lin.50

fits<-predictSE(bestModel, newdata=newdat, type="link", se.fit=TRUE)
newdat$bestModelFit<-exp(fits$fit)
newdat$bestModelFitLCL<-exp(fits$fit-1.96*fits$se.fit)
newdat$bestModelFitUCL<-exp(fits$fit+1.96*fits$se.fit)

newdat$bestModelFitUCL<-ifelse(newdat$bestModelFitUCL=="Inf",10,newdat$bestModelFitUCL)

p2a<-ggplot(data=newdat, aes(x=riground1, y=bestModelFit)) +
  geom_point(aes(x=riground1, y=bestModelFit, col=Seismic, shape=Seismic), size=4)+
  geom_line(aes(x=riground1, y=bestModelFit, col=Seismic))+
  geom_ribbon(aes(ymin=bestModelFitLCL, ymax=bestModelFitUCL, col=Seismic, fill=Seismic), alpha=0.3)+
  labs(x="Recovery Index (Ground cover)", y="Richness (50)")+
  theme_classic(base_family = "serif") +                        #theme_minimal Apply a minimalistic theme with serif font
  theme(plot.title = element_text(size = 24, family = "serif"),
        axis.title = element_text(size = 24, family = "serif"),  # Increase axis title font size and use serif font
        axis.text = element_text(size = 24, family = "serif"),   # Increase axis label font size and use serif font
        legend.position = "none")+ggtitle("Lowland")+
  geom_segment(aes(x = 0, 
                   xend = 0, 
                   y = 1.16, 
                   yend = 3.01), color = "red")
ggsave(p2a, file=paste0("2_outputs/December 2023/species richness models/LowlandSpeciesRichnesspred_bestmodel_50m.png"), units="in", width=10, height=8)



#get coefficients from best model for each species/point count size
mydataFrame<-data.frame(summary(bestModel)$coefficients)
mydataFrame$PCradius<-50
mydataFrame$BestModelName<-row.names(dd0)[1]
mydataFrame$Predictor<-row.names(mydataFrame)
mydataFrame$AIC<-AIC(bestModel)
mydataFrame$AICweight<-dd0$weight[1]
mydataFrame$marginalR2<-r.squaredGLMM(bestModel)[2,1]
mydataFrame$condR2<-r.squaredGLMM(bestModel)[2,2]
mydataFrame$LCL<-mydataFrame$Estimate-1.96*mydataFrame$Std..Error
mydataFrame$UCL<-mydataFrame$Estimate+1.96*mydataFrame$Std..Error
#reorder data frame
mydataFrame2<-mydataFrame%>%
  dplyr::select(PCradius,BestModelName,Predictor,Estimate,Std..Error,LCL,UCL,z.value,Pr...z..,AIC,AICweight,marginalR2,condR2)
write.csv(mydataFrame2, file="2_outputs/December 2023/species richness models/LowlandSpeciesRichness.50mbestmodelcoefs.csv")
mydataFrame3<-data.frame(dd0)
write.csv(mydataFrame3, file="2_outputs/December 2023/species richness models/LowlandSpeciesRichness.50mbestmodeltable.csv")


#100-m analysis
counts<-read.csv("0_data/1_processed/point counts/100mJoinEverything_MoreLatLong.csv", header=TRUE)
#convert species counts to 1's and 0's, then calculate species richness just for territorial passerines
countsBin<-counts%>%
  mutate(across(ALFL:YWAR, ~ ifelse(.x>0, 1, 0)))%>%
  mutate(SpeciesRichness=ALFL+AMRE+AMRO+BAWW+BBWA+BCCH+BHVI+
           BLPW+BOCH+BRCR+CAWA+CCSP+CHSP+CMWA+COYE+DEJU+FOSP+
           GCKI+GRAJ+HAFL+HETH+LCSP+LEFL+LISP+MAWA+MOWA+NOWA+
           OCWA+OSFL+OVEN+PAWA+PHVI+PIGR+RBGR+RBNU+RCKI+REVI+RUBL+SOSP+
           SWSP+SWTH+TEWA+WAVI+WBNU+WCSP+WETA+WIWA+WIWR+WTSP+
           WWCR+YBFL+YRWA+YWAR)


#This file appears to have the PCA scores and RI values needed for bird models.
vegBird<-read.csv("0_data/1_processed/point counts/vegBirdDataHedwigUsed.csv", header=TRUE)
vegBird$PKEY<-vegBird$pkey
vegBird$pkey<-NULL
vegBirdF<-vegBird%>%
  dplyr::select(PKEY,landtype2,F1all4,F2all4,riall,ritree1,rishrub1,riground1,riwoody1)
#vegBirdF PKEYs: replace string "HEDW" with string "NWTSLR"
vegBirdF$PKEY<-gsub("HEDW","NWTSLR",vegBirdF$PKEY)

setdiff(countsBin$PKEY, vegBirdF$PKEY)#41 PKEYs
setdiff(vegBirdF$PKEY, countsBin$PKEY)#0

m2<-merge(countsBin, vegBirdF, by=c("PKEY"), all.x=TRUE)
m2<-m2[m2$landtype2=="Lowland",]#just use Lowland point counts
m2<-m2[!is.na(m2$OBSERVER),]

mean(m2$SpeciesRichness)#4.235294
var(m2$SpeciesRichness)#5.756821 Poisson error distribution
m2$Julian.s<-(m2$JULIAN_DAY-mean(m2$JULIAN_DAY))/sd(m2$JULIAN_DAY)
m2$Time.s<-(m2$Time-mean(m2$Time))/sd(m2$Time)

m2$Seismic<-as.factor(ifelse(m2$Veg_Plot.Type=="Interior",0,1))
m2$Seismic.n<-ifelse(m2$Veg_Plot.Type=="Interior",0,1)
m2$riall.c<-m2$riall-mean(m2$riall)
m2$riall.q<-m2$riall.c^2
m2$rishrub1.c<-m2$rishrub1-mean(m2$rishrub1)
m2$rishrub1.q<-m2$rishrub1.c^2
m2$ritree1.c<-m2$ritree1-mean(m2$ritree1)
m2$ritree1.q<-m2$ritree1.c^2
m2$riwoody1.c<-m2$riwoody1-mean(m2$riwoody1)
m2$riwoody1.q<-m2$riwoody1.c^2
m2$riground1.c<-m2$riground1-mean(m2$riground1)
m2$riground1.q<-m2$riground1.c^2

if (var(m2$SpeciesRichness,na.rm=TRUE)/mean(m2$SpeciesRichness,na.rm=TRUE)<2) {
  FOREST.100<-glmer(SpeciesRichness~F1all4+F2all4+Julian.s+Time.s + (1|OBSERVER), data=m2, family=poisson)
  summary(FOREST.100)
  
  LINE.100<-glmer(SpeciesRichness~F1all4+F2all4+Seismic+Julian.s+Time.s + (1|OBSERVER), data=m2, family=poisson)
  summary(LINE.100)
  
  RIALL.Lin.100<-glmer(SpeciesRichness~F1all4+F2all4+Seismic.n+riall+Seismic.n*riall+Julian.s+Time.s + (1|OBSERVER), data=m2, family=poisson)
  summary(RIALL.Lin.100)
  RIALL.Quad.100<-glmer(SpeciesRichness~F1all4+F2all4+Seismic.n+riall.c+riall.q+Seismic.n*riall.c+Seismic.n*riall.q+Julian.s+Time.s + (1|OBSERVER), data=m2, family=poisson)
  summary(RIALL.Quad.100)
  
  RISHRUB.Lin.100<-glmer(SpeciesRichness~F1all4+F2all4+Seismic.n+rishrub1+Seismic.n*rishrub1+Julian.s+Time.s + (1|OBSERVER), data=m2, family=poisson)
  summary(RISHRUB.Lin.100)
  RISHRUB.Quad.100<-glmer(SpeciesRichness~F1all4+F2all4+Seismic.n+rishrub1.c+rishrub1.q+Seismic.n*rishrub1.c+Seismic.n*rishrub1.q+Julian.s+Time.s + (1|OBSERVER), data=m2, family=poisson)
  summary(RISHRUB.Quad.100)
  
  RITREE.Lin.100<-glmer(SpeciesRichness~F1all4+F2all4+Seismic.n+ritree1+Seismic.n*ritree1+Julian.s+Time.s + (1|OBSERVER), data=m2, family=poisson)
  summary(RITREE.Lin.100)
  RITREE.Quad.100<-glmer(SpeciesRichness~F1all4+F2all4+Seismic.n+ritree1.c+ritree1.q+Seismic.n*ritree1.c+Seismic.n*ritree1.q+Julian.s+Time.s + (1|OBSERVER), data=m2, family=poisson)
  summary(RITREE.Quad.100)
  
  RIGROUND.Lin.100<-glmer(SpeciesRichness~F1all4+F2all4+Seismic.n+riground1+Seismic.n*riground1+Julian.s+Time.s + (1|OBSERVER), data=m2, family=poisson)
  summary(RIGROUND.Lin.100)
  RIGROUND.Quad.100<-glmer(SpeciesRichness~F1all4+F2all4+Seismic.n+riground1.c+riground1.q+Seismic.n*riground1.c+Seismic.n*riground1.q+Julian.s+Time.s + (1|OBSERVER), data=m2, family=poisson)
  summary(RIGROUND.Quad.100)
}

if (!var(m2$SpeciesRichness,na.rm=TRUE)/mean(m2$SpeciesRichness,na.rm=TRUE)<2) {
  FOREST.100<-glmer.nb(SpeciesRichness~F1all4+F2all4+Julian.s+Time.s + (1|OBSERVER), data=m2)
  summary(FOREST.100)
  
  LINE.100<-glmer.nb(SpeciesRichness~F1all4+F2all4+Seismic+Julian.s+Time.s + (1|OBSERVER), data=m2)
  summary(LINE.100)
  
  RIALL.Lin.100<-glmer.nb(SpeciesRichness~F1all4+F2all4+Seismic.n+riall+Seismic.n*riall+Julian.s+Time.s + (1|OBSERVER), data=m2)
  summary(RIALL.Lin.100)
  RIALL.Quad.100<-glmer.nb(SpeciesRichness~F1all4+F2all4+Seismic.n+riall.c+riall.q+Seismic.n*riall.c+Seismic.n*riall.q+Julian.s+Time.s + (1|OBSERVER), data=m2)
  summary(RIALL.Quad.100)
  
  RISHRUB.Lin.100<-glmer.nb(SpeciesRichness~F1all4+F2all4+Seismic.n+rishrub1+Seismic.n*rishrub1+Julian.s+Time.s + (1|OBSERVER), data=m2)
  summary(RISHRUB.Lin.100)
  RISHRUB.Quad.100<-glmer.nb(SpeciesRichness~F1all4+F2all4+Seismic.n+rishrub1.c+rishrub1.q+Seismic.n*rishrub1.c+Seismic.n*rishrub1.q+Julian.s+Time.s + (1|OBSERVER), data=m2)
  summary(RISHRUB.Quad.100)
  
  RITREE.Lin.100<-glmer.nb(SpeciesRichness~F1all4+F2all4+Seismic.n+ritree1+Seismic.n*ritree1+Julian.s+Time.s + (1|OBSERVER), data=m2)
  summary(RITREE.Lin.100)
  RITREE.Quad.100<-glmer.nb(SpeciesRichness~F1all4+F2all4+Seismic.n+ritree1.c+ritree1.q+Seismic.n*ritree1.c+Seismic.n*ritree1.q+Julian.s+Time.s + (1|OBSERVER), data=m2)
  summary(RITREE.Quad.100)
  
  RIGROUND.Lin.100<-glmer.nb(SpeciesRichness~F1all4+F2all4+Seismic.n+riground1+Seismic.n*riground1+Julian.s+Time.s + (1|OBSERVER), data=m2)
  summary(RIGROUND.Lin.100)
  RIGROUND.Quad.100<-glmer.nb(SpeciesRichness~F1all4+F2all4+Seismic.n+riground1.c+riground1.q+Seismic.n*riground1.c+Seismic.n*riground1.q+Julian.s+Time.s + (1|OBSERVER), data=m2)
  summary(RIGROUND.Quad.100)
  
}

#Get prediction counts from best model when Hedwig is the observer
newdat <- data.frame(F1all4=mean(m2$F1all4, na.rm=TRUE),#older, taller deciduous forest
                     F2all4=mean(m2$F2all4, na.rm=TRUE),#greater canopy cover, dbh, stem density
                     Julian.s=-0.09831949,#June 15
                     Time.s=-1.232137,#5 AM
                     rishrub1=c(-1,-0.9,-0.8,-0.7,-0.6,-0.5,-0.4,-0.3,-0.2,-0.1,0,0),
                     ritree1=c(seq(from=-0.9744162,to=0,by=(0-(-0.9744162))/10),0),
                     riwoody1=c(seq(from=-0.897608,to=0,by=(0-(-0.897608))/10),0),
                     riground1=c(seq(from=-0.6666667,to=0,by=(0-(-0.6666667))/10),0),
                     riall=c(seq(from=-0.7545604,to=0,by=(0-(-0.7545604))/10),0),
                     Seismic.n=c(1,1,1,1,1,1,1,1,1,1,1,0),
                     Seismic=c("1","1","1","1","1","1","1","1","1","1","1","0"))

newdat$riall.c<-newdat$riall-mean(m2$riall)
newdat$riall.q<-newdat$riall.c^2
newdat$rishrub1.c<-newdat$rishrub1-mean(m2$rishrub1)
newdat$rishrub1.q<-newdat$rishrub1.c^2
newdat$riwoody1.c<-newdat$riwoody1-mean(m2$riwoody1)
newdat$riwoody1.q<-newdat$riwoody1.c^2
newdat$ritree1.c<-newdat$ritree1-mean(m2$ritree1)
newdat$ritree1.q<-newdat$ritree1.c^2
newdat$riground1.c<-newdat$riground1-mean(m2$riground1)
newdat$riground1.q<-newdat$riground1.c^2

#Best Model
dd0 <- model.sel(RIALL.Lin.100,RIALL.Quad.100, 
                 RITREE.Lin.100,RITREE.Quad.100, 
                 RISHRUB.Lin.100,RISHRUB.Quad.100, 
                 RIGROUND.Lin.100,RIGROUND.Quad.100, 
                 #RIWOODY.Lin.100,RIWOODY.Quad.100, 
                 FOREST.100, 
                 LINE.100, rank=AIC) 
bestModel<-get.models(dd0, subset = 1)[[1]]
#gets best model in terms of lowest AICc, highest Akaike weight
#best Model=RIGROUND.Lin.100
secondbestModel<-get.models(dd0, subset = 2)[[1]]
#second best Model=RIGROUND.Quad.100
thirdbestModel<-get.models(dd0, subset = 3)[[1]]
#third best Model=FOREST.100

fits<-predictSE(bestModel, newdata=newdat, type="link", se.fit=TRUE)
newdat$bestModelFit<-exp(fits$fit)
newdat$bestModelFitLCL<-exp(fits$fit-1.96*fits$se.fit)
newdat$bestModelFitUCL<-exp(fits$fit+1.96*fits$se.fit)

newdat$bestModelFitUCL<-ifelse(newdat$bestModelFitUCL=="Inf",10,newdat$bestModelFitUCL)

p2b<-ggplot(data=newdat, aes(x=riground1, y=bestModelFit)) +
  geom_point(aes(x=riground1, y=bestModelFit, col=Seismic, shape=Seismic), size=4)+
  geom_line(aes(x=riground1, y=bestModelFit, col=Seismic))+
  geom_ribbon(aes(ymin=bestModelFitLCL, ymax=bestModelFitUCL, col=Seismic, fill=Seismic), alpha=0.3)+
  ylim(0,(1.1*max(newdat$bestModelFitUCL)))+
  labs(x="Recovery Index (Ground cover)", y="Richness (100)")+
  theme_classic(base_family = "serif") +                        #theme_minimal Apply a minimalistic theme with serif font
  theme(axis.title = element_text(size = 24, family = "serif"),  # Increase axis title font size and use serif font
        axis.text = element_text(size = 24, family = "serif"),   # Increase axis label font size and use serif font
        plot.title = element_blank(),
        legend.position = "none")+
  geom_segment(aes(x = 0, 
                   xend = 0, 
                   y = 3.61, 
                   yend = 6.65), color = "red")
ggsave(p2b, file=paste0("2_outputs/December 2023/species richness models/LowlandSpeciesRichnesspred_bestmodel_100m.png"), units="in", width=10, height=8)

#get coefficients from best model for each species/point count size
mydataFrame<-data.frame(summary(bestModel)$coefficients)
mydataFrame$PCradius<-100
mydataFrame$BestModelName<-row.names(dd0)[1]
mydataFrame$Predictor<-row.names(mydataFrame)
mydataFrame$AIC<-AIC(bestModel)
mydataFrame$AICweight<-dd0$weight[1]
mydataFrame$marginalR2<-r.squaredGLMM(bestModel)[2,1]
mydataFrame$condR2<-r.squaredGLMM(bestModel)[2,2]
mydataFrame$LCL<-mydataFrame$Estimate-1.96*mydataFrame$Std..Error
mydataFrame$UCL<-mydataFrame$Estimate+1.96*mydataFrame$Std..Error
#reorder data frame
mydataFrame2<-mydataFrame%>%
  dplyr::select(PCradius,BestModelName,Predictor,Estimate,Std..Error,LCL,UCL,z.value,Pr...z..,AIC,AICweight,marginalR2,condR2)
write.csv(mydataFrame2, file="2_outputs/December 2023/species richness models/LowlandSpeciesRichness.100mbestmodelcoefs.csv")
mydataFrame3<-data.frame(dd0)
write.csv(mydataFrame3, file="2_outputs/December 2023/species richness models/LowlandSpeciesRichness.100mbestmodeltable.csv")


#Unlimited distance analysis
counts<-read.csv("0_data/1_processed/point counts/UnlimJoinEverything_MoreLatLong.csv", header=TRUE)
#convert species counts to 1's and 0's, then calculate species richness just for territorial passerines
countsBin<-counts%>%
  mutate(across(ALFL:YWAR, ~ ifelse(.x>0, 1, 0)))%>%
  mutate(SpeciesRichness=ALFL+AMRE+AMRO+BAWW+BBWA+BCCH+BHVI+
           BLPW+BOCH+BRCR+CAWA+CCSP+CHSP+CMWA+COYE+DEJU+EAPH+FOSP+
           GCKI+GRAJ+HAFL+HETH+LCSP+LEFL+LISP+MAWA+MOWA+NOWA+
           OCWA+OSFL+OVEN+PAWA+PHVI+PIGR+PUFI+RBGR+RBNU+RCKI+
           RECR+REVI+RUBL+RWBL+SOSP+SWSP+SWTH+TEWA+VATH+WAVI+
           WBNU+WCSP+WETA+WEWP+WIWA+WIWR+WTSP+
           WWCR+YBFL+YRWA+YWAR)


#This file appears to have the PCA scores and RI values needed for bird models.
vegBird<-read.csv("0_data/1_processed/point counts/vegBirdDataHedwigUsed.csv", header=TRUE)
vegBird$PKEY<-vegBird$pkey
vegBird$pkey<-NULL
vegBirdF<-vegBird%>%
  dplyr::select(PKEY,landtype2,F1all4,F2all4,riall,ritree1,rishrub1,riground1,riwoody1)
#vegBirdF PKEYs: replace string "HEDW" with string "NWTSLR"
vegBirdF$PKEY<-gsub("HEDW","NWTSLR",vegBirdF$PKEY)

setdiff(countsBin$PKEY, vegBirdF$PKEY)#41 PKEYs
setdiff(vegBirdF$PKEY, countsBin$PKEY)#0

m2<-merge(countsBin, vegBirdF, by=c("PKEY"), all.x=TRUE)
m2<-m2[m2$landtype2=="Lowland",]#just use Lowland point counts
m2<-m2[!is.na(m2$OBSERVER),]

mean(m2$SpeciesRichness)#6.37
var(m2$SpeciesRichness)#5.86 Poisson error distribution
m2$Julian.s<-(m2$JULIAN_DAY-mean(m2$JULIAN_DAY))/sd(m2$JULIAN_DAY)
m2$Time.s<-(m2$Time-mean(m2$Time))/sd(m2$Time)

m2$Seismic<-as.factor(ifelse(m2$Veg_Plot.Type=="Interior",0,1))
m2$Seismic.n<-ifelse(m2$Veg_Plot.Type=="Interior",0,1)
m2$riall.c<-m2$riall-mean(m2$riall)
m2$riall.q<-m2$riall.c^2
m2$rishrub1.c<-m2$rishrub1-mean(m2$rishrub1)
m2$rishrub1.q<-m2$rishrub1.c^2
m2$ritree1.c<-m2$ritree1-mean(m2$ritree1)
m2$ritree1.q<-m2$ritree1.c^2
m2$riwoody1.c<-m2$riwoody1-mean(m2$riwoody1)
m2$riwoody1.q<-m2$riwoody1.c^2
m2$riground1.c<-m2$riground1-mean(m2$riground1)
m2$riground1.q<-m2$riground1.c^2

if (var(m2$SpeciesRichness,na.rm=TRUE)/mean(m2$SpeciesRichness,na.rm=TRUE)<2) {
  FOREST.UNL<-glmer(SpeciesRichness~F1all4+F2all4+Julian.s+Time.s + (1|OBSERVER), data=m2, family=poisson)
  summary(FOREST.UNL)
  
  LINE.UNL<-glmer(SpeciesRichness~F1all4+F2all4+Seismic+Julian.s+Time.s + (1|OBSERVER), data=m2, family=poisson)
  summary(LINE.UNL)
  
  RIALL.Lin.UNL<-glmer(SpeciesRichness~F1all4+F2all4+Seismic.n+riall+Seismic.n*riall+Julian.s+Time.s + (1|OBSERVER), data=m2, family=poisson)
  summary(RIALL.Lin.UNL)
  RIALL.Quad.UNL<-glmer(SpeciesRichness~F1all4+F2all4+Seismic.n+riall.c+riall.q+Seismic.n*riall.c+Seismic.n*riall.q+Julian.s+Time.s + (1|OBSERVER), data=m2, family=poisson)
  summary(RIALL.Quad.UNL)
  
  RISHRUB.Lin.UNL<-glmer(SpeciesRichness~F1all4+F2all4+Seismic.n+rishrub1+Seismic.n*rishrub1+Julian.s+Time.s + (1|OBSERVER), data=m2, family=poisson)
  summary(RISHRUB.Lin.UNL)
  RISHRUB.Quad.UNL<-glmer(SpeciesRichness~F1all4+F2all4+Seismic.n+rishrub1.c+rishrub1.q+Seismic.n*rishrub1.c+Seismic.n*rishrub1.q+Julian.s+Time.s + (1|OBSERVER), data=m2, family=poisson)
  summary(RISHRUB.Quad.UNL)
  
  RITREE.Lin.UNL<-glmer(SpeciesRichness~F1all4+F2all4+Seismic.n+ritree1+Seismic.n*ritree1+Julian.s+Time.s + (1|OBSERVER), data=m2, family=poisson)
  summary(RITREE.Lin.UNL)
  RITREE.Quad.UNL<-glmer(SpeciesRichness~F1all4+F2all4+Seismic.n+ritree1.c+ritree1.q+Seismic.n*ritree1.c+Seismic.n*ritree1.q+Julian.s+Time.s + (1|OBSERVER), data=m2, family=poisson)
  summary(RITREE.Quad.UNL)
  
  RIGROUND.Lin.UNL<-glmer(SpeciesRichness~F1all4+F2all4+Seismic.n+riground1+Seismic.n*riground1+Julian.s+Time.s + (1|OBSERVER), data=m2, family=poisson)
  summary(RIGROUND.Lin.UNL)
  RIGROUND.Quad.UNL<-glmer(SpeciesRichness~F1all4+F2all4+Seismic.n+riground1.c+riground1.q+Seismic.n*riground1.c+Seismic.n*riground1.q+Julian.s+Time.s + (1|OBSERVER), data=m2, family=poisson)
  summary(RIGROUND.Quad.UNL)
}

if (!var(m2$SpeciesRichness,na.rm=TRUE)/mean(m2$SpeciesRichness,na.rm=TRUE)<2) {
  FOREST.UNL<-glmer.nb(SpeciesRichness~F1all4+F2all4+Julian.s+Time.s + (1|OBSERVER), data=m2)
  summary(FOREST.UNL)
  
  LINE.UNL<-glmer.nb(SpeciesRichness~F1all4+F2all4+Seismic+Julian.s+Time.s + (1|OBSERVER), data=m2)
  summary(LINE.UNL)
  
  RIALL.Lin.UNL<-glmer.nb(SpeciesRichness~F1all4+F2all4+Seismic.n+riall+Seismic.n*riall+Julian.s+Time.s + (1|OBSERVER), data=m2)
  summary(RIALL.Lin.UNL)
  RIALL.Quad.UNL<-glmer.nb(SpeciesRichness~F1all4+F2all4+Seismic.n+riall.c+riall.q+Seismic.n*riall.c+Seismic.n*riall.q+Julian.s+Time.s + (1|OBSERVER), data=m2)
  summary(RIALL.Quad.UNL)
  
  RISHRUB.Lin.UNL<-glmer.nb(SpeciesRichness~F1all4+F2all4+Seismic.n+rishrub1+Seismic.n*rishrub1+Julian.s+Time.s + (1|OBSERVER), data=m2)
  summary(RISHRUB.Lin.UNL)
  RISHRUB.Quad.UNL<-glmer.nb(SpeciesRichness~F1all4+F2all4+Seismic.n+rishrub1.c+rishrub1.q+Seismic.n*rishrub1.c+Seismic.n*rishrub1.q+Julian.s+Time.s + (1|OBSERVER), data=m2)
  summary(RISHRUB.Quad.UNL)
  
  RITREE.Lin.UNL<-glmer.nb(SpeciesRichness~F1all4+F2all4+Seismic.n+ritree1+Seismic.n*ritree1+Julian.s+Time.s + (1|OBSERVER), data=m2)
  summary(RITREE.Lin.UNL)
  RITREE.Quad.UNL<-glmer.nb(SpeciesRichness~F1all4+F2all4+Seismic.n+ritree1.c+ritree1.q+Seismic.n*ritree1.c+Seismic.n*ritree1.q+Julian.s+Time.s + (1|OBSERVER), data=m2)
  summary(RITREE.Quad.UNL)
  
  RIGROUND.Lin.UNL<-glmer.nb(SpeciesRichness~F1all4+F2all4+Seismic.n+riground1+Seismic.n*riground1+Julian.s+Time.s + (1|OBSERVER), data=m2)
  summary(RIGROUND.Lin.UNL)
  RIGROUND.Quad.UNL<-glmer.nb(SpeciesRichness~F1all4+F2all4+Seismic.n+riground1.c+riground1.q+Seismic.n*riground1.c+Seismic.n*riground1.q+Julian.s+Time.s + (1|OBSERVER), data=m2)
  summary(RIGROUND.Quad.UNL)
  
}

#Get prediction counts from best model when Hedwig is the observer
newdat <- data.frame(F1all4=mean(m2$F1all4, na.rm=TRUE),#older, taller deciduous forest
                     F2all4=mean(m2$F2all4, na.rm=TRUE),#greater canopy cover, dbh, stem density
                     Julian.s=-0.09831949,#June 15
                     Time.s=-1.232137,#5 AM
                     rishrub1=c(-1,-0.9,-0.8,-0.7,-0.6,-0.5,-0.4,-0.3,-0.2,-0.1,0,0),
                     ritree1=c(seq(from=-0.9744162,to=0,by=(0-(-0.9744162))/10),0),
                     riwoody1=c(seq(from=-0.897608,to=0,by=(0-(-0.897608))/10),0),
                     riground1=c(seq(from=-0.6666667,to=0,by=(0-(-0.6666667))/10),0),
                     riall=c(seq(from=-0.7545604,to=0,by=(0-(-0.7545604))/10),0),
                     Seismic.n=c(1,1,1,1,1,1,1,1,1,1,1,0),
                     Seismic=c("1","1","1","1","1","1","1","1","1","1","1","0"))

newdat$riall.c<-newdat$riall-mean(m2$riall)
newdat$riall.q<-newdat$riall.c^2
newdat$rishrub1.c<-newdat$rishrub1-mean(m2$rishrub1)
newdat$rishrub1.q<-newdat$rishrub1.c^2
newdat$riwoody1.c<-newdat$riwoody1-mean(m2$riwoody1)
newdat$riwoody1.q<-newdat$riwoody1.c^2
newdat$ritree1.c<-newdat$ritree1-mean(m2$ritree1)
newdat$ritree1.q<-newdat$ritree1.c^2
newdat$riground1.c<-newdat$riground1-mean(m2$riground1)
newdat$riground1.q<-newdat$riground1.c^2

#Best Model
dd0 <- model.sel(RIALL.Lin.UNL,RIALL.Quad.UNL, 
                 RITREE.Lin.UNL,RITREE.Quad.UNL, 
                 RISHRUB.Lin.UNL,RISHRUB.Quad.UNL, 
                 RIGROUND.Lin.UNL,RIGROUND.Quad.UNL, 
                 #RIWOODY.Lin.UNL,RIWOODY.Quad.UNL, 
                 FOREST.UNL, 
                 LINE.UNL, rank=AIC) 
bestModel<-get.models(dd0, subset = 1)[[1]]
#gets best model in terms of lowest AICc, highest Akaike weight
#best Model=RIGROUND.Lin.100
secondbestModel<-get.models(dd0, subset = 2)[[1]]
#second best Model=RIGROUND.Quad.100
thirdbestModel<-get.models(dd0, subset = 3)[[1]]
#third best Model=RIALL.Lin.100

fits<-predictSE(bestModel, newdata=newdat, type="link", se.fit=TRUE)
newdat$bestModelFit<-exp(fits$fit)
newdat$bestModelFitLCL<-exp(fits$fit-1.96*fits$se.fit)
newdat$bestModelFitUCL<-exp(fits$fit+1.96*fits$se.fit)

newdat$bestModelFitUCL<-ifelse(newdat$bestModelFitUCL=="Inf",10,newdat$bestModelFitUCL)

p2c<-ggplot(data=newdat, aes(x=riground1, y=bestModelFit)) +
  geom_point(aes(x=riground1, y=bestModelFit, col=Seismic, shape=Seismic), size=4)+
  geom_line(aes(x=riground1, y=bestModelFit, col=Seismic))+
  geom_ribbon(aes(ymin=bestModelFitLCL, ymax=bestModelFitUCL, col=Seismic, fill=Seismic), alpha=0.3)+
  labs(x="Recovery Index (Ground cover)", y="Richness (Unlim.)")+
  theme_classic(base_family = "serif") +                        #theme_minimal Apply a minimalistic theme with serif font
  theme(axis.title = element_text(size = 24, family = "serif"),  # Increase axis title font size and use serif font
        axis.text = element_text(size = 24, family = "serif"),   # Increase axis label font size and use serif font
        plot.title = element_blank(),
        legend.position = "none")+
  geom_segment(aes(x = 0, 
                   xend = 0, 
                   y = 6.02, 
                   yend = 8.78), color = "red")
ggsave(p2c, file=paste0("2_outputs/December 2023/species richness models/LowlandSpeciesRichnesspred_bestmodel_UNL.png"), units="in", width=10, height=8)


#get coefficients from best model for each species/point count size
mydataFrame<-data.frame(summary(bestModel)$coefficients)
mydataFrame$PCradius<-"Unlim"
mydataFrame$BestModelName<-row.names(dd0)[1]
mydataFrame$Predictor<-row.names(mydataFrame)
mydataFrame$AIC<-AIC(bestModel)
mydataFrame$AICweight<-dd0$weight[1]
mydataFrame$marginalR2<-r.squaredGLMM(bestModel)[2,1]
mydataFrame$condR2<-r.squaredGLMM(bestModel)[2,2]
mydataFrame$LCL<-mydataFrame$Estimate-1.96*mydataFrame$Std..Error
mydataFrame$UCL<-mydataFrame$Estimate+1.96*mydataFrame$Std..Error
#reorder data frame
mydataFrame2<-mydataFrame%>%
  dplyr::select(PCradius,BestModelName,Predictor,Estimate,Std..Error,LCL,UCL,z.value,Pr...z..,AIC,AICweight,marginalR2,condR2)
write.csv(mydataFrame2, file="2_outputs/December 2023/species richness models/LowlandSpeciesRichness.UNLbestmodelcoefs.csv")
mydataFrame3<-data.frame(dd0)
write.csv(mydataFrame3, file="2_outputs/December 2023/species richness models/LowlandSpeciesRichness.UNLbestmodeltable.csv")


mpplot5<-grid.arrange(p1a,p2a,p1b,p2b,p1c,p2c,
                      ncol=2,
                      nrow=3)
ggsave(mpplot5, file="2_outputs/December 2023/species richness models/AllSitesSpeciesRichnesspredsBestModelEachScale.png", units="in", width=20, height=24)
