#prediction plots of species response to seismic line recovery
library(tidyverse)
library(ggplot2)
library(MuMIn)
library(lme4)
library(AICcmodavg)
library(grid)
library(gridExtra)
my.theme <- theme_classic() +
  theme(text=element_text(size=24, family="Arial"),
        axis.text.x=element_text(size=24),
        axis.text.y=element_text(size=24),
        axis.title.x=element_text(margin=margin(24,0,0,0)),
        axis.title.y=element_text(margin=margin(0,24,0,0)),
        axis.line.x=element_line(linetype=1),
        axis.line.y=element_line(linetype=1))


#Generalists
generalists<-c("WTSP")#White-throated Sparrow

for (i in generalists){
  print(paste0("Starting analysis for ",i))
  #Unlimited distance analysis
  counts<-read.csv("0_data/1_processed/point counts/UnlimJoinEverything_MoreLatLong.csv", header=TRUE)
  offsets<-read.csv("0_data/1_processed/point counts/UnlimJoinEverything_OFF.csv", header=TRUE)
  offsets<-offsets %>%
    rename_with(.fn = function(.x){paste0(.x,"off")}) 
  offsets$PKEY<-offsets$Xoff
  offsets$Xoff<-NULL
  
  m1<-merge(counts, offsets, by=c("PKEY"))#, by=c("PKEY")
  vegBird<-read.csv("0_data/1_processed/point counts/vegBirdDataHedwigUsed.csv", header=TRUE)
  vegBird$PKEY<-vegBird$pkey
  vegBird$pkey<-NULL
  vegBirdF<-vegBird%>%
    dplyr::select(PKEY,F1all4,F2all4,riall,ritree1,rishrub1,riground1,riwoody1)
  #vegBirdF PKEYs: replace string "HEDW" with string "NWTSLR"
  vegBirdF$PKEY<-gsub("HEDW","NWTSLR",vegBirdF$PKEY)
  m2<-merge(m1, vegBirdF, by=c("PKEY"), all.x=TRUE)
  m2<-m2[!is.na(m2$OBSERVER),]
  m2$OBSERVER<-as.factor(m2$OBSERVER)  
  
  m2$spp<-m2[,i]
  m2$sppoff<-m2[,paste0(i,"off")]
  mean(m2$spp)
  var(m2$spp)#Poisson error distribution
  m2$Julian.s<-(m2$JULIAN_DAY-mean(m2$JULIAN_DAY))/sd(m2$JULIAN_DAY)
  m2$Time.s<-(m2$Time-mean(m2$Time))/sd(m2$Time)
  
  
  m2$Seismic<-as.factor(ifelse(m2$Veg_Plot.Type=="Interior",0,1))
  m2$Seismic.n<-ifelse(m2$Veg_Plot.Type=="Interior",0,1)
  m2$riall.c<-m2$riall-mean(m2$riall, na.rm=TRUE)
  m2$riall.q<-m2$riall.c^2
  m2$rishrub1.c<-m2$rishrub1-mean(m2$rishrub1, na.rm=TRUE)
  m2$rishrub1.q<-m2$rishrub1.c^2
  m2$ritree1.c<-m2$ritree1-mean(m2$ritree1, na.rm=TRUE)
  m2$ritree1.q<-m2$ritree1.c^2
  m2$riwoody1.c<-m2$riwoody1-mean(m2$riwoody1, na.rm=TRUE)
  m2$riwoody1.q<-m2$riwoody1.c^2
  m2$riground1.c<-m2$riground1-mean(m2$riground1, na.rm=TRUE)
  m2$riground1.q<-m2$riground1.c^2
  
  if (var(m2$spp,na.rm=TRUE)/mean(m2$spp,na.rm=TRUE)<2) {
    FOREST.UNL<-glmer(spp~F1all4+F2all4+Julian.s+Time.s + (1|OBSERVER), data=m2, family=poisson)
    summary(FOREST.UNL)
    
    LINE.UNL<-glmer(spp~F1all4+F2all4+Seismic+Julian.s+Time.s + (1|OBSERVER), data=m2, family=poisson)
    summary(LINE.UNL)
    
    RIALL.Lin.UNL<-glmer(spp~F1all4+F2all4+Seismic.n+riall+Seismic.n*riall+Julian.s+Time.s + (1|OBSERVER), data=m2, family=poisson)
    summary(RIALL.Lin.UNL)

    RISHRUB.Lin.UNL<-glmer(spp~F1all4+F2all4+Seismic.n+rishrub1+Seismic.n*rishrub1+Julian.s+Time.s + (1|OBSERVER), data=m2, family=poisson)
    summary(RISHRUB.Lin.UNL)

    RITREE.Lin.UNL<-glmer(spp~F1all4+F2all4+Seismic.n+ritree1+Seismic.n*ritree1+Julian.s+Time.s + (1|OBSERVER), data=m2, family=poisson)
    summary(RITREE.Lin.UNL)

    RIGROUND.Lin.UNL<-glmer(spp~F1all4+F2all4+Seismic.n+riground1+Seismic.n*riground1+Julian.s+Time.s + (1|OBSERVER), data=m2, family=poisson)
    summary(RIGROUND.Lin.UNL)
  }
  
  if (!var(m2$spp,na.rm=TRUE)/mean(m2$spp,na.rm=TRUE)<2) {
    FOREST.UNL<-glmer.nb(spp~F1all4+F2all4+Julian.s+Time.s + (1|OBSERVER), data=m2)
    summary(FOREST.UNL)
    
    LINE.UNL<-glmer.nb(spp~F1all4+F2all4+Seismic+Julian.s+Time.s + (1|OBSERVER), data=m2)
    summary(LINE.UNL)
    
    RIALL.Lin.UNL<-glmer.nb(spp~F1all4+F2all4+Seismic.n+riall+Seismic.n*riall+Julian.s+Time.s + (1|OBSERVER), data=m2)
    summary(RIALL.Lin.UNL)

    RISHRUB.Lin.UNL<-glmer.nb(spp~F1all4+F2all4+Seismic.n+rishrub1+Seismic.n*rishrub1+Julian.s+Time.s + (1|OBSERVER), data=m2)
    summary(RISHRUB.Lin.UNL)

    RITREE.Lin.UNL<-glmer.nb(spp~F1all4+F2all4+Seismic.n+ritree1+Seismic.n*ritree1+Julian.s+Time.s + (1|OBSERVER), data=m2)
    summary(RITREE.Lin.UNL)

    RIGROUND.Lin.UNL<-glmer.nb(spp~F1all4+F2all4+Seismic.n+riground1+Seismic.n*riground1+Julian.s+Time.s + (1|OBSERVER), data=m2)
    summary(RIGROUND.Lin.UNL)
  }
  
  #Get prediction counts from best model when Hedwig is the observer
  newdat <- data.frame(F1all4=mean(m2$F1all4, na.rm=TRUE),#older, taller deciduous forest
                       F2all4=mean(m2$F2all4, na.rm=TRUE),#greater canopy cover, dbh, stem density
                       Julian.s=-0.09831949,#June 15
                       Time.s=-1.232137,#5 AM
                       rishrub1=c(-1,-0.9,-0.8,-0.7,-0.6,-0.5,-0.4,-0.3,-0.2,-0.1,0,0),
                       ritree1=c(seq(from=-0.9744162,to=0,by=(0-(-0.9744162))/10),0),
                       riwoody1=c(seq(from=-0.897608,to=0,by=(0-(-0.897608))/10),0),
                       riground1=c(seq(from=-0.6666667,to=0,by=(0-(-0.6666667))/10),0),
                       riall=c(seq(from=-0.7545604,to=0,by=(0-(-0.7545604))/10),0),
                       Seismic.n=c(1,1,1,1,1,1,1,1,1,1,1,0),
                       Seismic=c("1","1","1","1","1","1","1","1","1","1","1","0"))
  
  newdat$riall.c<-newdat$riall-mean(m2$riall, na.rm=TRUE)
  newdat$riall.q<-newdat$riall.c^2
  newdat$rishrub1.c<-newdat$rishrub1-mean(m2$rishrub1, na.rm=TRUE)
  newdat$rishrub1.q<-newdat$rishrub1.c^2
  newdat$riwoody1.c<-newdat$riwoody1-mean(m2$riwoody1, na.rm=TRUE)
  newdat$riwoody1.q<-newdat$riwoody1.c^2
  newdat$ritree1.c<-newdat$ritree1-mean(m2$ritree1, na.rm=TRUE)
  newdat$ritree1.q<-newdat$ritree1.c^2
  newdat$riground1.c<-newdat$riground1-mean(m2$riground1, na.rm=TRUE)
  newdat$riground1.q<-newdat$riground1.c^2
  
  #Best Model
  dd0 <- model.sel(RIALL.Lin.UNL, 
                   RITREE.Lin.UNL, 
                   RISHRUB.Lin.UNL, 
                   RIGROUND.Lin.UNL,
                   FOREST.UNL, 
                   LINE.UNL, rank=AIC) 
  bestModel<-get.models(dd0, subset = 1)[[1]]

  fits<-predictSE(bestModel, newdata=newdat, type="link", se.fit=TRUE)
  newdat$bestModelFit<-exp(fits$fit)
  newdat$bestModelFitLCL<-exp(fits$fit-1.96*fits$se.fit)
  newdat$bestModelFitUCL<-exp(fits$fit+1.96*fits$se.fit)
  
  newdat$bestModelFitUCL<-ifelse(newdat$bestModelFitUCL=="Inf",10,newdat$bestModelFitUCL)
  
  newdat[newdat$Seismic=="0",]$bestModelFitLCL
  newdat[newdat$Seismic=="0",]$bestModelFitUCL
  #best model predicting WTSP in unlimited-distance point counts
  p1<-ggplot(data=newdat, aes(x=ritree1, y=bestModelFit)) +
    geom_point(aes(x=ritree1, y=bestModelFit, col=Seismic))+
    geom_line(aes(x=ritree1, y=bestModelFit, col=Seismic))+
    geom_ribbon(aes(ymin=bestModelFitLCL, ymax=bestModelFitUCL, col=Seismic, fill=Seismic), alpha=0.3)+
    labs(x="Recovery Index (Trees)", y=paste0(i," Count"))+
    theme_classic(base_family = "serif") +                        #theme_minimal Apply a minimalistic theme with serif font
    theme(axis.title = element_text(size = 24, family = "serif"),  # Increase axis title font size and use serif font
          axis.text = element_text(size = 20, family = "serif"),   # Increase axis label font size and use serif font
          plot.title = element_blank()) +
    guides(fill="none")+guides(col="none")+
    geom_segment(aes(x = 0, 
                     xend = 0, 
                     y = 0.44, 
                     yend = 0.80), color = "red")
}

generalists<-c("SWTH")#Swainson's Thrush

for (i in generalists){
  print(paste0("Starting analysis for ",i))
  #Unlimited distance analysis
  counts<-read.csv("0_data/1_processed/point counts/UnlimJoinEverything_MoreLatLong.csv", header=TRUE)
  offsets<-read.csv("0_data/1_processed/point counts/UnlimJoinEverything_OFF.csv", header=TRUE)
  offsets<-offsets %>%
    rename_with(.fn = function(.x){paste0(.x,"off")}) 
  offsets$PKEY<-offsets$Xoff
  offsets$Xoff<-NULL
  
  m1<-merge(counts, offsets, by=c("PKEY"))#, by=c("PKEY")
  vegBird<-read.csv("0_data/1_processed/point counts/vegBirdDataHedwigUsed.csv", header=TRUE)
  vegBird$PKEY<-vegBird$pkey
  vegBird$pkey<-NULL
  vegBirdF<-vegBird%>%
    dplyr::select(PKEY,F1all4,F2all4,riall,ritree1,rishrub1,riground1,riwoody1)
  #vegBirdF PKEYs: replace string "HEDW" with string "NWTSLR"
  vegBirdF$PKEY<-gsub("HEDW","NWTSLR",vegBirdF$PKEY)
  m2<-merge(m1, vegBirdF, by=c("PKEY"), all.x=TRUE)
  m2<-m2[!is.na(m2$OBSERVER),]
  m2$OBSERVER<-as.factor(m2$OBSERVER)  
  
  m2$spp<-m2[,i]
  m2$sppoff<-m2[,paste0(i,"off")]
  mean(m2$spp)
  var(m2$spp)#Poisson error distribution
  m2$Julian.s<-(m2$JULIAN_DAY-mean(m2$JULIAN_DAY))/sd(m2$JULIAN_DAY)
  m2$Time.s<-(m2$Time-mean(m2$Time))/sd(m2$Time)
  
  
  m2$Seismic<-as.factor(ifelse(m2$Veg_Plot.Type=="Interior",0,1))
  m2$Seismic.n<-ifelse(m2$Veg_Plot.Type=="Interior",0,1)
  m2$riall.c<-m2$riall-mean(m2$riall, na.rm=TRUE)
  m2$riall.q<-m2$riall.c^2
  m2$rishrub1.c<-m2$rishrub1-mean(m2$rishrub1, na.rm=TRUE)
  m2$rishrub1.q<-m2$rishrub1.c^2
  m2$ritree1.c<-m2$ritree1-mean(m2$ritree1, na.rm=TRUE)
  m2$ritree1.q<-m2$ritree1.c^2
  m2$riwoody1.c<-m2$riwoody1-mean(m2$riwoody1, na.rm=TRUE)
  m2$riwoody1.q<-m2$riwoody1.c^2
  m2$riground1.c<-m2$riground1-mean(m2$riground1, na.rm=TRUE)
  m2$riground1.q<-m2$riground1.c^2
  
  if (var(m2$spp,na.rm=TRUE)/mean(m2$spp,na.rm=TRUE)<2) {
    FOREST.UNL<-glmer(spp~F1all4+F2all4+Julian.s+Time.s + (1|OBSERVER), data=m2, family=poisson)
    summary(FOREST.UNL)
    
    LINE.UNL<-glmer(spp~F1all4+F2all4+Seismic+Julian.s+Time.s + (1|OBSERVER), data=m2, family=poisson)
    summary(LINE.UNL)
    
    RIALL.Lin.UNL<-glmer(spp~F1all4+F2all4+Seismic.n+riall+Seismic.n*riall+Julian.s+Time.s + (1|OBSERVER), data=m2, family=poisson)
    summary(RIALL.Lin.UNL)
    
    RISHRUB.Lin.UNL<-glmer(spp~F1all4+F2all4+Seismic.n+rishrub1+Seismic.n*rishrub1+Julian.s+Time.s + (1|OBSERVER), data=m2, family=poisson)
    summary(RISHRUB.Lin.UNL)
    
    RITREE.Lin.UNL<-glmer(spp~F1all4+F2all4+Seismic.n+ritree1+Seismic.n*ritree1+Julian.s+Time.s + (1|OBSERVER), data=m2, family=poisson)
    summary(RITREE.Lin.UNL)
    
    RIGROUND.Lin.UNL<-glmer(spp~F1all4+F2all4+Seismic.n+riground1+Seismic.n*riground1+Julian.s+Time.s + (1|OBSERVER), data=m2, family=poisson)
    summary(RIGROUND.Lin.UNL)
  }
  
  if (!var(m2$spp,na.rm=TRUE)/mean(m2$spp,na.rm=TRUE)<2) {
    FOREST.UNL<-glmer.nb(spp~F1all4+F2all4+Julian.s+Time.s + (1|OBSERVER), data=m2)
    summary(FOREST.UNL)
    
    LINE.UNL<-glmer.nb(spp~F1all4+F2all4+Seismic+Julian.s+Time.s + (1|OBSERVER), data=m2)
    summary(LINE.UNL)
    
    RIALL.Lin.UNL<-glmer.nb(spp~F1all4+F2all4+Seismic.n+riall+Seismic.n*riall+Julian.s+Time.s + (1|OBSERVER), data=m2)
    summary(RIALL.Lin.UNL)
    
    RISHRUB.Lin.UNL<-glmer.nb(spp~F1all4+F2all4+Seismic.n+rishrub1+Seismic.n*rishrub1+Julian.s+Time.s + (1|OBSERVER), data=m2)
    summary(RISHRUB.Lin.UNL)
    
    RITREE.Lin.UNL<-glmer.nb(spp~F1all4+F2all4+Seismic.n+ritree1+Seismic.n*ritree1+Julian.s+Time.s + (1|OBSERVER), data=m2)
    summary(RITREE.Lin.UNL)
    
    RIGROUND.Lin.UNL<-glmer.nb(spp~F1all4+F2all4+Seismic.n+riground1+Seismic.n*riground1+Julian.s+Time.s + (1|OBSERVER), data=m2)
    summary(RIGROUND.Lin.UNL)
  }
  
  #Get prediction counts from best model when Hedwig is the observer
  newdat <- data.frame(F1all4=mean(m2$F1all4, na.rm=TRUE),#older, taller deciduous forest
                       F2all4=mean(m2$F2all4, na.rm=TRUE),#greater canopy cover, dbh, stem density
                       Julian.s=-0.09831949,#June 15
                       Time.s=-1.232137,#5 AM
                       rishrub1=c(-1,-0.9,-0.8,-0.7,-0.6,-0.5,-0.4,-0.3,-0.2,-0.1,0,0),
                       ritree1=c(seq(from=-0.9744162,to=0,by=(0-(-0.9744162))/10),0),
                       riwoody1=c(seq(from=-0.897608,to=0,by=(0-(-0.897608))/10),0),
                       riground1=c(seq(from=-0.6666667,to=0,by=(0-(-0.6666667))/10),0),
                       riall=c(seq(from=-0.7545604,to=0,by=(0-(-0.7545604))/10),0),
                       Seismic.n=c(1,1,1,1,1,1,1,1,1,1,1,0),
                       Seismic=c("1","1","1","1","1","1","1","1","1","1","1","0"))
  
  newdat$riall.c<-newdat$riall-mean(m2$riall, na.rm=TRUE)
  newdat$riall.q<-newdat$riall.c^2
  newdat$rishrub1.c<-newdat$rishrub1-mean(m2$rishrub1, na.rm=TRUE)
  newdat$rishrub1.q<-newdat$rishrub1.c^2
  newdat$riwoody1.c<-newdat$riwoody1-mean(m2$riwoody1, na.rm=TRUE)
  newdat$riwoody1.q<-newdat$riwoody1.c^2
  newdat$ritree1.c<-newdat$ritree1-mean(m2$ritree1, na.rm=TRUE)
  newdat$ritree1.q<-newdat$ritree1.c^2
  newdat$riground1.c<-newdat$riground1-mean(m2$riground1, na.rm=TRUE)
  newdat$riground1.q<-newdat$riground1.c^2
  
  #Best Model
  dd0 <- model.sel(RIALL.Lin.UNL, 
                   RITREE.Lin.UNL, 
                   RISHRUB.Lin.UNL, 
                   RIGROUND.Lin.UNL,
                   FOREST.UNL, 
                   LINE.UNL, rank=AIC) 
  bestModel<-get.models(dd0, subset = 1)[[1]]

  fits<-predictSE(bestModel, newdata=newdat, type="link", se.fit=TRUE)
  newdat$bestModelFit<-exp(fits$fit)
  newdat$bestModelFitLCL<-exp(fits$fit-1.96*fits$se.fit)
  newdat$bestModelFitUCL<-exp(fits$fit+1.96*fits$se.fit)
  
  newdat$bestModelFitUCL<-ifelse(newdat$bestModelFitUCL=="Inf",10,newdat$bestModelFitUCL)
  
  newdat[newdat$Seismic=="0",]$bestModelFitLCL
  newdat[newdat$Seismic=="0",]$bestModelFitUCL
  #best model predicting SWTH in unlimited-distance point counts
  p4<-ggplot(data=newdat, aes(x=riall, y=bestModelFit)) +
    geom_point(aes(x=riall, y=bestModelFit, col=Seismic))+
    geom_line(aes(x=riall, y=bestModelFit, col=Seismic))+
    geom_ribbon(aes(ymin=bestModelFitLCL, ymax=bestModelFitUCL, col=Seismic, fill=Seismic), alpha=0.3)+
    labs(x="Recovery Index (All vegetation)", y=paste0(i," Count"))+
    theme_classic(base_family = "serif") +                        #theme_minimal Apply a minimalistic theme with serif font
    theme(axis.title = element_text(size = 24, family = "serif"),  # Increase axis title font size and use serif font
          axis.text = element_text(size = 20, family = "serif"),   # Increase axis label font size and use serif font
          plot.title = element_blank()) +
    guides(fill="none")+guides(col="none")+
    geom_segment(aes(x = 0, 
                     xend = 0, 
                     y = 0.68, 
                     yend = 1.48), color = "red")
}

#Upland Species
upland<-c("AMRE")
for (i in upland){
  #Unlimited distance analysis
  counts<-read.csv("0_data/1_processed/point counts/UnlimJoinEverything_MoreLatLong.csv", header=TRUE)
  offsets<-read.csv("0_data/1_processed/point counts/UnlimJoinEverything_OFF.csv", header=TRUE)
  offsets<-offsets %>%
    rename_with(.fn = function(.x){paste0(.x,"off")}) 
  offsets$PKEY<-offsets$Xoff
  offsets$Xoff<-NULL
  
  m1<-merge(counts, offsets, by=c("PKEY"))#, by=c("PKEY")
  vegBird<-read.csv("0_data/1_processed/point counts/vegBirdDataHedwigUsed.csv", header=TRUE)
  vegBird$PKEY<-vegBird$pkey
  vegBird$pkey<-NULL
  vegBirdF<-vegBird%>%
    dplyr::select(PKEY,landtype2,F1all4,F2all4,riall,ritree1,riwoody1,rishrub1,riground1)
  #vegBirdF PKEYs: replace string "HEDW" with string "NWTSLR"
  vegBirdF$PKEY<-gsub("HEDW","NWTSLR",vegBirdF$PKEY)
  m2<-merge(m1, vegBirdF, by=c("PKEY"), all.x=TRUE)
  m2<-m2[m2$landtype2=="Upland",]#just use upland point counts
  m2<-m2[!is.na(m2$OBSERVER),]
  
  m2$spp<-m2[,i]
  m2$sppoff<-m2[,paste0(i,"off")]
  mean(m2$spp)
  var(m2$spp)#Poisson error distribution (except for LEFL)
  m2$Julian.s<-(m2$JULIAN_DAY-mean(m2$JULIAN_DAY))/sd(m2$JULIAN_DAY)
  m2$Time.s<-(m2$Time-mean(m2$Time))/sd(m2$Time)
  
  m2$Seismic<-as.factor(ifelse(m2$Veg_Plot.Type=="Interior",0,1))
  m2$Seismic.n<-ifelse(m2$Veg_Plot.Type=="Interior",0,1)
  m2$riall.c<-m2$riall-mean(m2$riall)
  m2$riall.q<-m2$riall.c^2
  m2$rishrub1.c<-m2$rishrub1-mean(m2$rishrub1)
  m2$rishrub1.q<-m2$rishrub1.c^2
  m2$ritree1.c<-m2$ritree1-mean(m2$ritree1)
  m2$ritree1.q<-m2$ritree1.c^2
  m2$riwoody1.c<-m2$riwoody1-mean(m2$riwoody1)
  m2$riwoody1.q<-m2$riwoody1.c^2
  m2$riground1.c<-m2$riground1-mean(m2$riground1)
  m2$riground1.q<-m2$riground1.c^2
  
  if (var(m2$spp,na.rm=TRUE)/mean(m2$spp,na.rm=TRUE)<2) {
    FOREST.UNL<-glmer(spp~F1all4+F2all4+Julian.s+Time.s + (1|OBSERVER), data=m2, family=poisson)
    summary(FOREST.UNL)
    
    LINE.UNL<-glmer(spp~F1all4+F2all4+Seismic+Julian.s+Time.s + (1|OBSERVER), data=m2, family=poisson)
    summary(LINE.UNL)
    
    RIALL.Lin.UNL<-glmer(spp~F1all4+F2all4+Seismic.n+riall+Seismic.n*riall+Julian.s+Time.s + (1|OBSERVER), data=m2, family=poisson)
    summary(RIALL.Lin.UNL)

    RISHRUB.Lin.UNL<-glmer(spp~F1all4+F2all4+Seismic.n+rishrub1+Seismic.n*rishrub1+Julian.s+Time.s + (1|OBSERVER), data=m2, family=poisson)
    summary(RISHRUB.Lin.UNL)

    RITREE.Lin.UNL<-glmer(spp~F1all4+F2all4+Seismic.n+ritree1+Seismic.n*ritree1+Julian.s+Time.s + (1|OBSERVER), data=m2, family=poisson)
    summary(RITREE.Lin.UNL)

    RIGROUND.Lin.UNL<-glmer(spp~F1all4+F2all4+Seismic.n+riground1+Seismic.n*riground1+Julian.s+Time.s + (1|OBSERVER), data=m2, family=poisson)
    summary(RIGROUND.Lin.UNL)
  }
  
  if (!var(m2$spp,na.rm=TRUE)/mean(m2$spp,na.rm=TRUE)<2) {
    FOREST.UNL<-glmer.nb(spp~F1all4+F2all4+Julian.s+Time.s + (1|OBSERVER), data=m2)
    summary(FOREST.UNL)
    
    LINE.UNL<-glmer.nb(spp~F1all4+F2all4+Seismic+Julian.s+Time.s + (1|OBSERVER), data=m2)
    summary(LINE.UNL)
    
    RIALL.Lin.UNL<-glmer.nb(spp~F1all4+F2all4+Seismic.n+riall+Seismic.n*riall+Julian.s+Time.s + (1|OBSERVER), data=m2)
    summary(RIALL.Lin.UNL)

    RISHRUB.Lin.UNL<-glmer.nb(spp~F1all4+F2all4+Seismic.n+rishrub1+Seismic.n*rishrub1+Julian.s+Time.s + (1|OBSERVER), data=m2)
    summary(RISHRUB.Lin.UNL)

    RITREE.Lin.UNL<-glmer.nb(spp~F1all4+F2all4+Seismic.n+ritree1+Seismic.n*ritree1+Julian.s+Time.s + (1|OBSERVER), data=m2)
    summary(RITREE.Lin.UNL)

    RIGROUND.Lin.UNL<-glmer.nb(spp~F1all4+F2all4+Seismic.n+riground1+Seismic.n*riground1+Julian.s+Time.s + (1|OBSERVER), data=m2)
    summary(RIGROUND.Lin.UNL)
  }
  
  #Get prediction counts from best model when Hedwig is the observer
  newdat <- data.frame(F1all4=mean(m2$F1all4, na.rm=TRUE),#older, taller deciduous forest
                       F2all4=mean(m2$F2all4, na.rm=TRUE),#greater canopy cover, dbh, stem density
                       Julian.s=-0.09831949,#June 15
                       Time.s=-1.232137,#5 AM
                       rishrub1=c(-1,-0.9,-0.8,-0.7,-0.6,-0.5,-0.4,-0.3,-0.2,-0.1,0,0),
                       ritree1=c(seq(from=-0.9744162,to=0,by=(0-(-0.9744162))/10),0),
                       riwoody1=c(seq(from=-0.897608,to=0,by=(0-(-0.897608))/10),0),
                       riground1=c(seq(from=-0.6666667,to=0,by=(0-(-0.6666667))/10),0),
                       riall=c(seq(from=-0.7545604,to=0,by=(0-(-0.7545604))/10),0),
                       Seismic.n=c(1,1,1,1,1,1,1,1,1,1,1,0),
                       Seismic=c("1","1","1","1","1","1","1","1","1","1","1","0"))
  
  newdat$riall.c<-newdat$riall-mean(m2$riall)
  newdat$riall.q<-newdat$riall.c^2
  newdat$rishrub1.c<-newdat$rishrub1-mean(m2$rishrub1)
  newdat$rishrub1.q<-newdat$rishrub1.c^2
  newdat$riwoody1.c<-newdat$riwoody1-mean(m2$riwoody1)
  newdat$riwoody1.q<-newdat$riwoody1.c^2
  newdat$ritree1.c<-newdat$ritree1-mean(m2$ritree1)
  newdat$ritree1.q<-newdat$ritree1.c^2
  newdat$riground1.c<-newdat$riground1-mean(m2$riground1)
  newdat$riground1.q<-newdat$riground1.c^2
  
  #Best Model
  dd0 <- model.sel(RIALL.Lin.UNL, 
                   RITREE.Lin.UNL, 
                   RISHRUB.Lin.UNL, 
                   RIGROUND.Lin.UNL, 
                   FOREST.UNL, 
                   LINE.UNL, rank=AIC) 
  bestModel<-get.models(dd0, subset = 1)[[1]]

  fits<-predictSE(bestModel, newdata=newdat, type="link", se.fit=TRUE)
  newdat$bestModelFit<-exp(fits$fit)
  newdat$bestModelFitLCL<-exp(fits$fit-1.96*fits$se.fit)
  newdat$bestModelFitUCL<-exp(fits$fit+1.96*fits$se.fit)
  
  newdat$bestModelFitUCL<-ifelse(newdat$bestModelFitUCL=="Inf",10,newdat$bestModelFitUCL)
  
  p2<-ggplot(data=newdat, aes(x=rishrub1, y=bestModelFit)) +
    geom_point(aes(x=rishrub1, y=bestModelFit, col=Seismic))+
    geom_line(aes(x=rishrub1, y=bestModelFit, col=Seismic))+
    geom_ribbon(aes(ymin=bestModelFitLCL, ymax=bestModelFitUCL, col=Seismic, fill=Seismic), alpha=0.3)+
    labs(x="Recovery Index (Shrubs)", y=paste0(i," Count"))+
    theme_classic(base_family = "serif") +                        #theme_minimal Apply a minimalistic theme with serif font
    theme(axis.title = element_text(size = 24, family = "serif"),  # Increase axis title font size and use serif font
          axis.text = element_text(size = 20, family = "serif"),   # Increase axis label font size and use serif font
          plot.title = element_blank())+
    guides(fill="none")+guides(col="none")+
    geom_segment(aes(x = 0, 
                     xend = 0, 
                     y = 0.02, 
                     yend = 0.13), color = "red")
  
}

upland<-c("LEFL")
for (i in upland){
  #Unlimited distance analysis
  counts<-read.csv("0_data/1_processed/point counts/UnlimJoinEverything_MoreLatLong.csv", header=TRUE)
  offsets<-read.csv("0_data/1_processed/point counts/UnlimJoinEverything_OFF.csv", header=TRUE)
  offsets<-offsets %>%
    rename_with(.fn = function(.x){paste0(.x,"off")}) 
  offsets$PKEY<-offsets$Xoff
  offsets$Xoff<-NULL
  
  m1<-merge(counts, offsets, by=c("PKEY"))#, by=c("PKEY")
  vegBird<-read.csv("0_data/1_processed/point counts/vegBirdDataHedwigUsed.csv", header=TRUE)
  vegBird$PKEY<-vegBird$pkey
  vegBird$pkey<-NULL
  vegBirdF<-vegBird%>%
    dplyr::select(PKEY,landtype2,F1all4,F2all4,riall,ritree1,riwoody1,rishrub1,riground1)
  #vegBirdF PKEYs: replace string "HEDW" with string "NWTSLR"
  vegBirdF$PKEY<-gsub("HEDW","NWTSLR",vegBirdF$PKEY)
  m2<-merge(m1, vegBirdF, by=c("PKEY"), all.x=TRUE)
  m2<-m2[m2$landtype2=="Upland",]#just use upland point counts
  m2<-m2[!is.na(m2$OBSERVER),]
  
  m2$spp<-m2[,i]
  m2$sppoff<-m2[,paste0(i,"off")]
  mean(m2$spp)
  var(m2$spp)#Poisson error distribution (except for LEFL)
  m2$Julian.s<-(m2$JULIAN_DAY-mean(m2$JULIAN_DAY))/sd(m2$JULIAN_DAY)
  m2$Time.s<-(m2$Time-mean(m2$Time))/sd(m2$Time)
  
  m2$Seismic<-as.factor(ifelse(m2$Veg_Plot.Type=="Interior",0,1))
  m2$Seismic.n<-ifelse(m2$Veg_Plot.Type=="Interior",0,1)
  m2$riall.c<-m2$riall-mean(m2$riall)
  m2$riall.q<-m2$riall.c^2
  m2$rishrub1.c<-m2$rishrub1-mean(m2$rishrub1)
  m2$rishrub1.q<-m2$rishrub1.c^2
  m2$ritree1.c<-m2$ritree1-mean(m2$ritree1)
  m2$ritree1.q<-m2$ritree1.c^2
  m2$riwoody1.c<-m2$riwoody1-mean(m2$riwoody1)
  m2$riwoody1.q<-m2$riwoody1.c^2
  m2$riground1.c<-m2$riground1-mean(m2$riground1)
  m2$riground1.q<-m2$riground1.c^2
  
  if (var(m2$spp,na.rm=TRUE)/mean(m2$spp,na.rm=TRUE)<2) {
    FOREST.UNL<-glmer(spp~F1all4+F2all4+Julian.s+Time.s + (1|OBSERVER), data=m2, family=poisson)
    summary(FOREST.UNL)
    
    LINE.UNL<-glmer(spp~F1all4+F2all4+Seismic+Julian.s+Time.s + (1|OBSERVER), data=m2, family=poisson)
    summary(LINE.UNL)
    
    RIALL.Lin.UNL<-glmer(spp~F1all4+F2all4+Seismic.n+riall+Seismic.n*riall+Julian.s+Time.s + (1|OBSERVER), data=m2, family=poisson)
    summary(RIALL.Lin.UNL)
    
    RISHRUB.Lin.UNL<-glmer(spp~F1all4+F2all4+Seismic.n+rishrub1+Seismic.n*rishrub1+Julian.s+Time.s + (1|OBSERVER), data=m2, family=poisson)
    summary(RISHRUB.Lin.UNL)
    
    RITREE.Lin.UNL<-glmer(spp~F1all4+F2all4+Seismic.n+ritree1+Seismic.n*ritree1+Julian.s+Time.s + (1|OBSERVER), data=m2, family=poisson)
    summary(RITREE.Lin.UNL)
    
    RIGROUND.Lin.UNL<-glmer(spp~F1all4+F2all4+Seismic.n+riground1+Seismic.n*riground1+Julian.s+Time.s + (1|OBSERVER), data=m2, family=poisson)
    summary(RIGROUND.Lin.UNL)
  }
  
  if (!var(m2$spp,na.rm=TRUE)/mean(m2$spp,na.rm=TRUE)<2) {
    FOREST.UNL<-glmer.nb(spp~F1all4+F2all4+Julian.s+Time.s + (1|OBSERVER), data=m2)
    summary(FOREST.UNL)
    
    LINE.UNL<-glmer.nb(spp~F1all4+F2all4+Seismic+Julian.s+Time.s + (1|OBSERVER), data=m2)
    summary(LINE.UNL)
    
    RIALL.Lin.UNL<-glmer.nb(spp~F1all4+F2all4+Seismic.n+riall+Seismic.n*riall+Julian.s+Time.s + (1|OBSERVER), data=m2)
    summary(RIALL.Lin.UNL)
    
    RISHRUB.Lin.UNL<-glmer.nb(spp~F1all4+F2all4+Seismic.n+rishrub1+Seismic.n*rishrub1+Julian.s+Time.s + (1|OBSERVER), data=m2)
    summary(RISHRUB.Lin.UNL)
    
    RITREE.Lin.UNL<-glmer.nb(spp~F1all4+F2all4+Seismic.n+ritree1+Seismic.n*ritree1+Julian.s+Time.s + (1|OBSERVER), data=m2)
    summary(RITREE.Lin.UNL)
    
    RIGROUND.Lin.UNL<-glmer.nb(spp~F1all4+F2all4+Seismic.n+riground1+Seismic.n*riground1+Julian.s+Time.s + (1|OBSERVER), data=m2)
    summary(RIGROUND.Lin.UNL)
  }
  
  #Get prediction counts from best model when Hedwig is the observer
  newdat <- data.frame(F1all4=mean(m2$F1all4, na.rm=TRUE),#older, taller deciduous forest
                       F2all4=mean(m2$F2all4, na.rm=TRUE),#greater canopy cover, dbh, stem density
                       Julian.s=-0.09831949,#June 15
                       Time.s=-1.232137,#5 AM
                       rishrub1=c(-1,-0.9,-0.8,-0.7,-0.6,-0.5,-0.4,-0.3,-0.2,-0.1,0,0),
                       ritree1=c(seq(from=-0.9744162,to=0,by=(0-(-0.9744162))/10),0),
                       riwoody1=c(seq(from=-0.897608,to=0,by=(0-(-0.897608))/10),0),
                       riground1=c(seq(from=-0.6666667,to=0,by=(0-(-0.6666667))/10),0),
                       riall=c(seq(from=-0.7545604,to=0,by=(0-(-0.7545604))/10),0),
                       Seismic.n=c(1,1,1,1,1,1,1,1,1,1,1,0),
                       Seismic=c("1","1","1","1","1","1","1","1","1","1","1","0"))
  
  newdat$riall.c<-newdat$riall-mean(m2$riall)
  newdat$riall.q<-newdat$riall.c^2
  newdat$rishrub1.c<-newdat$rishrub1-mean(m2$rishrub1)
  newdat$rishrub1.q<-newdat$rishrub1.c^2
  newdat$riwoody1.c<-newdat$riwoody1-mean(m2$riwoody1)
  newdat$riwoody1.q<-newdat$riwoody1.c^2
  newdat$ritree1.c<-newdat$ritree1-mean(m2$ritree1)
  newdat$ritree1.q<-newdat$ritree1.c^2
  newdat$riground1.c<-newdat$riground1-mean(m2$riground1)
  newdat$riground1.q<-newdat$riground1.c^2
  
  #Best Model
  dd0 <- model.sel(RIALL.Lin.UNL, 
                   RITREE.Lin.UNL, 
                   RISHRUB.Lin.UNL, 
                   RIGROUND.Lin.UNL, 
                   FOREST.UNL, 
                   LINE.UNL, rank=AIC) 
  bestModel<-get.models(dd0, subset = 1)[[1]]
  
  fits<-predictSE(bestModel, newdata=newdat, type="link", se.fit=TRUE)
  newdat$bestModelFit<-exp(fits$fit)
  newdat$bestModelFitLCL<-exp(fits$fit-1.96*fits$se.fit)
  newdat$bestModelFitUCL<-exp(fits$fit+1.96*fits$se.fit)
  
  newdat$bestModelFitUCL<-ifelse(newdat$bestModelFitUCL=="Inf",10,newdat$bestModelFitUCL)
  
  p5<-ggplot(data=newdat, aes(x=ritree1, y=bestModelFit)) +
    geom_point(aes(x=ritree1, y=bestModelFit, col=Seismic))+
    geom_line(aes(x=ritree1, y=bestModelFit, col=Seismic))+
    geom_ribbon(aes(ymin=bestModelFitLCL, ymax=bestModelFitUCL, col=Seismic, fill=Seismic), alpha=0.3)+
    labs(x="Recovery Index (Tree Cover)", y=paste0(i," Count"))+
    theme_classic(base_family = "serif") +                        #theme_minimal Apply a minimalistic theme with serif font
    theme(axis.title = element_text(size = 24, family = "serif"),  # Increase axis title font size and use serif font
          axis.text = element_text(size = 20, family = "serif"),   # Increase axis label font size and use serif font
          plot.title = element_blank())+
    guides(fill="none")+guides(col="none")+
    geom_segment(aes(x = 0, 
                     xend = 0, 
                     y = 0.03, 
                     yend = 0.15), color = "red")
  
}


#Lowland Species
lowland<-c("ALFL")
for (i in lowland){
  #Unlimited distance analysis
  counts<-read.csv("0_data/1_processed/point counts/UnlimJoinEverything_MoreLatLong.csv", header=TRUE)
  offsets<-read.csv("0_data/1_processed/point counts/UnlimJoinEverything_OFF.csv", header=TRUE)
  offsets<-offsets %>%
    rename_with(.fn = function(.x){paste0(.x,"off")}) 
  offsets$PKEY<-offsets$Xoff
  offsets$Xoff<-NULL
  
  m1<-merge(counts, offsets, by=c("PKEY"))#, by=c("PKEY")
  vegBird<-read.csv("0_data/1_processed/point counts/vegBirdDataHedwigUsed.csv", header=TRUE)
  vegBird$PKEY<-vegBird$pkey
  vegBird$pkey<-NULL
  vegBirdF<-vegBird%>%
    dplyr::select(PKEY,landtype2,F1all4,F2all4,riall,ritree1,riwoody1,rishrub1,riground1)
  #vegBirdF PKEYs: replace string "HEDW" with string "NWTSLR"
  vegBirdF$PKEY<-gsub("HEDW","NWTSLR",vegBirdF$PKEY)
  m2<-merge(m1, vegBirdF, by=c("PKEY"), all.x=TRUE)
  m2<-m2[m2$landtype2=="Lowland",]#just use lowland point counts
  m2<-m2[!is.na(m2$OBSERVER),]
  
  m2$spp<-m2[,i]
  m2$sppoff<-m2[,paste0(i,"off")]
  mean(m2$spp)
  var(m2$spp)#Poisson error distribution
  m2$Julian.s<-(m2$JULIAN_DAY-mean(m2$JULIAN_DAY))/sd(m2$JULIAN_DAY)
  m2$Time.s<-(m2$Time-mean(m2$Time))/sd(m2$Time)
  
  m2$Seismic<-as.factor(ifelse(m2$Veg_Plot.Type=="Interior",0,1))
  m2$Seismic.n<-ifelse(m2$Veg_Plot.Type=="Interior",0,1)
  m2$riall.c<-m2$riall-mean(m2$riall)
  m2$riall.q<-m2$riall.c^2
  m2$rishrub1.c<-m2$rishrub1-mean(m2$rishrub1)
  m2$rishrub1.q<-m2$rishrub1.c^2
  m2$ritree1.c<-m2$ritree1-mean(m2$ritree1)
  m2$ritree1.q<-m2$ritree1.c^2
  m2$riwoody1.c<-m2$riwoody1-mean(m2$riwoody1)
  m2$riwoody1.q<-m2$riwoody1.c^2
  m2$riground1.c<-m2$riground1-mean(m2$riground1)
  m2$riground1.q<-m2$riground1.c^2
  
  if (var(m2$spp,na.rm=TRUE)/mean(m2$spp,na.rm=TRUE)<2) {
    FOREST.UNL<-glmer(spp~F1all4+F2all4+Julian.s+Time.s + (1|OBSERVER), data=m2, family=poisson)
    summary(FOREST.UNL)
    
    LINE.UNL<-glmer(spp~F1all4+F2all4+Seismic+Julian.s+Time.s + (1|OBSERVER), data=m2, family=poisson)
    summary(LINE.UNL)
    
    RIALL.Lin.UNL<-glmer(spp~F1all4+F2all4+Seismic.n+riall+Seismic.n*riall+Julian.s+Time.s + (1|OBSERVER), data=m2, family=poisson)
    summary(RIALL.Lin.UNL)

    RISHRUB.Lin.UNL<-glmer(spp~F1all4+F2all4+Seismic.n+rishrub1+Seismic.n*rishrub1+Julian.s+Time.s + (1|OBSERVER), data=m2, family=poisson)
    summary(RISHRUB.Lin.UNL)

    RITREE.Lin.UNL<-glmer(spp~F1all4+F2all4+Seismic.n+ritree1+Seismic.n*ritree1+Julian.s+Time.s + (1|OBSERVER), data=m2, family=poisson)
    summary(RITREE.Lin.UNL)

    RIGROUND.Lin.UNL<-glmer(spp~F1all4+F2all4+Seismic.n+riground1+Seismic.n*riground1+Julian.s+Time.s + (1|OBSERVER), data=m2, family=poisson)
    summary(RIGROUND.Lin.UNL)
  }
  
  if (!var(m2$spp,na.rm=TRUE)/mean(m2$spp,na.rm=TRUE)<2) {
    FOREST.UNL<-glmer.nb(spp~F1all4+F2all4+Julian.s+Time.s + (1|OBSERVER), data=m2)
    summary(FOREST.UNL)
    
    LINE.UNL<-glmer.nb(spp~F1all4+F2all4+Seismic+Julian.s+Time.s + (1|OBSERVER), data=m2)
    summary(LINE.UNL)
    
    RIALL.Lin.UNL<-glmer.nb(spp~F1all4+F2all4+Seismic.n+riall+Seismic.n*riall+Julian.s+Time.s + (1|OBSERVER), data=m2)
    summary(RIALL.Lin.UNL)

    RISHRUB.Lin.UNL<-glmer.nb(spp~F1all4+F2all4+Seismic.n+rishrub1+Seismic.n*rishrub1+Julian.s+Time.s + (1|OBSERVER), data=m2)
    summary(RISHRUB.Lin.UNL)

    RITREE.Lin.UNL<-glmer.nb(spp~F1all4+F2all4+Seismic.n+ritree1+Seismic.n*ritree1+Julian.s+Time.s + (1|OBSERVER), data=m2)
    summary(RITREE.Lin.UNL)

    RIGROUND.Lin.UNL<-glmer.nb(spp~F1all4+F2all4+Seismic.n+riground1+Seismic.n*riground1+Julian.s+Time.s + (1|OBSERVER), data=m2)
    summary(RIGROUND.Lin.UNL)
  }
  
  #Get prediction counts from best model when Hedwig is the observer
  newdat <- data.frame(F1all4=mean(m2$F1all4, na.rm=TRUE),#older, taller deciduous forest
                       F2all4=mean(m2$F2all4, na.rm=TRUE),#greater canopy cover, dbh, stem density
                       Julian.s=-0.09831949,#June 15
                       Time.s=-1.232137,#5 AM
                       rishrub1=c(-1,-0.9,-0.8,-0.7,-0.6,-0.5,-0.4,-0.3,-0.2,-0.1,0,0),
                       ritree1=c(seq(from=-0.9744162,to=0,by=(0-(-0.9744162))/10),0),
                       riwoody1=c(seq(from=-0.897608,to=0,by=(0-(-0.897608))/10),0),
                       riground1=c(seq(from=-0.6666667,to=0,by=(0-(-0.6666667))/10),0),
                       riall=c(seq(from=-0.7545604,to=0,by=(0-(-0.7545604))/10),0),
                       Seismic.n=c(1,1,1,1,1,1,1,1,1,1,1,0),
                       Seismic=c("1","1","1","1","1","1","1","1","1","1","1","0"))
  
  newdat$riall.c<-newdat$riall-mean(m2$riall)
  newdat$riall.q<-newdat$riall.c^2
  newdat$rishrub1.c<-newdat$rishrub1-mean(m2$rishrub1)
  newdat$rishrub1.q<-newdat$rishrub1.c^2
  newdat$riwoody1.c<-newdat$riwoody1-mean(m2$riwoody1)
  newdat$riwoody1.q<-newdat$riwoody1.c^2
  newdat$ritree1.c<-newdat$ritree1-mean(m2$ritree1)
  newdat$ritree1.q<-newdat$ritree1.c^2
  newdat$riground1.c<-newdat$riground1-mean(m2$riground1)
  newdat$riground1.q<-newdat$riground1.c^2
  
  #Best Model
  dd0 <- model.sel(RIALL.Lin.UNL, 
                   RITREE.Lin.UNL, 
                   RISHRUB.Lin.UNL, 
                   RIGROUND.Lin.UNL, 
                   FOREST.UNL, 
                   LINE.UNL, rank=AIC) 
  bestModel<-get.models(dd0, subset = 1)[[1]]

  fits<-predictSE(bestModel, newdata=newdat, type="link", se.fit=TRUE)
  newdat$bestModelFit<-exp(fits$fit)
  newdat$bestModelFitLCL<-exp(fits$fit-1.96*fits$se.fit)
  newdat$bestModelFitUCL<-exp(fits$fit+1.96*fits$se.fit)
  
  newdat$bestModelFitUCL<-ifelse(newdat$bestModelFitUCL=="Inf",10,newdat$bestModelFitUCL)
  
  p3<-ggplot(data=newdat, aes(x=riground1, y=bestModelFit)) +
    geom_point(aes(x=riground1, y=bestModelFit, col=Seismic))+
    geom_line(aes(x=riground1, y=bestModelFit, col=Seismic))+
    geom_ribbon(aes(ymin=bestModelFitLCL, ymax=bestModelFitUCL, col=Seismic, fill=Seismic), alpha=0.3)+
    labs(x="Recovery Index (Ground Cover)", y=paste0(i," Count"))+
    theme_classic(base_family = "serif") +                        #theme_minimal Apply a minimalistic theme with serif font
    theme(axis.title = element_text(size = 24, family = "serif"),  # Increase axis title font size and use serif font
          axis.text = element_text(size = 20, family = "serif"),   # Increase axis label font size and use serif font
          plot.title = element_blank())+
    guides(fill="none")+guides(col="none")+
    geom_segment(aes(x = 0, 
                     xend = 0, 
                     y = 0.03, 
                     yend = 0.18), color = "red")
  
}

lowland<-c("DEJU")
for (i in lowland){
  #Unlimited distance analysis
  counts<-read.csv("0_data/1_processed/point counts/UnlimJoinEverything_MoreLatLong.csv", header=TRUE)
  offsets<-read.csv("0_data/1_processed/point counts/UnlimJoinEverything_OFF.csv", header=TRUE)
  offsets<-offsets %>%
    rename_with(.fn = function(.x){paste0(.x,"off")}) 
  offsets$PKEY<-offsets$Xoff
  offsets$Xoff<-NULL
  
  m1<-merge(counts, offsets, by=c("PKEY"))#, by=c("PKEY")
  vegBird<-read.csv("0_data/1_processed/point counts/vegBirdDataHedwigUsed.csv", header=TRUE)
  vegBird$PKEY<-vegBird$pkey
  vegBird$pkey<-NULL
  vegBirdF<-vegBird%>%
    dplyr::select(PKEY,landtype2,F1all4,F2all4,riall,ritree1,riwoody1,rishrub1,riground1)
  #vegBirdF PKEYs: replace string "HEDW" with string "NWTSLR"
  vegBirdF$PKEY<-gsub("HEDW","NWTSLR",vegBirdF$PKEY)
  m2<-merge(m1, vegBirdF, by=c("PKEY"), all.x=TRUE)
  m2<-m2[m2$landtype2=="Lowland",]#just use lowland point counts
  m2<-m2[!is.na(m2$OBSERVER),]
  
  m2$spp<-m2[,i]
  m2$sppoff<-m2[,paste0(i,"off")]
  mean(m2$spp)
  var(m2$spp)#Poisson error distribution
  m2$Julian.s<-(m2$JULIAN_DAY-mean(m2$JULIAN_DAY))/sd(m2$JULIAN_DAY)
  m2$Time.s<-(m2$Time-mean(m2$Time))/sd(m2$Time)
  
  m2$Seismic<-as.factor(ifelse(m2$Veg_Plot.Type=="Interior",0,1))
  m2$Seismic.n<-ifelse(m2$Veg_Plot.Type=="Interior",0,1)
  m2$riall.c<-m2$riall-mean(m2$riall)
  m2$riall.q<-m2$riall.c^2
  m2$rishrub1.c<-m2$rishrub1-mean(m2$rishrub1)
  m2$rishrub1.q<-m2$rishrub1.c^2
  m2$ritree1.c<-m2$ritree1-mean(m2$ritree1)
  m2$ritree1.q<-m2$ritree1.c^2
  m2$riwoody1.c<-m2$riwoody1-mean(m2$riwoody1)
  m2$riwoody1.q<-m2$riwoody1.c^2
  m2$riground1.c<-m2$riground1-mean(m2$riground1)
  m2$riground1.q<-m2$riground1.c^2
  
  if (var(m2$spp,na.rm=TRUE)/mean(m2$spp,na.rm=TRUE)<2) {
    FOREST.UNL<-glmer(spp~F1all4+F2all4+Julian.s+Time.s + (1|OBSERVER), data=m2, family=poisson)
    summary(FOREST.UNL)
    
    LINE.UNL<-glmer(spp~F1all4+F2all4+Seismic+Julian.s+Time.s + (1|OBSERVER), data=m2, family=poisson)
    summary(LINE.UNL)
    
    RIALL.Lin.UNL<-glmer(spp~F1all4+F2all4+Seismic.n+riall+Seismic.n*riall+Julian.s+Time.s + (1|OBSERVER), data=m2, family=poisson)
    summary(RIALL.Lin.UNL)
    
    RISHRUB.Lin.UNL<-glmer(spp~F1all4+F2all4+Seismic.n+rishrub1+Seismic.n*rishrub1+Julian.s+Time.s + (1|OBSERVER), data=m2, family=poisson)
    summary(RISHRUB.Lin.UNL)
    
    RITREE.Lin.UNL<-glmer(spp~F1all4+F2all4+Seismic.n+ritree1+Seismic.n*ritree1+Julian.s+Time.s + (1|OBSERVER), data=m2, family=poisson)
    summary(RITREE.Lin.UNL)
    
    RIGROUND.Lin.UNL<-glmer(spp~F1all4+F2all4+Seismic.n+riground1+Seismic.n*riground1+Julian.s+Time.s + (1|OBSERVER), data=m2, family=poisson)
    summary(RIGROUND.Lin.UNL)
  }
  
  if (!var(m2$spp,na.rm=TRUE)/mean(m2$spp,na.rm=TRUE)<2) {
    FOREST.UNL<-glmer.nb(spp~F1all4+F2all4+Julian.s+Time.s + (1|OBSERVER), data=m2)
    summary(FOREST.UNL)
    
    LINE.UNL<-glmer.nb(spp~F1all4+F2all4+Seismic+Julian.s+Time.s + (1|OBSERVER), data=m2)
    summary(LINE.UNL)
    
    RIALL.Lin.UNL<-glmer.nb(spp~F1all4+F2all4+Seismic.n+riall+Seismic.n*riall+Julian.s+Time.s + (1|OBSERVER), data=m2)
    summary(RIALL.Lin.UNL)
    
    RISHRUB.Lin.UNL<-glmer.nb(spp~F1all4+F2all4+Seismic.n+rishrub1+Seismic.n*rishrub1+Julian.s+Time.s + (1|OBSERVER), data=m2)
    summary(RISHRUB.Lin.UNL)
    
    RITREE.Lin.UNL<-glmer.nb(spp~F1all4+F2all4+Seismic.n+ritree1+Seismic.n*ritree1+Julian.s+Time.s + (1|OBSERVER), data=m2)
    summary(RITREE.Lin.UNL)
    
    RIGROUND.Lin.UNL<-glmer.nb(spp~F1all4+F2all4+Seismic.n+riground1+Seismic.n*riground1+Julian.s+Time.s + (1|OBSERVER), data=m2)
    summary(RIGROUND.Lin.UNL)
  }
  
  #Get prediction counts from best model when Hedwig is the observer
  newdat <- data.frame(F1all4=mean(m2$F1all4, na.rm=TRUE),#older, taller deciduous forest
                       F2all4=mean(m2$F2all4, na.rm=TRUE),#greater canopy cover, dbh, stem density
                       Julian.s=-0.09831949,#June 15
                       Time.s=-1.232137,#5 AM
                       rishrub1=c(-1,-0.9,-0.8,-0.7,-0.6,-0.5,-0.4,-0.3,-0.2,-0.1,0,0),
                       ritree1=c(seq(from=-0.9744162,to=0,by=(0-(-0.9744162))/10),0),
                       riwoody1=c(seq(from=-0.897608,to=0,by=(0-(-0.897608))/10),0),
                       riground1=c(seq(from=-0.6666667,to=0,by=(0-(-0.6666667))/10),0),
                       riall=c(seq(from=-0.7545604,to=0,by=(0-(-0.7545604))/10),0),
                       Seismic.n=c(1,1,1,1,1,1,1,1,1,1,1,0),
                       Seismic=c("1","1","1","1","1","1","1","1","1","1","1","0"))
  
  newdat$riall.c<-newdat$riall-mean(m2$riall)
  newdat$riall.q<-newdat$riall.c^2
  newdat$rishrub1.c<-newdat$rishrub1-mean(m2$rishrub1)
  newdat$rishrub1.q<-newdat$rishrub1.c^2
  newdat$riwoody1.c<-newdat$riwoody1-mean(m2$riwoody1)
  newdat$riwoody1.q<-newdat$riwoody1.c^2
  newdat$ritree1.c<-newdat$ritree1-mean(m2$ritree1)
  newdat$ritree1.q<-newdat$ritree1.c^2
  newdat$riground1.c<-newdat$riground1-mean(m2$riground1)
  newdat$riground1.q<-newdat$riground1.c^2
  
  #Best Model
  dd0 <- model.sel(RIALL.Lin.UNL, 
                   RITREE.Lin.UNL, 
                   RISHRUB.Lin.UNL, 
                   RIGROUND.Lin.UNL, 
                   FOREST.UNL, 
                   LINE.UNL, rank=AIC) 
  bestModel<-get.models(dd0, subset = 1)[[1]]
  
  fits<-predictSE(bestModel, newdata=newdat, type="link", se.fit=TRUE)
  newdat$bestModelFit<-exp(fits$fit)
  newdat$bestModelFitLCL<-exp(fits$fit-1.96*fits$se.fit)
  newdat$bestModelFitUCL<-exp(fits$fit+1.96*fits$se.fit)
  
  newdat$bestModelFitUCL<-ifelse(newdat$bestModelFitUCL=="Inf",10,newdat$bestModelFitUCL)
  
  p6<-ggplot(data=newdat, aes(x=ritree1, y=bestModelFit)) +
    geom_point(aes(x=ritree1, y=bestModelFit, col=Seismic))+
    geom_line(aes(x=ritree1, y=bestModelFit, col=Seismic))+
    geom_ribbon(aes(ymin=bestModelFitLCL, ymax=bestModelFitUCL, col=Seismic, fill=Seismic), alpha=0.3)+
    labs(x="Recovery Index (Tree Cover)", y=paste0(i," Count"))+
    theme_classic(base_family = "serif") +                        #theme_minimal Apply a minimalistic theme with serif font
    theme(axis.title = element_text(size = 24, family = "serif"),  # Increase axis title font size and use serif font
          axis.text = element_text(size = 20, family = "serif"),   # Increase axis label font size and use serif font
          plot.title = element_blank())+
    guides(fill="none")+guides(col="none")+
    geom_segment(aes(x = 0, 
                     xend = 0, 
                     y = 0.61, 
                     yend = 1.46), color = "red")
  
}

#Multi-panel plot
p123<-grid.arrange(p3,p2,p1,
                      ncol=1,
                      nrow=3)
ggsave(p123, file="2_outputs/December 2023/MultipanelPlot_3SpeciesExemplarsBestModelUnlimDist.png", units="in", dpi=300, width=6, height=12)

p123456<-grid.arrange(p3,p6,p2,p5,p1,p4,
                   ncol=2,
                   nrow=3)
ggsave(p123456, file="2_outputs/December 2023/MultipanelPlot_6SpeciesExemplarsBestModelUnlimDist.png", units="in", dpi=300, width=12, height=12)
