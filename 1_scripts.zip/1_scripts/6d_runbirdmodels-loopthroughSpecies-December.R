#The purpose of this script is to run mixed-effects models of individual 
#generalist, upland, and lowland bird species in forest and seismic line 
#point counts, with separate analyses using observations within 50 m, 
#within 100 m, or unlimited distance point counts. 

library(tidyverse)
library(ggplot2)
library(MuMIn)
library(lme4)
library(AICcmodavg)
library(grid)
library(gridExtra)
my.theme <- theme_classic() +
  theme(text=element_text(size=24, family="Arial"),
        axis.text.x=element_text(size=24),
        axis.text.y=element_text(size=24),
        axis.title.x=element_text(margin=margin(24,0,0,0)),
        axis.title.y=element_text(margin=margin(0,24,0,0)),
        axis.line.x=element_line(linetype=1),
        axis.line.y=element_line(linetype=1))



generalists<-c("YRWA")

#Generalists
generalists<-c("AMRO",#American Robin
               "BAWW",#Black-and-white Warbler
               "BBWA",#Bay-breasted Warbler
               "CHSP",#Chipping Sparrow
               "MAWA",#Magnolia Warbler
               "RBGR",#Rose-breasted Grosbeak
               "SWTH",#Swainson's Thrush
               "TEWA",#Tennessee Warbler
               "WTSP",#White-throated Sparrow
               "YRWA")#Yellow-rumped Warbler

for (i in generalists){
  print(paste0("Starting analysis for ",i))
  #50-m analysis
  counts<-read.csv("0_data/1_processed/point counts/50mJoinEverything_MoreLatLong.csv", header=TRUE)
  offsets<-read.csv("0_data/1_processed/point counts/50mJoinEverything_OFF.csv", header=TRUE)
  offsets<-offsets %>%
    rename_with(.fn = function(.x){paste0(.x,"off")}) 
  offsets$PKEY<-offsets$Xoff
  offsets$Xoff<-NULL
  
  m1<-merge(counts, offsets, by=c("PKEY"))
  
  #This file appears to have the PCA scores and RI values needed for bird models.
  vegBird<-read.csv("0_data/1_processed/point counts/vegBirdDataHedwigUsed.csv", header=TRUE)
  vegBird$PKEY<-vegBird$pkey
  vegBird$pkey<-NULL
  vegBirdF<-vegBird%>%
    dplyr::select(PKEY,F1all4,F2all4,riall,ritree1,rishrub1,riground1,riwoody1)
  #vegBirdF PKEYs: replace string "HEDW" with string "NWTSLR"
  vegBirdF$PKEY<-gsub("HEDW","NWTSLR",vegBirdF$PKEY)
  
  setdiff(m1$PKEY, vegBirdF$PKEY)#41 PKEYs
  setdiff(vegBirdF$PKEY, m1$PKEY)#34 PKEYs
  
  m2<-merge(m1, vegBirdF, by=c("PKEY"), all.x=TRUE)
  m2<-m2[!is.na(m2$OBSERVER),]
  m2$OBSERVER<-as.factor(m2$OBSERVER)
  
  m2$spp<-m2[,i]
  m2$sppoff<-m2[,paste0(i,"off")]
  mean(m2$spp)
  var(m2$spp)#Poisson error distribution
  m2$Julian.s<-(m2$JULIAN_DAY-mean(m2$JULIAN_DAY))/sd(m2$JULIAN_DAY)
  m2$Time.s<-(m2$Time-mean(m2$Time))/sd(m2$Time)
  
  m2$Seismic<-as.factor(ifelse(m2$Veg_Plot.Type=="Interior",0,1))
  m2$Seismic.n<-ifelse(m2$Veg_Plot.Type=="Interior",0,1)
  m2$riall.c<-m2$riall-mean(m2$riall, na.rm=TRUE)
  m2$riall.q<-m2$riall.c^2
  m2$rishrub1.c<-m2$rishrub1-mean(m2$rishrub1, na.rm=TRUE)
  m2$rishrub1.q<-m2$rishrub1.c^2
  m2$ritree1.c<-m2$ritree1-mean(m2$ritree1, na.rm=TRUE)
  m2$ritree1.q<-m2$ritree1.c^2
  m2$riwoody1.c<-m2$riwoody1-mean(m2$riwoody1, na.rm=TRUE)
  m2$riwoody1.q<-m2$riwoody1.c^2
  m2$riground1.c<-m2$riground1-mean(m2$riground1, na.rm=TRUE)
  m2$riground1.q<-m2$riground1.c^2
  
  if (var(m2$spp,na.rm=TRUE)/mean(m2$spp,na.rm=TRUE)<2) {
    FOREST.50<-glmer(spp~F1all4+F2all4+Julian.s+Time.s + (1|OBSERVER), data=m2, family=poisson)
    summary(FOREST.50)
    
    LINE.50<-glmer(spp~F1all4+F2all4+Seismic+Julian.s+Time.s + (1|OBSERVER), data=m2, family=poisson)
    summary(LINE.50)
    
    RIALL.Lin.50<-glmer(spp~F1all4+F2all4+Seismic.n+riall+Seismic.n*riall+Julian.s+Time.s + (1|OBSERVER), data=m2, family=poisson)
    summary(RIALL.Lin.50)

    RISHRUB.Lin.50<-glmer(spp~F1all4+F2all4+Seismic.n+rishrub1+Seismic.n*rishrub1+Julian.s+Time.s + (1|OBSERVER), data=m2, family=poisson)
    summary(RISHRUB.Lin.50)
    
    RITREE.Lin.50<-glmer(spp~F1all4+F2all4+Seismic.n+ritree1+Seismic.n*ritree1+Julian.s+Time.s + (1|OBSERVER), data=m2, family=poisson)
    summary(RITREE.Lin.50)

    RIGROUND.Lin.50<-glmer(spp~F1all4+F2all4+Seismic.n+riground1+Seismic.n*riground1+Julian.s+Time.s + (1|OBSERVER), data=m2, family=poisson)
    summary(RIGROUND.Lin.50)
  }
  
  if (!var(m2$spp,na.rm=TRUE)/mean(m2$spp,na.rm=TRUE)<2) {
    FOREST.50<-glmer.nb(spp~F1all4+F2all4+Julian.s+Time.s + (1|OBSERVER), data=m2)
    summary(FOREST.50)
    
    LINE.50<-glmer.nb(spp~F1all4+F2all4+Seismic+Julian.s+Time.s + (1|OBSERVER), data=m2)
    summary(LINE.50)
    
    RIALL.Lin.50<-glmer.nb(spp~F1all4+F2all4+Seismic.n+riall+Seismic.n*riall+Julian.s+Time.s + (1|OBSERVER), data=m2)
    summary(RIALL.Lin.50)

    RISHRUB.Lin.50<-glmer.nb(spp~F1all4+F2all4+Seismic.n+rishrub1+Seismic.n*rishrub1+Julian.s+Time.s + (1|OBSERVER), data=m2)
    summary(RISHRUB.Lin.50)

    RITREE.Lin.50<-glmer.nb(spp~F1all4+F2all4+Seismic.n+ritree1+Seismic.n*ritree1+Julian.s+Time.s + (1|OBSERVER), data=m2)
    summary(RITREE.Lin.50)

    RIGROUND.Lin.50<-glmer.nb(spp~F1all4+F2all4+Seismic.n+riground1+Seismic.n*riground1+Julian.s+Time.s + (1|OBSERVER), data=m2)
    summary(RIGROUND.Lin.50)
  }

  #Get prediction counts from best model when Hedwig is the observer
  newdat <- data.frame(F1all4=mean(m2$F1all4, na.rm=TRUE),#older, taller deciduous forest
                       F2all4=mean(m2$F2all4, na.rm=TRUE),#greater canopy cover, dbh, stem density
                       Julian.s=-0.09831949,#June 15
                       Time.s=-1.232137,#5 AM
                       rishrub1=c(-1,-0.9,-0.8,-0.7,-0.6,-0.5,-0.4,-0.3,-0.2,-0.1,0,0),
                       ritree1=c(seq(from=-0.9744162,to=0,by=(0-(-0.9744162))/10),0),
                       riwoody1=c(seq(from=-0.897608,to=0,by=(0-(-0.897608))/10),0),
                       riground1=c(seq(from=-0.6666667,to=0,by=(0-(-0.6666667))/10),0),
                       riall=c(seq(from=-0.7545604,to=0,by=(0-(-0.7545604))/10),0),
                       Seismic.n=c(1,1,1,1,1,1,1,1,1,1,1,0),
                       Seismic=c("1","1","1","1","1","1","1","1","1","1","1","0"))
  
  newdat$riall.c<-newdat$riall-mean(m2$riall, na.rm=TRUE)
  newdat$riall.q<-newdat$riall.c^2
  newdat$rishrub1.c<-newdat$rishrub1-mean(m2$rishrub1, na.rm=TRUE)
  newdat$rishrub1.q<-newdat$rishrub1.c^2
  newdat$riwoody1.c<-newdat$riwoody1-mean(m2$riwoody1, na.rm=TRUE)
  newdat$riwoody1.q<-newdat$riwoody1.c^2
  newdat$ritree1.c<-newdat$ritree1-mean(m2$ritree1, na.rm=TRUE)
  newdat$ritree1.q<-newdat$ritree1.c^2
  newdat$riground1.c<-newdat$riground1-mean(m2$riground1, na.rm=TRUE)
  newdat$riground1.q<-newdat$riground1.c^2
  
  #Best Model
  dd0 <- model.sel(RIALL.Lin.50, 
                   RITREE.Lin.50, 
                   RISHRUB.Lin.50, 
                   RIGROUND.Lin.50, 
                   FOREST.50, 
                   LINE.50, rank=AIC) 
  bestModel<-get.models(dd0, subset = 1)[[1]]
  secondbestModel<-get.models(dd0, subset = 2)[[1]]
  thirdbestModel<-get.models(dd0, subset = 3)[[1]]
  #gets best model in terms of lowest AICc, highest Akaike weight
  #bestModel=RITREE.Lin.50
  
  fits<-predictSE(bestModel, newdata=newdat, type="link", se.fit=TRUE)
  newdat$bestModelFit<-exp(fits$fit)
  newdat$bestModelFitLCL<-exp(fits$fit-1.96*fits$se.fit)
  newdat$bestModelFitUCL<-exp(fits$fit+1.96*fits$se.fit)

  newdat$bestModelFitUCL<-ifelse(newdat$bestModelFitUCL=="Inf",10,newdat$bestModelFitUCL)
  
  #Best Model = LINE.50 but here's RIALL.Lin.50  
  p1a<-ggplot(data=newdat, aes(x=riall, y=bestModelFit)) +
    geom_point(aes(x=riall, y=bestModelFit, col=Seismic, shape=Seismic), size=4)+
    geom_line(aes(x=riall, y=bestModelFit, col=Seismic))+
    geom_errorbar(aes(ymin=bestModelFitLCL, ymax=bestModelFitUCL, col=Seismic), width=.075)+
    ylim(0,(1.1*max(newdat$bestModelFitUCL)))+
    labs(x="Recovery Index (All veg.)", y=paste0("Predicted ",i," Count (50 m)"))+
    theme_classic(base_family = "serif") +                        #theme_minimal Apply a minimalistic theme with serif font
    theme(axis.title = element_text(size = 24, family = "serif"),  # Increase axis title font size and use serif font
          axis.text = element_text(size = 20, family = "serif"),   # Increase axis label font size and use serif font
          plot.title = element_blank(),
          legend.position = "none")    
  ggsave(p1a, file=paste0("2_outputs/December 2023/",i,"predcountbestmodel_50m.png"), units="in", width=10, height=8)

  #get coefficients from best model for each species/point count size
  mydataFrame<-data.frame(summary(bestModel)$coefficients)
  mydataFrame$Species<-i
  mydataFrame$PCradius<-50
  mydataFrame$ModelName<-row.names(dd0)[1]
  mydataFrame$Predictor<-row.names(mydataFrame)
  mydataFrame$AIC<-AIC(bestModel)
  mydataFrame$AICweight<-dd0$weight[1]
  mydataFrame$marginalR2<-r.squaredGLMM(bestModel)[2,1]
  mydataFrame$condR2<-r.squaredGLMM(bestModel)[2,2]
  mydataFrame$LCL<-mydataFrame$Estimate-1.96*mydataFrame$Std..Error
  mydataFrame$UCL<-mydataFrame$Estimate+1.96*mydataFrame$Std..Error
  #reorder data frame
  mydataFrame2<-mydataFrame%>%
    dplyr::select(Species,PCradius,ModelName,Predictor,Estimate,Std..Error,LCL,UCL,z.value,Pr...z..,AIC,AICweight,marginalR2,condR2)
  write.csv(mydataFrame2, file=paste0("2_outputs/December 2023/",i,".50mbestmodelcoefs.csv"))
  mydataFrame3<-data.frame(dd0)  
  write.csv(mydataFrame3, file=paste0("2_outputs/December 2023/",i,".50mbestmodeltable.csv"))
  
  #get coefficients from second best model for each species/point count size
  mydataFrame<-data.frame(summary(secondbestModel)$coefficients)
  mydataFrame$Species<-i
  mydataFrame$PCradius<-50
  mydataFrame$ModelName<-row.names(dd0)[2]
  mydataFrame$Predictor<-row.names(mydataFrame)
  mydataFrame$AIC<-AIC(secondbestModel)
  mydataFrame$AICweight<-dd0$weight[2]
  mydataFrame$marginalR2<-r.squaredGLMM(secondbestModel)[2,1]
  mydataFrame$condR2<-r.squaredGLMM(secondbestModel)[2,2]
  mydataFrame$LCL<-mydataFrame$Estimate-1.96*mydataFrame$Std..Error
  mydataFrame$UCL<-mydataFrame$Estimate+1.96*mydataFrame$Std..Error
  #reorder data frame
  mydataFrame2<-mydataFrame%>%
    dplyr::select(Species,PCradius,ModelName,Predictor,Estimate,Std..Error,LCL,UCL,z.value,Pr...z..,AIC,AICweight,marginalR2,condR2)
  write.csv(mydataFrame2, file=paste0("2_outputs/December 2023/",i,".50msecondbestModelcoefs.csv"))

  #get coefficients from third best model for each species/point count size
  mydataFrame<-data.frame(summary(thirdbestModel)$coefficients)
  mydataFrame$Species<-i
  mydataFrame$PCradius<-50
  mydataFrame$ModelName<-row.names(dd0)[3]
  mydataFrame$Predictor<-row.names(mydataFrame)
  mydataFrame$AIC<-AIC(thirdbestModel)
  mydataFrame$AICweight<-dd0$weight[3]
  mydataFrame$marginalR2<-r.squaredGLMM(thirdbestModel)[2,1]
  mydataFrame$condR2<-r.squaredGLMM(thirdbestModel)[2,2]
  mydataFrame$LCL<-mydataFrame$Estimate-1.96*mydataFrame$Std..Error
  mydataFrame$UCL<-mydataFrame$Estimate+1.96*mydataFrame$Std..Error
  #reorder data frame
  mydataFrame2<-mydataFrame%>%
    dplyr::select(Species,PCradius,ModelName,Predictor,Estimate,Std..Error,LCL,UCL,z.value,Pr...z..,AIC,AICweight,marginalR2,condR2)
  write.csv(mydataFrame2, file=paste0("2_outputs/December 2023/",i,".50mthirdbestModelcoefs.csv"))
  
  print(paste0("Starting 100-m models for ",i))
  
  
  #100-m analysis
  counts<-read.csv("0_data/1_processed/point counts/100mJoinEverything_MoreLatLong.csv", header=TRUE)
  offsets<-read.csv("0_data/1_processed/point counts/100mJoinEverything_OFF.csv", header=TRUE)
  offsets<-offsets %>%
    rename_with(.fn = function(.x){paste0(.x,"off")}) 
  offsets$PKEY<-offsets$Xoff
  offsets$Xoff<-NULL
  
  m1<-merge(counts, offsets, by=c("PKEY"))
  
  vegBird<-read.csv("0_data/1_processed/point counts/vegBirdDataHedwigUsed.csv", header=TRUE)
  vegBird$PKEY<-vegBird$pkey
  vegBird$pkey<-NULL
  vegBirdF<-vegBird%>%
    dplyr::select(PKEY,F1all4,F2all4,riall,ritree1,rishrub1,riground1,riwoody1)
  #vegBirdF PKEYs: replace string "HEDW" with string "NWTSLR"
  vegBirdF$PKEY<-gsub("HEDW","NWTSLR",vegBirdF$PKEY)
  m2<-merge(m1, vegBirdF, by=c("PKEY"), all.x=TRUE)
  m2<-m2[!is.na(m2$OBSERVER),]
  m2$OBSERVER<-as.factor(m2$OBSERVER)
  
  m2$spp<-m2[,i]
  m2$sppoff<-m2[,paste0(i,"off")]
  mean(m2$spp)
  var(m2$spp)#Poisson error distribution
  m2$Julian.s<-(m2$JULIAN_DAY-mean(m2$JULIAN_DAY))/sd(m2$JULIAN_DAY)
  m2$Time.s<-(m2$Time-mean(m2$Time))/sd(m2$Time)
  
  m2$Seismic<-as.factor(ifelse(m2$Veg_Plot.Type=="Interior",0,1))
  m2$Seismic.n<-ifelse(m2$Veg_Plot.Type=="Interior",0,1)
  m2$riall.c<-m2$riall-mean(m2$riall, na.rm=TRUE)
  m2$riall.q<-m2$riall.c^2
  m2$rishrub1.c<-m2$rishrub1-mean(m2$rishrub1, na.rm=TRUE)
  m2$rishrub1.q<-m2$rishrub1.c^2
  m2$ritree1.c<-m2$ritree1-mean(m2$ritree1, na.rm=TRUE)
  m2$ritree1.q<-m2$ritree1.c^2
  m2$riwoody1.c<-m2$riwoody1-mean(m2$riwoody1, na.rm=TRUE)
  m2$riwoody1.q<-m2$riwoody1.c^2
  m2$riground1.c<-m2$riground1-mean(m2$riground1, na.rm=TRUE)
  m2$riground1.q<-m2$riground1.c^2
  
  if (var(m2$spp,na.rm=TRUE)/mean(m2$spp,na.rm=TRUE)<2) {
    FOREST.100<-glmer(spp~F1all4+F2all4+Julian.s+Time.s + (1|OBSERVER), data=m2, family=poisson)
    summary(FOREST.100)
    
    LINE.100<-glmer(spp~F1all4+F2all4+Seismic+Julian.s+Time.s + (1|OBSERVER), data=m2, family=poisson)
    summary(LINE.100)
    
    RIALL.Lin.100<-glmer(spp~F1all4+F2all4+Seismic.n+riall+Seismic.n*riall+Julian.s+Time.s + (1|OBSERVER), data=m2, family=poisson)
    summary(RIALL.Lin.100)

    RISHRUB.Lin.100<-glmer(spp~F1all4+F2all4+Seismic.n+rishrub1+Seismic.n*rishrub1+Julian.s+Time.s + (1|OBSERVER), data=m2, family=poisson)
    summary(RISHRUB.Lin.100)

    RITREE.Lin.100<-glmer(spp~F1all4+F2all4+Seismic.n+ritree1+Seismic.n*ritree1+Julian.s+Time.s + (1|OBSERVER), data=m2, family=poisson)
    summary(RITREE.Lin.100)
    
    RIGROUND.Lin.100<-glmer(spp~F1all4+F2all4+Seismic.n+riground1+Seismic.n*riground1+Julian.s+Time.s + (1|OBSERVER), data=m2, family=poisson)
    summary(RIGROUND.Lin.100)
  }
  
  if (!var(m2$spp,na.rm=TRUE)/mean(m2$spp,na.rm=TRUE)<2) {
    FOREST.100<-glmer.nb(spp~F1all4+F2all4+Julian.s+Time.s + (1|OBSERVER), data=m2)
    summary(FOREST.100)
    
    LINE.100<-glmer.nb(spp~F1all4+F2all4+Seismic+Julian.s+Time.s + (1|OBSERVER), data=m2)
    summary(LINE.100)
    
    RIALL.Lin.100<-glmer.nb(spp~F1all4+F2all4+Seismic.n+riall+Seismic.n*riall+Julian.s+Time.s + (1|OBSERVER), data=m2)
    summary(RIALL.Lin.100)

    RISHRUB.Lin.100<-glmer.nb(spp~F1all4+F2all4+Seismic.n+rishrub1+Seismic.n*rishrub1+Julian.s+Time.s + (1|OBSERVER), data=m2)
    summary(RISHRUB.Lin.100)

    RITREE.Lin.100<-glmer.nb(spp~F1all4+F2all4+Seismic.n+ritree1+Seismic.n*ritree1+Julian.s+Time.s + (1|OBSERVER), data=m2)
    summary(RITREE.Lin.100)

    RIGROUND.Lin.100<-glmer.nb(spp~F1all4+F2all4+Seismic.n+riground1+Seismic.n*riground1+Julian.s+Time.s + (1|OBSERVER), data=m2)
    summary(RIGROUND.Lin.100)
  }
  
  #Get prediction counts from best model when Hedwig is the observer
  newdat <- data.frame(F1all4=mean(m2$F1all4, na.rm=TRUE),#older, taller deciduous forest
                       F2all4=mean(m2$F2all4, na.rm=TRUE),#greater canopy cover, dbh, stem density
                       Julian.s=-0.09831949,#June 15
                       Time.s=-1.232137,#5 AM
                       rishrub1=c(-1,-0.9,-0.8,-0.7,-0.6,-0.5,-0.4,-0.3,-0.2,-0.1,0,0),
                       ritree1=c(seq(from=-0.9744162,to=0,by=(0-(-0.9744162))/10),0),
                       riwoody1=c(seq(from=-0.897608,to=0,by=(0-(-0.897608))/10),0),
                       riground1=c(seq(from=-0.6666667,to=0,by=(0-(-0.6666667))/10),0),
                       riall=c(seq(from=-0.7545604,to=0,by=(0-(-0.7545604))/10),0),
                       Seismic.n=c(1,1,1,1,1,1,1,1,1,1,1,0),
                       Seismic=c("1","1","1","1","1","1","1","1","1","1","1","0"))
  
  newdat$riall.c<-newdat$riall-mean(m2$riall, na.rm=TRUE)
  newdat$riall.q<-newdat$riall.c^2
  newdat$rishrub1.c<-newdat$rishrub1-mean(m2$rishrub1, na.rm=TRUE)
  newdat$rishrub1.q<-newdat$rishrub1.c^2
  newdat$riwoody1.c<-newdat$riwoody1-mean(m2$riwoody1, na.rm=TRUE)
  newdat$riwoody1.q<-newdat$riwoody1.c^2
  newdat$ritree1.c<-newdat$ritree1-mean(m2$ritree1, na.rm=TRUE)
  newdat$ritree1.q<-newdat$ritree1.c^2
  newdat$riground1.c<-newdat$riground1-mean(m2$riground1, na.rm=TRUE)
  newdat$riground1.q<-newdat$riground1.c^2
  
  #Best Model
  dd0 <- model.sel(RIALL.Lin.100, 
                   RITREE.Lin.100, 
                   RISHRUB.Lin.100, 
                   RIGROUND.Lin.100, 
                   FOREST.100, 
                   LINE.100, rank=AIC) 
  bestModel<-get.models(dd0, subset = 1)[[1]]
  secondbestModel<-get.models(dd0, subset = 2)[[1]]
  thirdbestModel<-get.models(dd0, subset = 3)[[1]]
  #gets best model in terms of lowest AICc, highest Akaike weight
  #bestModel=LINE.100
  
  fits<-predictSE(bestModel, newdata=newdat, type="link", se.fit=TRUE)
  newdat$bestModelFit<-exp(fits$fit)
  newdat$bestModelFitLCL<-exp(fits$fit-1.96*fits$se.fit)
  newdat$bestModelFitUCL<-exp(fits$fit+1.96*fits$se.fit)
  
  newdat$bestModelFitUCL<-ifelse(newdat$bestModelFitUCL=="Inf",10,newdat$bestModelFitUCL)
  
  p1b<-ggplot(data=newdat, aes(x=riall, y=bestModelFit)) +
    geom_point(aes(x=riall, y=bestModelFit, col=Seismic, shape=Seismic), size=4)+
    geom_line(aes(x=riall, y=bestModelFit, col=Seismic))+
    geom_errorbar(aes(ymin=bestModelFitLCL, ymax=bestModelFitUCL, col=Seismic), width=.075)+
    ylim(0,(1.1*max(newdat$bestModelFitUCL)))+
    labs(x="Recovery Index (All veg.)", y=paste0("Predicted ",i," Count (100 m)"))+
    theme_classic(base_family = "serif") +                        #theme_minimal Apply a minimalistic theme with serif font
    theme(axis.title = element_text(size = 24, family = "serif"),  # Increase axis title font size and use serif font
          axis.text = element_text(size = 20, family = "serif"),   # Increase axis label font size and use serif font
          plot.title = element_blank(),
          legend.position = "none")    
  ggsave(p1b, file=paste0("2_outputs/December 2023/",i,"predcountbestmodel_100m.png"), units="in", width=10, height=8)


  #get coefficients from best model for each species/point count size
  mydataFrame<-data.frame(summary(bestModel)$coefficients)
  mydataFrame$Species<-i
  mydataFrame$PCradius<-100
  mydataFrame$ModelName<-row.names(dd0)[1]
  mydataFrame$Predictor<-row.names(mydataFrame)
  mydataFrame$AIC<-AIC(bestModel)
  mydataFrame$AICweight<-dd0$weight[1]
  mydataFrame$marginalR2<-r.squaredGLMM(bestModel)[2,1]
  mydataFrame$condR2<-r.squaredGLMM(bestModel)[2,2]
  mydataFrame$LCL<-mydataFrame$Estimate-1.96*mydataFrame$Std..Error
  mydataFrame$UCL<-mydataFrame$Estimate+1.96*mydataFrame$Std..Error
  #reorder data frame
  mydataFrame2<-mydataFrame%>%
    dplyr::select(Species,PCradius,ModelName,Predictor,Estimate,Std..Error,LCL,UCL,z.value,Pr...z..,AIC,AICweight,marginalR2,condR2)
  write.csv(mydataFrame2, file=paste0("2_outputs/December 2023/",i,".100mbestmodelcoefs.csv"))
  mydataFrame3<-data.frame(dd0)
  write.csv(mydataFrame3, file=paste0("2_outputs/December 2023/",i,".100mbestmodeltable.csv"))
  
  #get coefficients from second best model for each species/point count size
  mydataFrame<-data.frame(summary(secondbestModel)$coefficients)
  mydataFrame$Species<-i
  mydataFrame$PCradius<-100
  mydataFrame$ModelName<-row.names(dd0)[2]
  mydataFrame$Predictor<-row.names(mydataFrame)
  mydataFrame$AIC<-AIC(secondbestModel)
  mydataFrame$AICweight<-dd0$weight[2]
  mydataFrame$marginalR2<-r.squaredGLMM(secondbestModel)[2,1]
  mydataFrame$condR2<-r.squaredGLMM(secondbestModel)[2,2]
  mydataFrame$LCL<-mydataFrame$Estimate-1.96*mydataFrame$Std..Error
  mydataFrame$UCL<-mydataFrame$Estimate+1.96*mydataFrame$Std..Error
  #reorder data frame
  mydataFrame2<-mydataFrame%>%
    dplyr::select(Species,PCradius,ModelName,Predictor,Estimate,Std..Error,LCL,UCL,z.value,Pr...z..,AIC,AICweight,marginalR2,condR2)
  write.csv(mydataFrame2, file=paste0("2_outputs/December 2023/",i,".100msecondbestModelcoefs.csv"))
  
  #get coefficients from third best model for each species/point count size
  mydataFrame<-data.frame(summary(thirdbestModel)$coefficients)
  mydataFrame$Species<-i
  mydataFrame$PCradius<-100
  mydataFrame$ModelName<-row.names(dd0)[3]
  mydataFrame$Predictor<-row.names(mydataFrame)
  mydataFrame$AIC<-AIC(thirdbestModel)
  mydataFrame$AICweight<-dd0$weight[3]
  mydataFrame$marginalR2<-r.squaredGLMM(thirdbestModel)[2,1]
  mydataFrame$condR2<-r.squaredGLMM(thirdbestModel)[2,2]
  mydataFrame$LCL<-mydataFrame$Estimate-1.96*mydataFrame$Std..Error
  mydataFrame$UCL<-mydataFrame$Estimate+1.96*mydataFrame$Std..Error
  #reorder data frame
  mydataFrame2<-mydataFrame%>%
    dplyr::select(Species,PCradius,ModelName,Predictor,Estimate,Std..Error,LCL,UCL,z.value,Pr...z..,AIC,AICweight,marginalR2,condR2)
  write.csv(mydataFrame2, file=paste0("2_outputs/December 2023/",i,".100mthirdbestModelcoefs.csv"))
  
  print(paste0("Starting unlimited-distance models for ",i))
  
  #Unlimited distance analysis
  counts<-read.csv("0_data/1_processed/point counts/UnlimJoinEverything_MoreLatLong.csv", header=TRUE)
  offsets<-read.csv("0_data/1_processed/point counts/UnlimJoinEverything_OFF.csv", header=TRUE)
  offsets<-offsets %>%
    rename_with(.fn = function(.x){paste0(.x,"off")}) 
  offsets$PKEY<-offsets$Xoff
  offsets$Xoff<-NULL
  
  m1<-merge(counts, offsets, by=c("PKEY"))#, by=c("PKEY")
  vegBird<-read.csv("0_data/1_processed/point counts/vegBirdDataHedwigUsed.csv", header=TRUE)
  vegBird$PKEY<-vegBird$pkey
  vegBird$pkey<-NULL
  vegBirdF<-vegBird%>%
    dplyr::select(PKEY,F1all4,F2all4,riall,ritree1,rishrub1,riground1,riwoody1)
  #vegBirdF PKEYs: replace string "HEDW" with string "NWTSLR"
  vegBirdF$PKEY<-gsub("HEDW","NWTSLR",vegBirdF$PKEY)
  m2<-merge(m1, vegBirdF, by=c("PKEY"), all.x=TRUE)
  m2<-m2[!is.na(m2$OBSERVER),]
  m2$OBSERVER<-as.factor(m2$OBSERVER)  
  
  m2$spp<-m2[,i]
  m2$sppoff<-m2[,paste0(i,"off")]
  mean(m2$spp)
  var(m2$spp)#Poisson error distribution
  m2$Julian.s<-(m2$JULIAN_DAY-mean(m2$JULIAN_DAY))/sd(m2$JULIAN_DAY)
  m2$Time.s<-(m2$Time-mean(m2$Time))/sd(m2$Time)
  
  
  m2$Seismic<-as.factor(ifelse(m2$Veg_Plot.Type=="Interior",0,1))
  m2$Seismic.n<-ifelse(m2$Veg_Plot.Type=="Interior",0,1)
  m2$riall.c<-m2$riall-mean(m2$riall, na.rm=TRUE)
  m2$riall.q<-m2$riall.c^2
  m2$rishrub1.c<-m2$rishrub1-mean(m2$rishrub1, na.rm=TRUE)
  m2$rishrub1.q<-m2$rishrub1.c^2
  m2$ritree1.c<-m2$ritree1-mean(m2$ritree1, na.rm=TRUE)
  m2$ritree1.q<-m2$ritree1.c^2
  m2$riwoody1.c<-m2$riwoody1-mean(m2$riwoody1, na.rm=TRUE)
  m2$riwoody1.q<-m2$riwoody1.c^2
  m2$riground1.c<-m2$riground1-mean(m2$riground1, na.rm=TRUE)
  m2$riground1.q<-m2$riground1.c^2
  
  if (var(m2$spp,na.rm=TRUE)/mean(m2$spp,na.rm=TRUE)<2) {
    FOREST.UNL<-glmer(spp~F1all4+F2all4+Julian.s+Time.s + (1|OBSERVER), data=m2, family=poisson)
    summary(FOREST.UNL)
    
    LINE.UNL<-glmer(spp~F1all4+F2all4+Seismic+Julian.s+Time.s + (1|OBSERVER), data=m2, family=poisson)
    summary(LINE.UNL)
    
    RIALL.Lin.UNL<-glmer(spp~F1all4+F2all4+Seismic.n+riall+Seismic.n*riall+Julian.s+Time.s + (1|OBSERVER), data=m2, family=poisson)
    summary(RIALL.Lin.UNL)

    RISHRUB.Lin.UNL<-glmer(spp~F1all4+F2all4+Seismic.n+rishrub1+Seismic.n*rishrub1+Julian.s+Time.s + (1|OBSERVER), data=m2, family=poisson)
    summary(RISHRUB.Lin.UNL)

    RITREE.Lin.UNL<-glmer(spp~F1all4+F2all4+Seismic.n+ritree1+Seismic.n*ritree1+Julian.s+Time.s + (1|OBSERVER), data=m2, family=poisson)
    summary(RITREE.Lin.UNL)

    RIGROUND.Lin.UNL<-glmer(spp~F1all4+F2all4+Seismic.n+riground1+Seismic.n*riground1+Julian.s+Time.s + (1|OBSERVER), data=m2, family=poisson)
    summary(RIGROUND.Lin.UNL)
  }
  
  if (!var(m2$spp,na.rm=TRUE)/mean(m2$spp,na.rm=TRUE)<2) {
    FOREST.UNL<-glmer.nb(spp~F1all4+F2all4+Julian.s+Time.s + (1|OBSERVER), data=m2)
    summary(FOREST.UNL)
    
    LINE.UNL<-glmer.nb(spp~F1all4+F2all4+Seismic+Julian.s+Time.s + (1|OBSERVER), data=m2)
    summary(LINE.UNL)
    
    RIALL.Lin.UNL<-glmer.nb(spp~F1all4+F2all4+Seismic.n+riall+Seismic.n*riall+Julian.s+Time.s + (1|OBSERVER), data=m2)
    summary(RIALL.Lin.UNL)

    RISHRUB.Lin.UNL<-glmer.nb(spp~F1all4+F2all4+Seismic.n+rishrub1+Seismic.n*rishrub1+Julian.s+Time.s + (1|OBSERVER), data=m2)
    summary(RISHRUB.Lin.UNL)

    RITREE.Lin.UNL<-glmer.nb(spp~F1all4+F2all4+Seismic.n+ritree1+Seismic.n*ritree1+Julian.s+Time.s + (1|OBSERVER), data=m2)
    summary(RITREE.Lin.UNL)

    RIGROUND.Lin.UNL<-glmer.nb(spp~F1all4+F2all4+Seismic.n+riground1+Seismic.n*riground1+Julian.s+Time.s + (1|OBSERVER), data=m2)
    summary(RIGROUND.Lin.UNL)
  }
  
  #Get prediction counts from best model when Hedwig is the observer
  newdat <- data.frame(F1all4=mean(m2$F1all4, na.rm=TRUE),#older, taller deciduous forest
                       F2all4=mean(m2$F2all4, na.rm=TRUE),#greater canopy cover, dbh, stem density
                       Julian.s=-0.09831949,#June 15
                       Time.s=-1.232137,#5 AM
                       rishrub1=c(-1,-0.9,-0.8,-0.7,-0.6,-0.5,-0.4,-0.3,-0.2,-0.1,0,0),
                       ritree1=c(seq(from=-0.9744162,to=0,by=(0-(-0.9744162))/10),0),
                       riwoody1=c(seq(from=-0.897608,to=0,by=(0-(-0.897608))/10),0),
                       riground1=c(seq(from=-0.6666667,to=0,by=(0-(-0.6666667))/10),0),
                       riall=c(seq(from=-0.7545604,to=0,by=(0-(-0.7545604))/10),0),
                       Seismic.n=c(1,1,1,1,1,1,1,1,1,1,1,0),
                       Seismic=c("1","1","1","1","1","1","1","1","1","1","1","0"))
  
  newdat$riall.c<-newdat$riall-mean(m2$riall, na.rm=TRUE)
  newdat$riall.q<-newdat$riall.c^2
  newdat$rishrub1.c<-newdat$rishrub1-mean(m2$rishrub1, na.rm=TRUE)
  newdat$rishrub1.q<-newdat$rishrub1.c^2
  newdat$riwoody1.c<-newdat$riwoody1-mean(m2$riwoody1, na.rm=TRUE)
  newdat$riwoody1.q<-newdat$riwoody1.c^2
  newdat$ritree1.c<-newdat$ritree1-mean(m2$ritree1, na.rm=TRUE)
  newdat$ritree1.q<-newdat$ritree1.c^2
  newdat$riground1.c<-newdat$riground1-mean(m2$riground1, na.rm=TRUE)
  newdat$riground1.q<-newdat$riground1.c^2
  
  #Best Model
  dd0 <- model.sel(RIALL.Lin.UNL, 
                   RITREE.Lin.UNL, 
                   RISHRUB.Lin.UNL, 
                   RIGROUND.Lin.UNL,
                   FOREST.UNL, 
                   LINE.UNL, rank=AIC) 
  bestModel<-get.models(dd0, subset = 1)[[1]]
  secondbestModel<-get.models(dd0, subset = 2)[[1]]
  thirdbestModel<-get.models(dd0, subset = 3)[[1]]
  #gets best model in terms of lowest AICc, highest Akaike weight
  #bestModel=RITREE.Lin.UNL; second-best=RIWOODY.Lin.UNL
  
  fits<-predictSE(bestModel, newdata=newdat, type="link", se.fit=TRUE)
  newdat$bestModelFit<-exp(fits$fit)
  newdat$bestModelFitLCL<-exp(fits$fit-1.96*fits$se.fit)
  newdat$bestModelFitUCL<-exp(fits$fit+1.96*fits$se.fit)
  
  newdat$bestModelFitUCL<-ifelse(newdat$bestModelFitUCL=="Inf",10,newdat$bestModelFitUCL)

  p1c<-ggplot(data=newdat, aes(x=riall, y=bestModelFit)) +
    geom_point(aes(x=riall, y=bestModelFit, col=Seismic, shape=Seismic), size=4)+
    geom_line(aes(x=riall, y=bestModelFit, col=Seismic))+
    geom_errorbar(aes(ymin=bestModelFitLCL, ymax=bestModelFitUCL, col=Seismic), width=.075)+
    ylim(0,(1.1*max(newdat$bestModelFitUCL)))+
    labs(x="Recovery Index (All veg.)", y=paste0("Predicted ",i," Count (Unlim.)"))+
    theme_classic(base_family = "serif") +                        #theme_minimal Apply a minimalistic theme with serif font
    theme(axis.title = element_text(size = 24, family = "serif"),  # Increase axis title font size and use serif font
          axis.text = element_text(size = 20, family = "serif"),   # Increase axis label font size and use serif font
          plot.title = element_blank(),
          legend.position = "none")    
  ggsave(p1c, file=paste0("2_outputs/December 2023/",i,"predcountbestmodel_UNL.png"), units="in", width=10, height=8)

  #get coefficients from best model for each species/point count size
  mydataFrame<-data.frame(summary(bestModel)$coefficients)
  mydataFrame$Species<-i
  mydataFrame$PCradius<-"UnlimDist"
  mydataFrame$ModelName<-row.names(dd0)[1]
  mydataFrame$Predictor<-row.names(mydataFrame)
  mydataFrame$AIC<-AIC(bestModel)
  mydataFrame$AICweight<-dd0$weight[1]
  mydataFrame$marginalR2<-r.squaredGLMM(bestModel)[2,1]
  mydataFrame$condR2<-r.squaredGLMM(bestModel)[2,2]
  mydataFrame$LCL<-mydataFrame$Estimate-1.96*mydataFrame$Std..Error
  mydataFrame$UCL<-mydataFrame$Estimate+1.96*mydataFrame$Std..Error
  #reorder data frame
  mydataFrame2<-mydataFrame%>%
    dplyr::select(Species,PCradius,ModelName,Predictor,Estimate,Std..Error,LCL,UCL,z.value,Pr...z..,AIC,AICweight,marginalR2,condR2)
  write.csv(mydataFrame2, file=paste0("2_outputs/December 2023/",i,".UnlimDistbestmodelcoefs.csv"))
  mydataFrame3<-data.frame(dd0)
  write.csv(mydataFrame3, file=paste0("2_outputs/December 2023/",i,".UnlimDistbestmodeltable.csv"))
  
  #get coefficients from second best model for each species/point count size
  mydataFrame<-data.frame(summary(secondbestModel)$coefficients)
  mydataFrame$Species<-i
  mydataFrame$PCradius<-"UnlimDist"
  mydataFrame$ModelName<-row.names(dd0)[2]
  mydataFrame$Predictor<-row.names(mydataFrame)
  mydataFrame$AIC<-AIC(secondbestModel)
  mydataFrame$AICweight<-dd0$weight[2]
  mydataFrame$marginalR2<-r.squaredGLMM(secondbestModel)[2,1]
  mydataFrame$condR2<-r.squaredGLMM(secondbestModel)[2,2]
  mydataFrame$LCL<-mydataFrame$Estimate-1.96*mydataFrame$Std..Error
  mydataFrame$UCL<-mydataFrame$Estimate+1.96*mydataFrame$Std..Error
  #reorder data frame
  mydataFrame2<-mydataFrame%>%
    dplyr::select(Species,PCradius,ModelName,Predictor,Estimate,Std..Error,LCL,UCL,z.value,Pr...z..,AIC,AICweight,marginalR2,condR2)
  write.csv(mydataFrame2, file=paste0("2_outputs/December 2023/",i,".UnlimDistsecondbestModelcoefs.csv"))
  
  #get coefficients from third best model for each species/point count size
  mydataFrame<-data.frame(summary(thirdbestModel)$coefficients)
  mydataFrame$Species<-i
  mydataFrame$PCradius<-"UnlimDist"
  mydataFrame$ModelName<-row.names(dd0)[3]
  mydataFrame$Predictor<-row.names(mydataFrame)
  mydataFrame$AIC<-AIC(thirdbestModel)
  mydataFrame$AICweight<-dd0$weight[3]
  mydataFrame$marginalR2<-r.squaredGLMM(thirdbestModel)[2,1]
  mydataFrame$condR2<-r.squaredGLMM(thirdbestModel)[2,2]
  mydataFrame$LCL<-mydataFrame$Estimate-1.96*mydataFrame$Std..Error
  mydataFrame$UCL<-mydataFrame$Estimate+1.96*mydataFrame$Std..Error
  #reorder data frame
  mydataFrame2<-mydataFrame%>%
    dplyr::select(Species,PCradius,ModelName,Predictor,Estimate,Std..Error,LCL,UCL,z.value,Pr...z..,AIC,AICweight,marginalR2,condR2)
  write.csv(mydataFrame2, file=paste0("2_outputs/December 2023/",i,".UnlimDistthirdbestModelcoefs.csv"))
  
  mpplot2<-grid.arrange(p1a,p1b,p1c,
                       ncol=1,
                       nrow=3)
  ggsave(mpplot2, file=paste0("2_outputs/December 2023/",i,"predseachmodelBestModelEachScale.png"), units="in", width=20, height=24)
  
  print(paste0("Finished analysis for ",i))
  
}

#Upland Species
upland<-c("LEFL")
upland<-c("AMRE","CAWA","OVEN","REVI","WETA")
for (i in upland){
  #50-m analysis
  counts<-read.csv("0_data/1_processed/point counts/50mJoinEverything_MoreLatLong.csv", header=TRUE)
  offsets<-read.csv("0_data/1_processed/point counts/50mJoinEverything_OFF.csv", header=TRUE)
  offsets<-offsets %>%
    rename_with(.fn = function(.x){paste0(.x,"off")}) 
  offsets$PKEY<-offsets$Xoff
  offsets$Xoff<-NULL
  
  m1<-merge(counts, offsets, by=c("PKEY"))
  
  #This file appears to have the PCA scores and RI values needed for bird models.
  vegBird<-read.csv("0_data/1_processed/point counts/vegBirdDataHedwigUsed.csv", header=TRUE)
  vegBird$PKEY<-vegBird$pkey
  vegBird$pkey<-NULL
  vegBirdF<-vegBird%>%
    dplyr::select(PKEY,landtype2,F1all4,F2all4,riall,ritree1,riwoody1,rishrub1,riground1)
  #vegBirdF PKEYs: replace string "HEDW" with string "NWTSLR"
  vegBirdF$PKEY<-gsub("HEDW","NWTSLR",vegBirdF$PKEY)
  
  setdiff(m1$PKEY, vegBirdF$PKEY)#41 PKEYs
  setdiff(vegBirdF$PKEY, m1$PKEY)#34 PKEYs
  
  m2<-merge(m1, vegBirdF, by=c("PKEY"), all.x=TRUE)
  m2<-m2[m2$landtype2=="Upland",]#just use upland point counts
  m2<-m2[!is.na(m2$OBSERVER),]
  
  m2$spp<-m2[,i]
  m2$sppoff<-m2[,paste0(i,"off")]
  mean(m2$spp)
  var(m2$spp)#Poisson error distribution
  m2$Julian.s<-(m2$JULIAN_DAY-mean(m2$JULIAN_DAY))/sd(m2$JULIAN_DAY)
  m2$Time.s<-(m2$Time-mean(m2$Time))/sd(m2$Time)
  
  m2$Seismic<-as.factor(ifelse(m2$Veg_Plot.Type=="Interior",0,1))
  m2$Seismic.n<-ifelse(m2$Veg_Plot.Type=="Interior",0,1)
  m2$riall.c<-m2$riall-mean(m2$riall)
  m2$riall.q<-m2$riall.c^2
  m2$rishrub1.c<-m2$rishrub1-mean(m2$rishrub1)
  m2$rishrub1.q<-m2$rishrub1.c^2
  m2$ritree1.c<-m2$ritree1-mean(m2$ritree1)
  m2$ritree1.q<-m2$ritree1.c^2
  m2$riwoody1.c<-m2$riwoody1-mean(m2$riwoody1)
  m2$riwoody1.q<-m2$riwoody1.c^2
  m2$riground1.c<-m2$riground1-mean(m2$riground1)
  m2$riground1.q<-m2$riground1.c^2
  
  if (var(m2$spp,na.rm=TRUE)/mean(m2$spp,na.rm=TRUE)<2) {
    FOREST.50<-glmer(spp~F1all4+F2all4+Julian.s+Time.s + (1|OBSERVER), data=m2, family=poisson)
    summary(FOREST.50)
    
    LINE.50<-glmer(spp~F1all4+F2all4+Seismic+Julian.s+Time.s + (1|OBSERVER), data=m2, family=poisson)
    summary(LINE.50)
    
    RIALL.Lin.50<-glmer(spp~F1all4+F2all4+Seismic.n+riall+Seismic.n*riall+Julian.s+Time.s + (1|OBSERVER), data=m2, family=poisson)
    summary(RIALL.Lin.50)

    RISHRUB.Lin.50<-glmer(spp~F1all4+F2all4+Seismic.n+rishrub1+Seismic.n*rishrub1+Julian.s+Time.s + (1|OBSERVER), data=m2, family=poisson)
    summary(RISHRUB.Lin.50)

    RITREE.Lin.50<-glmer(spp~F1all4+F2all4+Seismic.n+ritree1+Seismic.n*ritree1+Julian.s+Time.s + (1|OBSERVER), data=m2, family=poisson)
    summary(RITREE.Lin.50)

    RIGROUND.Lin.50<-glmer(spp~F1all4+F2all4+Seismic.n+riground1+Seismic.n*riground1+Julian.s+Time.s + (1|OBSERVER), data=m2, family=poisson)
    summary(RIGROUND.Lin.50)
  }
  
  if (!var(m2$spp,na.rm=TRUE)/mean(m2$spp,na.rm=TRUE)<2) {
    FOREST.50<-glmer.nb(spp~F1all4+F2all4+Julian.s+Time.s + (1|OBSERVER), data=m2)
    summary(FOREST.50)
    
    LINE.50<-glmer.nb(spp~F1all4+F2all4+Seismic+Julian.s+Time.s + (1|OBSERVER), data=m2)
    summary(LINE.50)
    
    RIALL.Lin.50<-glmer.nb(spp~F1all4+F2all4+Seismic.n+riall+Seismic.n*riall+Julian.s+Time.s + (1|OBSERVER), data=m2)
    summary(RIALL.Lin.50)

    RISHRUB.Lin.50<-glmer.nb(spp~F1all4+F2all4+Seismic.n+rishrub1+Seismic.n*rishrub1+Julian.s+Time.s + (1|OBSERVER), data=m2)
    summary(RISHRUB.Lin.50)

    RITREE.Lin.50<-glmer.nb(spp~F1all4+F2all4+Seismic.n+ritree1+Seismic.n*ritree1+Julian.s+Time.s + (1|OBSERVER), data=m2)
    summary(RITREE.Lin.50)

    RIGROUND.Lin.50<-glmer.nb(spp~F1all4+F2all4+Seismic.n+riground1+Seismic.n*riground1+Julian.s+Time.s + (1|OBSERVER), data=m2)
    summary(RIGROUND.Lin.50)
  }
  
  #Get prediction counts from best model when Hedwig is the observer
  newdat <- data.frame(F1all4=mean(m2$F1all4, na.rm=TRUE),#older, taller deciduous forest
                       F2all4=mean(m2$F2all4, na.rm=TRUE),#greater canopy cover, dbh, stem density
                       Julian.s=-0.09831949,#June 15
                       Time.s=-1.232137,#5 AM
                       rishrub1=c(-1,-0.9,-0.8,-0.7,-0.6,-0.5,-0.4,-0.3,-0.2,-0.1,0,0),
                       ritree1=c(seq(from=-0.9744162,to=0,by=(0-(-0.9744162))/10),0),
                       riwoody1=c(seq(from=-0.897608,to=0,by=(0-(-0.897608))/10),0),
                       riground1=c(seq(from=-0.6666667,to=0,by=(0-(-0.6666667))/10),0),
                       riall=c(seq(from=-0.7545604,to=0,by=(0-(-0.7545604))/10),0),
                       Seismic.n=c(1,1,1,1,1,1,1,1,1,1,1,0),
                       Seismic=c("1","1","1","1","1","1","1","1","1","1","1","0"))
  
  newdat$riall.c<-newdat$riall-mean(m2$riall)
  newdat$riall.q<-newdat$riall.c^2
  newdat$rishrub1.c<-newdat$rishrub1-mean(m2$rishrub1)
  newdat$rishrub1.q<-newdat$rishrub1.c^2
  newdat$riwoody1.c<-newdat$riwoody1-mean(m2$riwoody1)
  newdat$riwoody1.q<-newdat$riwoody1.c^2
  newdat$ritree1.c<-newdat$ritree1-mean(m2$ritree1)
  newdat$ritree1.q<-newdat$ritree1.c^2
  newdat$riground1.c<-newdat$riground1-mean(m2$riground1)
  newdat$riground1.q<-newdat$riground1.c^2
  
  #Best Model
  dd0 <- model.sel(RIALL.Lin.50, 
                   RITREE.Lin.50, 
                   RISHRUB.Lin.50, 
                   RIGROUND.Lin.50, 
                   FOREST.50, 
                   LINE.50, rank=AIC) 
  bestModel<-get.models(dd0, subset = 1)[[1]]
  secondbestModel<-get.models(dd0, subset = 2)[[1]]
  thirdbestModel<-get.models(dd0, subset = 3)[[1]]
  #gets best model in terms of lowest AICc, highest Akaike weight

  fits<-predictSE(bestModel, newdata=newdat, type="link", se.fit=TRUE)
  newdat$bestModelFit<-exp(fits$fit)
  newdat$bestModelFitLCL<-exp(fits$fit-1.96*fits$se.fit)
  newdat$bestModelFitUCL<-exp(fits$fit+1.96*fits$se.fit)
  
  newdat$bestModelFitUCL<-ifelse(newdat$bestModelFitUCL=="Inf",10,newdat$bestModelFitUCL)
  
  p1a<-ggplot(data=newdat, aes(x=riall, y=bestModelFit)) +
    geom_point(aes(x=riall, y=bestModelFit, col=Seismic, shape=Seismic), size=4)+
    geom_line(aes(x=riall, y=bestModelFit, col=Seismic))+
    geom_errorbar(aes(ymin=bestModelFitLCL, ymax=bestModelFitUCL, col=Seismic), width=.075)+
    ylim(0,(1.1*max(newdat$bestModelFitUCL)))+
    labs(x="Recovery Index (All veg.)", y=paste0("Predicted ",i," Count (50 m)"))+
    theme_classic(base_family = "serif") +                        #theme_minimal Apply a minimalistic theme with serif font
    theme(axis.title = element_text(size = 24, family = "serif"),  # Increase axis title font size and use serif font
          axis.text = element_text(size = 20, family = "serif"),   # Increase axis label font size and use serif font
          plot.title = element_blank(),
          legend.position="none")    
  ggsave(p1a, file=paste0("2_outputs/December 2023/",i,"predcountbestmodel_50m.png"), units="in", width=10, height=8)
  
  #get coefficients from best model for each species/point count size
  mydataFrame<-data.frame(summary(bestModel)$coefficients)
  mydataFrame$Species<-i
  mydataFrame$PCradius<-50
  mydataFrame$ModelName<-row.names(dd0)[1]
  mydataFrame$Predictor<-row.names(mydataFrame)
  mydataFrame$AIC<-AIC(bestModel)
  mydataFrame$AICweight<-dd0$weight[1]
  mydataFrame$marginalR2<-r.squaredGLMM(bestModel)[2,1]
  mydataFrame$condR2<-r.squaredGLMM(bestModel)[2,2]
  mydataFrame$LCL<-mydataFrame$Estimate-1.96*mydataFrame$Std..Error
  mydataFrame$UCL<-mydataFrame$Estimate+1.96*mydataFrame$Std..Error
  #reorder data frame
  mydataFrame2<-mydataFrame%>%
    dplyr::select(Species,PCradius,ModelName,Predictor,Estimate,Std..Error,LCL,UCL,z.value,Pr...z..,AIC,AICweight,marginalR2,condR2)
  write.csv(mydataFrame2, file=paste0("2_outputs/December 2023/",i,".50mbestmodelcoefs.csv"))
  mydataFrame3<-data.frame(dd0)  
  write.csv(mydataFrame3, file=paste0("2_outputs/December 2023/",i,".50mbestmodeltable.csv"))
  
  #get coefficients from second best model for each species/point count size
  mydataFrame<-data.frame(summary(secondbestModel)$coefficients)
  mydataFrame$Species<-i
  mydataFrame$PCradius<-50
  mydataFrame$ModelName<-row.names(dd0)[2]
  mydataFrame$Predictor<-row.names(mydataFrame)
  mydataFrame$AIC<-AIC(secondbestModel)
  mydataFrame$AICweight<-dd0$weight[2]
  mydataFrame$marginalR2<-r.squaredGLMM(secondbestModel)[2,1]
  mydataFrame$condR2<-r.squaredGLMM(secondbestModel)[2,2]
  mydataFrame$LCL<-mydataFrame$Estimate-1.96*mydataFrame$Std..Error
  mydataFrame$UCL<-mydataFrame$Estimate+1.96*mydataFrame$Std..Error
  #reorder data frame
  mydataFrame2<-mydataFrame%>%
    dplyr::select(Species,PCradius,ModelName,Predictor,Estimate,Std..Error,LCL,UCL,z.value,Pr...z..,AIC,AICweight,marginalR2,condR2)
  write.csv(mydataFrame2, file=paste0("2_outputs/December 2023/",i,".50msecondbestModelcoefs.csv"))
  
  #get coefficients from third best model for each species/point count size
  mydataFrame<-data.frame(summary(thirdbestModel)$coefficients)
  mydataFrame$Species<-i
  mydataFrame$PCradius<-50
  mydataFrame$ModelName<-row.names(dd0)[3]
  mydataFrame$Predictor<-row.names(mydataFrame)
  mydataFrame$AIC<-AIC(thirdbestModel)
  mydataFrame$AICweight<-dd0$weight[3]
  mydataFrame$marginalR2<-r.squaredGLMM(thirdbestModel)[2,1]
  mydataFrame$condR2<-r.squaredGLMM(thirdbestModel)[2,2]
  mydataFrame$LCL<-mydataFrame$Estimate-1.96*mydataFrame$Std..Error
  mydataFrame$UCL<-mydataFrame$Estimate+1.96*mydataFrame$Std..Error
  #reorder data frame
  mydataFrame2<-mydataFrame%>%
    dplyr::select(Species,PCradius,ModelName,Predictor,Estimate,Std..Error,LCL,UCL,z.value,Pr...z..,AIC,AICweight,marginalR2,condR2)
  write.csv(mydataFrame2, file=paste0("2_outputs/December 2023/",i,".50mthirdbestModelcoefs.csv"))
  
  print(paste0("Starting 100-m models for ",i))

  #100-m analysis
  counts<-read.csv("0_data/1_processed/point counts/100mJoinEverything_MoreLatLong.csv", header=TRUE)
  offsets<-read.csv("0_data/1_processed/point counts/100mJoinEverything_OFF.csv", header=TRUE)
  offsets<-offsets %>%
    rename_with(.fn = function(.x){paste0(.x,"off")}) 
  offsets$PKEY<-offsets$Xoff
  offsets$Xoff<-NULL
  
  m1<-merge(counts, offsets, by=c("PKEY"))
  
  vegBird<-read.csv("0_data/1_processed/point counts/vegBirdDataHedwigUsed.csv", header=TRUE)
  vegBird$PKEY<-vegBird$pkey
  vegBird$pkey<-NULL
  vegBirdF<-vegBird%>%
    dplyr::select(PKEY,landtype2,F1all4,F2all4,riall,ritree1,riwoody1,rishrub1,riground1)
  #vegBirdF PKEYs: replace string "HEDW" with string "NWTSLR"
  vegBirdF$PKEY<-gsub("HEDW","NWTSLR",vegBirdF$PKEY)
  m2<-merge(m1, vegBirdF, by=c("PKEY"), all.x=TRUE)
  m2<-m2[m2$landtype2=="Upland",]#just use upland point counts
  m2<-m2[!is.na(m2$OBSERVER),]
  m2$OBSERVER<-as.factor(m2$OBSERVER)
  
  m2$spp<-m2[,i]
  m2$sppoff<-m2[,paste0(i,"off")]
  mean(m2$spp)
  var(m2$spp)#Poisson error distribution (except for LEFL)
  m2$Julian.s<-(m2$JULIAN_DAY-mean(m2$JULIAN_DAY))/sd(m2$JULIAN_DAY)
  m2$Time.s<-(m2$Time-mean(m2$Time))/sd(m2$Time)
  
  m2$Seismic<-as.factor(ifelse(m2$Veg_Plot.Type=="Interior",0,1))
  m2$Seismic.n<-ifelse(m2$Veg_Plot.Type=="Interior",0,1)
  m2$riall.c<-m2$riall-mean(m2$riall)
  m2$riall.q<-m2$riall.c^2
  m2$rishrub1.c<-m2$rishrub1-mean(m2$rishrub1)
  m2$rishrub1.q<-m2$rishrub1.c^2
  m2$ritree1.c<-m2$ritree1-mean(m2$ritree1)
  m2$ritree1.q<-m2$ritree1.c^2
  m2$riwoody1.c<-m2$riwoody1-mean(m2$riwoody1)
  m2$riwoody1.q<-m2$riwoody1.c^2
  m2$riground1.c<-m2$riground1-mean(m2$riground1)
  m2$riground1.q<-m2$riground1.c^2
  
  if (var(m2$spp,na.rm=TRUE)/mean(m2$spp,na.rm=TRUE)<2) {
    FOREST.100<-glmer(spp~F1all4+F2all4+Julian.s+Time.s + (1|OBSERVER), data=m2, family=poisson)
    summary(FOREST.100)
    
    LINE.100<-glmer(spp~F1all4+F2all4+Seismic+Julian.s+Time.s + (1|OBSERVER), data=m2, family=poisson)
    summary(LINE.100)
    
    RIALL.Lin.100<-glmer(spp~F1all4+F2all4+Seismic.n+riall+Seismic.n*riall+Julian.s+Time.s + (1|OBSERVER), data=m2, family=poisson)
    summary(RIALL.Lin.100)

    RISHRUB.Lin.100<-glmer(spp~F1all4+F2all4+Seismic.n+rishrub1+Seismic.n*rishrub1+Julian.s+Time.s + (1|OBSERVER), data=m2, family=poisson)
    summary(RISHRUB.Lin.100)

    RITREE.Lin.100<-glmer(spp~F1all4+F2all4+Seismic.n+ritree1+Seismic.n*ritree1+Julian.s+Time.s + (1|OBSERVER), data=m2, family=poisson)
    summary(RITREE.Lin.100)

    RIGROUND.Lin.100<-glmer(spp~F1all4+F2all4+Seismic.n+riground1+Seismic.n*riground1+Julian.s+Time.s + (1|OBSERVER), data=m2, family=poisson)
    summary(RIGROUND.Lin.100)
  }
  
  if (!var(m2$spp,na.rm=TRUE)/mean(m2$spp,na.rm=TRUE)<2) {
    FOREST.100<-glmer.nb(spp~F1all4+F2all4+Julian.s+Time.s + (1|OBSERVER), data=m2)
    summary(FOREST.100)
    
    LINE.100<-glmer.nb(spp~F1all4+F2all4+Seismic+Julian.s+Time.s + (1|OBSERVER), data=m2)
    summary(LINE.100)
    
    RIALL.Lin.100<-glmer.nb(spp~F1all4+F2all4+Seismic.n+riall+Seismic.n*riall+Julian.s+Time.s + (1|OBSERVER), data=m2)
    summary(RIALL.Lin.100)

    RISHRUB.Lin.100<-glmer.nb(spp~F1all4+F2all4+Seismic.n+rishrub1+Seismic.n*rishrub1+Julian.s+Time.s + (1|OBSERVER), data=m2)
    summary(RISHRUB.Lin.100)

    RITREE.Lin.100<-glmer.nb(spp~F1all4+F2all4+Seismic.n+ritree1+Seismic.n*ritree1+Julian.s+Time.s + (1|OBSERVER), data=m2)
    summary(RITREE.Lin.100)

    RIGROUND.Lin.100<-glmer.nb(spp~F1all4+F2all4+Seismic.n+riground1+Seismic.n*riground1+Julian.s+Time.s + (1|OBSERVER), data=m2)
    summary(RIGROUND.Lin.100)
  }
  
  #Get prediction counts from best model when Hedwig is the observer
  newdat <- data.frame(F1all4=mean(m2$F1all4, na.rm=TRUE),#older, taller deciduous forest
                       F2all4=mean(m2$F2all4, na.rm=TRUE),#greater canopy cover, dbh, stem density
                       Julian.s=-0.09831949,#June 15
                       Time.s=-1.232137,#5 AM
                       rishrub1=c(-1,-0.9,-0.8,-0.7,-0.6,-0.5,-0.4,-0.3,-0.2,-0.1,0,0),
                       ritree1=c(seq(from=-0.9744162,to=0,by=(0-(-0.9744162))/10),0),
                       riwoody1=c(seq(from=-0.897608,to=0,by=(0-(-0.897608))/10),0),
                       riground1=c(seq(from=-0.6666667,to=0,by=(0-(-0.6666667))/10),0),
                       riall=c(seq(from=-0.7545604,to=0,by=(0-(-0.7545604))/10),0),
                       Seismic.n=c(1,1,1,1,1,1,1,1,1,1,1,0),
                       Seismic=c("1","1","1","1","1","1","1","1","1","1","1","0"))
  
  newdat$riall.c<-newdat$riall-mean(m2$riall)
  newdat$riall.q<-newdat$riall.c^2
  newdat$rishrub1.c<-newdat$rishrub1-mean(m2$rishrub1)
  newdat$rishrub1.q<-newdat$rishrub1.c^2
  newdat$riwoody1.c<-newdat$riwoody1-mean(m2$riwoody1)
  newdat$riwoody1.q<-newdat$riwoody1.c^2
  newdat$ritree1.c<-newdat$ritree1-mean(m2$ritree1)
  newdat$ritree1.q<-newdat$ritree1.c^2
  newdat$riground1.c<-newdat$riground1-mean(m2$riground1)
  newdat$riground1.q<-newdat$riground1.c^2
  
  #Best Model
  dd0 <- model.sel(RIALL.Lin.100, 
                   RITREE.Lin.100, 
                   RISHRUB.Lin.100, 
                   RIGROUND.Lin.100,
                   FOREST.100, 
                   LINE.100, rank=AIC) 
  bestModel<-get.models(dd0, subset = 1)[[1]]
  secondbestModel<-get.models(dd0, subset = 2)[[1]]
  thirdbestModel<-get.models(dd0, subset = 3)[[1]]
  #gets best model in terms of lowest AICc, highest Akaike weight

  fits<-predictSE(bestModel, newdata=newdat, type="link", se.fit=TRUE)
  newdat$bestModelFit<-exp(fits$fit)
  newdat$bestModelFitLCL<-exp(fits$fit-1.96*fits$se.fit)
  newdat$bestModelFitUCL<-exp(fits$fit+1.96*fits$se.fit)
  
  newdat$bestModelFitUCL<-ifelse(newdat$bestModelFitUCL=="Inf",10,newdat$bestModelFitUCL)
  
  p1b<-ggplot(data=newdat, aes(x=riall, y=bestModelFit)) +
    geom_point(aes(x=riall, y=bestModelFit, col=Seismic, shape=Seismic), size=4)+
    geom_line(aes(x=riall, y=bestModelFit, col=Seismic))+
    geom_errorbar(aes(ymin=bestModelFitLCL, ymax=bestModelFitUCL, col=Seismic), width=.075)+
    ylim(0,(1.1*max(newdat$bestModelFitUCL)))+
    labs(x="Recovery Index (All veg.)", y=paste0("Predicted ",i," Count (100 m)"))+
    theme_classic(base_family = "serif") +                        #theme_minimal Apply a minimalistic theme with serif font
    theme(axis.title = element_text(size = 24, family = "serif"),  # Increase axis title font size and use serif font
          axis.text = element_text(size = 20, family = "serif"),   # Increase axis label font size and use serif font
          plot.title = element_blank(),
          legend.position="none")    
  ggsave(p1b, file=paste0("2_outputs/December 2023/",i,"predcountbestmodel_100m.png"), units="in", width=10, height=8)
  
  
  #get coefficients from best model for each species/point count size
  mydataFrame<-data.frame(summary(bestModel)$coefficients)
  mydataFrame$Species<-i
  mydataFrame$PCradius<-100
  mydataFrame$ModelName<-row.names(dd0)[1]
  mydataFrame$Predictor<-row.names(mydataFrame)
  mydataFrame$AIC<-AIC(bestModel)
  mydataFrame$AICweight<-dd0$weight[1]
  mydataFrame$marginalR2<-r.squaredGLMM(bestModel)[2,1]
  mydataFrame$condR2<-r.squaredGLMM(bestModel)[2,2]
  mydataFrame$LCL<-mydataFrame$Estimate-1.96*mydataFrame$Std..Error
  mydataFrame$UCL<-mydataFrame$Estimate+1.96*mydataFrame$Std..Error
  #reorder data frame
  mydataFrame2<-mydataFrame%>%
    dplyr::select(Species,PCradius,ModelName,Predictor,Estimate,Std..Error,LCL,UCL,z.value,Pr...z..,AIC,AICweight,marginalR2,condR2)
  write.csv(mydataFrame2, file=paste0("2_outputs/December 2023/",i,".100mbestmodelcoefs.csv"))
  mydataFrame3<-data.frame(dd0)
  write.csv(mydataFrame3, file=paste0("2_outputs/December 2023/",i,".100mbestmodeltable.csv"))
  
  #get coefficients from second best model for each species/point count size
  mydataFrame<-data.frame(summary(secondbestModel)$coefficients)
  mydataFrame$Species<-i
  mydataFrame$PCradius<-100
  mydataFrame$ModelName<-row.names(dd0)[2]
  mydataFrame$Predictor<-row.names(mydataFrame)
  mydataFrame$AIC<-AIC(secondbestModel)
  mydataFrame$AICweight<-dd0$weight[2]
  mydataFrame$marginalR2<-r.squaredGLMM(secondbestModel)[2,1]
  mydataFrame$condR2<-r.squaredGLMM(secondbestModel)[2,2]
  mydataFrame$LCL<-mydataFrame$Estimate-1.96*mydataFrame$Std..Error
  mydataFrame$UCL<-mydataFrame$Estimate+1.96*mydataFrame$Std..Error
  #reorder data frame
  mydataFrame2<-mydataFrame%>%
    dplyr::select(Species,PCradius,ModelName,Predictor,Estimate,Std..Error,LCL,UCL,z.value,Pr...z..,AIC,AICweight,marginalR2,condR2)
  write.csv(mydataFrame2, file=paste0("2_outputs/December 2023/",i,".100msecondbestModelcoefs.csv"))
  
  #get coefficients from third best model for each species/point count size
  mydataFrame<-data.frame(summary(thirdbestModel)$coefficients)
  mydataFrame$Species<-i
  mydataFrame$PCradius<-100
  mydataFrame$ModelName<-row.names(dd0)[3]
  mydataFrame$Predictor<-row.names(mydataFrame)
  mydataFrame$AIC<-AIC(thirdbestModel)
  mydataFrame$AICweight<-dd0$weight[3]
  mydataFrame$marginalR2<-r.squaredGLMM(thirdbestModel)[2,1]
  mydataFrame$condR2<-r.squaredGLMM(thirdbestModel)[2,2]
  mydataFrame$LCL<-mydataFrame$Estimate-1.96*mydataFrame$Std..Error
  mydataFrame$UCL<-mydataFrame$Estimate+1.96*mydataFrame$Std..Error
  #reorder data frame
  mydataFrame2<-mydataFrame%>%
    dplyr::select(Species,PCradius,ModelName,Predictor,Estimate,Std..Error,LCL,UCL,z.value,Pr...z..,AIC,AICweight,marginalR2,condR2)
  write.csv(mydataFrame2, file=paste0("2_outputs/December 2023/",i,".100mthirdbestModelcoefs.csv"))
  
  print(paste0("Starting unlimited-distance models for ",i))
  
  #Unlimited distance analysis
  counts<-read.csv("0_data/1_processed/point counts/UnlimJoinEverything_MoreLatLong.csv", header=TRUE)
  offsets<-read.csv("0_data/1_processed/point counts/UnlimJoinEverything_OFF.csv", header=TRUE)
  offsets<-offsets %>%
    rename_with(.fn = function(.x){paste0(.x,"off")}) 
  offsets$PKEY<-offsets$Xoff
  offsets$Xoff<-NULL
  
  m1<-merge(counts, offsets, by=c("PKEY"))#, by=c("PKEY")
  vegBird<-read.csv("0_data/1_processed/point counts/vegBirdDataHedwigUsed.csv", header=TRUE)
  vegBird$PKEY<-vegBird$pkey
  vegBird$pkey<-NULL
  vegBirdF<-vegBird%>%
    dplyr::select(PKEY,landtype2,F1all4,F2all4,riall,ritree1,riwoody1,rishrub1,riground1)
  #vegBirdF PKEYs: replace string "HEDW" with string "NWTSLR"
  vegBirdF$PKEY<-gsub("HEDW","NWTSLR",vegBirdF$PKEY)
  m2<-merge(m1, vegBirdF, by=c("PKEY"), all.x=TRUE)
  m2<-m2[m2$landtype2=="Upland",]#just use upland point counts
  m2<-m2[!is.na(m2$OBSERVER),]
  
  m2$spp<-m2[,i]
  m2$sppoff<-m2[,paste0(i,"off")]
  mean(m2$spp)
  var(m2$spp)#Poisson error distribution (except for LEFL)
  m2$Julian.s<-(m2$JULIAN_DAY-mean(m2$JULIAN_DAY))/sd(m2$JULIAN_DAY)
  m2$Time.s<-(m2$Time-mean(m2$Time))/sd(m2$Time)
  
  m2$Seismic<-as.factor(ifelse(m2$Veg_Plot.Type=="Interior",0,1))
  m2$Seismic.n<-ifelse(m2$Veg_Plot.Type=="Interior",0,1)
  m2$riall.c<-m2$riall-mean(m2$riall)
  m2$riall.q<-m2$riall.c^2
  m2$rishrub1.c<-m2$rishrub1-mean(m2$rishrub1)
  m2$rishrub1.q<-m2$rishrub1.c^2
  m2$ritree1.c<-m2$ritree1-mean(m2$ritree1)
  m2$ritree1.q<-m2$ritree1.c^2
  m2$riwoody1.c<-m2$riwoody1-mean(m2$riwoody1)
  m2$riwoody1.q<-m2$riwoody1.c^2
  m2$riground1.c<-m2$riground1-mean(m2$riground1)
  m2$riground1.q<-m2$riground1.c^2
  
  if (var(m2$spp,na.rm=TRUE)/mean(m2$spp,na.rm=TRUE)<2) {
    FOREST.UNL<-glmer(spp~F1all4+F2all4+Julian.s+Time.s + (1|OBSERVER), data=m2, family=poisson)
    summary(FOREST.UNL)
    
    LINE.UNL<-glmer(spp~F1all4+F2all4+Seismic+Julian.s+Time.s + (1|OBSERVER), data=m2, family=poisson)
    summary(LINE.UNL)
    
    RIALL.Lin.UNL<-glmer(spp~F1all4+F2all4+Seismic.n+riall+Seismic.n*riall+Julian.s+Time.s + (1|OBSERVER), data=m2, family=poisson)
    summary(RIALL.Lin.UNL)

    RISHRUB.Lin.UNL<-glmer(spp~F1all4+F2all4+Seismic.n+rishrub1+Seismic.n*rishrub1+Julian.s+Time.s + (1|OBSERVER), data=m2, family=poisson)
    summary(RISHRUB.Lin.UNL)

    RITREE.Lin.UNL<-glmer(spp~F1all4+F2all4+Seismic.n+ritree1+Seismic.n*ritree1+Julian.s+Time.s + (1|OBSERVER), data=m2, family=poisson)
    summary(RITREE.Lin.UNL)

    RIGROUND.Lin.UNL<-glmer(spp~F1all4+F2all4+Seismic.n+riground1+Seismic.n*riground1+Julian.s+Time.s + (1|OBSERVER), data=m2, family=poisson)
    summary(RIGROUND.Lin.UNL)
  }
  
  if (!var(m2$spp,na.rm=TRUE)/mean(m2$spp,na.rm=TRUE)<2) {
    FOREST.UNL<-glmer.nb(spp~F1all4+F2all4+Julian.s+Time.s + (1|OBSERVER), data=m2)
    summary(FOREST.UNL)
    
    LINE.UNL<-glmer.nb(spp~F1all4+F2all4+Seismic+Julian.s+Time.s + (1|OBSERVER), data=m2)
    summary(LINE.UNL)
    
    RIALL.Lin.UNL<-glmer.nb(spp~F1all4+F2all4+Seismic.n+riall+Seismic.n*riall+Julian.s+Time.s + (1|OBSERVER), data=m2)
    summary(RIALL.Lin.UNL)

    RISHRUB.Lin.UNL<-glmer.nb(spp~F1all4+F2all4+Seismic.n+rishrub1+Seismic.n*rishrub1+Julian.s+Time.s + (1|OBSERVER), data=m2)
    summary(RISHRUB.Lin.UNL)

    RITREE.Lin.UNL<-glmer.nb(spp~F1all4+F2all4+Seismic.n+ritree1+Seismic.n*ritree1+Julian.s+Time.s + (1|OBSERVER), data=m2)
    summary(RITREE.Lin.UNL)

    RIGROUND.Lin.UNL<-glmer.nb(spp~F1all4+F2all4+Seismic.n+riground1+Seismic.n*riground1+Julian.s+Time.s + (1|OBSERVER), data=m2)
    summary(RIGROUND.Lin.UNL)
  }
  
  #Get prediction counts from best model when Hedwig is the observer
  newdat <- data.frame(F1all4=mean(m2$F1all4, na.rm=TRUE),#older, taller deciduous forest
                       F2all4=mean(m2$F2all4, na.rm=TRUE),#greater canopy cover, dbh, stem density
                       Julian.s=-0.09831949,#June 15
                       Time.s=-1.232137,#5 AM
                       rishrub1=c(-1,-0.9,-0.8,-0.7,-0.6,-0.5,-0.4,-0.3,-0.2,-0.1,0,0),
                       ritree1=c(seq(from=-0.9744162,to=0,by=(0-(-0.9744162))/10),0),
                       riwoody1=c(seq(from=-0.897608,to=0,by=(0-(-0.897608))/10),0),
                       riground1=c(seq(from=-0.6666667,to=0,by=(0-(-0.6666667))/10),0),
                       riall=c(seq(from=-0.7545604,to=0,by=(0-(-0.7545604))/10),0),
                       Seismic.n=c(1,1,1,1,1,1,1,1,1,1,1,0),
                       Seismic=c("1","1","1","1","1","1","1","1","1","1","1","0"))
  
  newdat$riall.c<-newdat$riall-mean(m2$riall)
  newdat$riall.q<-newdat$riall.c^2
  newdat$rishrub1.c<-newdat$rishrub1-mean(m2$rishrub1)
  newdat$rishrub1.q<-newdat$rishrub1.c^2
  newdat$riwoody1.c<-newdat$riwoody1-mean(m2$riwoody1)
  newdat$riwoody1.q<-newdat$riwoody1.c^2
  newdat$ritree1.c<-newdat$ritree1-mean(m2$ritree1)
  newdat$ritree1.q<-newdat$ritree1.c^2
  newdat$riground1.c<-newdat$riground1-mean(m2$riground1)
  newdat$riground1.q<-newdat$riground1.c^2
  
  #Best Model
  dd0 <- model.sel(RIALL.Lin.UNL, 
                   RITREE.Lin.UNL, 
                   RISHRUB.Lin.UNL, 
                   RIGROUND.Lin.UNL, 
                   FOREST.UNL, 
                   LINE.UNL, rank=AIC) 
  bestModel<-get.models(dd0, subset = 1)[[1]]
  secondbestModel<-get.models(dd0, subset = 2)[[1]]
  thirdbestModel<-get.models(dd0, subset = 3)[[1]]
  #gets best model in terms of lowest AICc, highest Akaike weight
  #bestModel=RITREE.Lin.UNL; second-best=RIWOODY.Lin.UNL
  
  fits<-predictSE(bestModel, newdata=newdat, type="link", se.fit=TRUE)
  newdat$bestModelFit<-exp(fits$fit)
  newdat$bestModelFitLCL<-exp(fits$fit-1.96*fits$se.fit)
  newdat$bestModelFitUCL<-exp(fits$fit+1.96*fits$se.fit)
  
  newdat$bestModelFitUCL<-ifelse(newdat$bestModelFitUCL=="Inf",10,newdat$bestModelFitUCL)
  
  p1c<-ggplot(data=newdat, aes(x=riall, y=bestModelFit)) +
    geom_point(aes(x=riall, y=bestModelFit, col=Seismic, shape=Seismic), size=4)+
    geom_line(aes(x=riall, y=bestModelFit, col=Seismic))+
    geom_errorbar(aes(ymin=bestModelFitLCL, ymax=bestModelFitUCL, col=Seismic), width=.075)+
    ylim(0,(1.1*max(newdat$bestModelFitUCL)))+
    labs(x="Recovery Index (All veg.)", y=paste0("Predicted ",i," Count (Unlim.)"))+
    theme_classic(base_family = "serif") +                        #theme_minimal Apply a minimalistic theme with serif font
    theme(axis.title = element_text(size = 24, family = "serif"),  # Increase axis title font size and use serif font
          axis.text = element_text(size = 20, family = "serif"),   # Increase axis label font size and use serif font
          plot.title = element_blank(),
          legend.position="none")    
  ggsave(p1c, file=paste0("2_outputs/December 2023/",i,"predcountbestmodel_UNL.png"), units="in", width=10, height=8)
  
  #get coefficients from best model for each species/point count size
  mydataFrame<-data.frame(summary(bestModel)$coefficients)
  mydataFrame$Species<-i
  mydataFrame$PCradius<-"UnlimDist"
  mydataFrame$ModelName<-row.names(dd0)[1]
  mydataFrame$Predictor<-row.names(mydataFrame)
  mydataFrame$AIC<-AIC(bestModel)
  mydataFrame$AICweight<-dd0$weight[1]
  mydataFrame$marginalR2<-r.squaredGLMM(bestModel)[2,1]
  mydataFrame$condR2<-r.squaredGLMM(bestModel)[2,2]
  mydataFrame$LCL<-mydataFrame$Estimate-1.96*mydataFrame$Std..Error
  mydataFrame$UCL<-mydataFrame$Estimate+1.96*mydataFrame$Std..Error
  #reorder data frame
  mydataFrame2<-mydataFrame%>%
    dplyr::select(Species,PCradius,ModelName,Predictor,Estimate,Std..Error,LCL,UCL,z.value,Pr...z..,AIC,AICweight,marginalR2,condR2)
  write.csv(mydataFrame2, file=paste0("2_outputs/December 2023/",i,".UnlimDistbestmodelcoefs.csv"))
  mydataFrame3<-data.frame(dd0)
  write.csv(mydataFrame3, file=paste0("2_outputs/December 2023/",i,".UnlimDistbestmodeltable.csv"))
  
  #get coefficients from second best model for each species/point count size
  mydataFrame<-data.frame(summary(secondbestModel)$coefficients)
  mydataFrame$Species<-i
  mydataFrame$PCradius<-"UnlimDist"
  mydataFrame$ModelName<-row.names(dd0)[2]
  mydataFrame$Predictor<-row.names(mydataFrame)
  mydataFrame$AIC<-AIC(secondbestModel)
  mydataFrame$AICweight<-dd0$weight[2]
  mydataFrame$marginalR2<-r.squaredGLMM(secondbestModel)[2,1]
  mydataFrame$condR2<-r.squaredGLMM(secondbestModel)[2,2]
  mydataFrame$LCL<-mydataFrame$Estimate-1.96*mydataFrame$Std..Error
  mydataFrame$UCL<-mydataFrame$Estimate+1.96*mydataFrame$Std..Error
  #reorder data frame
  mydataFrame2<-mydataFrame%>%
    dplyr::select(Species,PCradius,ModelName,Predictor,Estimate,Std..Error,LCL,UCL,z.value,Pr...z..,AIC,AICweight,marginalR2,condR2)
  write.csv(mydataFrame2, file=paste0("2_outputs/December 2023/",i,".UnlimDistsecondbestModelcoefs.csv"))
  
  #get coefficients from third best model for each species/point count size
  mydataFrame<-data.frame(summary(thirdbestModel)$coefficients)
  mydataFrame$Species<-i
  mydataFrame$PCradius<-"UnlimDist"
  mydataFrame$ModelName<-row.names(dd0)[3]
  mydataFrame$Predictor<-row.names(mydataFrame)
  mydataFrame$AIC<-AIC(thirdbestModel)
  mydataFrame$AICweight<-dd0$weight[3]
  mydataFrame$marginalR2<-r.squaredGLMM(thirdbestModel)[2,1]
  mydataFrame$condR2<-r.squaredGLMM(thirdbestModel)[2,2]
  mydataFrame$LCL<-mydataFrame$Estimate-1.96*mydataFrame$Std..Error
  mydataFrame$UCL<-mydataFrame$Estimate+1.96*mydataFrame$Std..Error
  #reorder data frame
  mydataFrame2<-mydataFrame%>%
    dplyr::select(Species,PCradius,ModelName,Predictor,Estimate,Std..Error,LCL,UCL,z.value,Pr...z..,AIC,AICweight,marginalR2,condR2)
  write.csv(mydataFrame2, file=paste0("2_outputs/December 2023/",i,".UnlimDistthirdbestModelcoefs.csv"))
  
  mpplot2<-grid.arrange(p1a,p1b,p1c,
                        ncol=1,
                        nrow=3)
  ggsave(mpplot2, file=paste0("2_outputs/December 2023/",i,"predseachmodelBestModelEachScale.png"), units="in", width=20, height=24)
  
  print(paste0("Finished analysis for ",i))
  
}


#Lowland Species
lowland<-c("YBFL")
lowland<-c("ALFL","DEJU","FOSP","HETH","LISP","PAWA","RCKI","YBFL")
for (i in lowland){
  #50-m analysis
  counts<-read.csv("0_data/1_processed/point counts/50mJoinEverything_MoreLatLong.csv", header=TRUE)
  offsets<-read.csv("0_data/1_processed/point counts/50mJoinEverything_OFF.csv", header=TRUE)
  offsets<-offsets %>%
    rename_with(.fn = function(.x){paste0(.x,"off")}) 
  offsets$PKEY<-offsets$Xoff
  offsets$Xoff<-NULL
  
  m1<-merge(counts, offsets, by=c("PKEY"))
  
  #This file appears to have the PCA scores and RI values needed for bird models.
  vegBird<-read.csv("0_data/1_processed/point counts/vegBirdDataHedwigUsed.csv", header=TRUE)
  vegBird$PKEY<-vegBird$pkey
  vegBird$pkey<-NULL
  vegBirdF<-vegBird%>%
    dplyr::select(PKEY,landtype2,F1all4,F2all4,riall,ritree1,riwoody1,rishrub1,riground1)
  #vegBirdF PKEYs: replace string "HEDW" with string "NWTSLR"
  vegBirdF$PKEY<-gsub("HEDW","NWTSLR",vegBirdF$PKEY)
  
  setdiff(m1$PKEY, vegBirdF$PKEY)#41 PKEYs
  setdiff(vegBirdF$PKEY, m1$PKEY)#34 PKEYs
  
  m2<-merge(m1, vegBirdF, by=c("PKEY"), all.x=TRUE)
  m2<-m2[m2$landtype2=="Lowland",]#just use lowland point counts
  m2<-m2[!is.na(m2$OBSERVER),]
  m2$spp<-m2[,i]
  m2$sppoff<-m2[,paste0(i,"off")]
  mean(m2$spp)
  var(m2$spp)#Poisson error distribution
  m2$Julian.s<-(m2$JULIAN_DAY-mean(m2$JULIAN_DAY))/sd(m2$JULIAN_DAY)
  m2$Time.s<-(m2$Time-mean(m2$Time))/sd(m2$Time)
  
  m2$Seismic<-as.factor(ifelse(m2$Veg_Plot.Type=="Interior",0,1))
  m2$Seismic.n<-ifelse(m2$Veg_Plot.Type=="Interior",0,1)
  m2$riall.c<-m2$riall-mean(m2$riall)
  m2$riall.q<-m2$riall.c^2
  m2$rishrub1.c<-m2$rishrub1-mean(m2$rishrub1)
  m2$rishrub1.q<-m2$rishrub1.c^2
  m2$ritree1.c<-m2$ritree1-mean(m2$ritree1)
  m2$ritree1.q<-m2$ritree1.c^2
  m2$riwoody1.c<-m2$riwoody1-mean(m2$riwoody1)
  m2$riwoody1.q<-m2$riwoody1.c^2
  m2$riground1.c<-m2$riground1-mean(m2$riground1)
  m2$riground1.q<-m2$riground1.c^2
  
  if (var(m2$spp,na.rm=TRUE)/mean(m2$spp,na.rm=TRUE)<2) {
    FOREST.50<-glmer(spp~F1all4+F2all4+Julian.s+Time.s + (1|OBSERVER), data=m2, family=poisson)
    summary(FOREST.50)
    
    LINE.50<-glmer(spp~F1all4+F2all4+Seismic+Julian.s+Time.s + (1|OBSERVER), data=m2, family=poisson)
    summary(LINE.50)
    
    RIALL.Lin.50<-glmer(spp~F1all4+F2all4+Seismic.n+riall+Seismic.n*riall+Julian.s+Time.s + (1|OBSERVER), data=m2, family=poisson)
    summary(RIALL.Lin.50)

    RISHRUB.Lin.50<-glmer(spp~F1all4+F2all4+Seismic.n+rishrub1+Seismic.n*rishrub1+Julian.s+Time.s + (1|OBSERVER), data=m2, family=poisson)
    summary(RISHRUB.Lin.50)

    RITREE.Lin.50<-glmer(spp~F1all4+F2all4+Seismic.n+ritree1+Seismic.n*ritree1+Julian.s+Time.s + (1|OBSERVER), data=m2, family=poisson)
    summary(RITREE.Lin.50)

    RIGROUND.Lin.50<-glmer(spp~F1all4+F2all4+Seismic.n+riground1+Seismic.n*riground1+Julian.s+Time.s + (1|OBSERVER), data=m2, family=poisson)
    summary(RIGROUND.Lin.50)
  }
  
  if (!var(m2$spp,na.rm=TRUE)/mean(m2$spp,na.rm=TRUE)<2) {
    FOREST.50<-glmer.nb(spp~F1all4+F2all4+Julian.s+Time.s + (1|OBSERVER), data=m2)
    summary(FOREST.50)
    
    LINE.50<-glmer.nb(spp~F1all4+F2all4+Seismic+Julian.s+Time.s + (1|OBSERVER), data=m2)
    summary(LINE.50)
    
    RIALL.Lin.50<-glmer.nb(spp~F1all4+F2all4+Seismic.n+riall+Seismic.n*riall+Julian.s+Time.s + (1|OBSERVER), data=m2)
    summary(RIALL.Lin.50)

    RISHRUB.Lin.50<-glmer.nb(spp~F1all4+F2all4+Seismic.n+rishrub1+Seismic.n*rishrub1+Julian.s+Time.s + (1|OBSERVER), data=m2)
    summary(RISHRUB.Lin.50)

    RITREE.Lin.50<-glmer.nb(spp~F1all4+F2all4+Seismic.n+ritree1+Seismic.n*ritree1+Julian.s+Time.s + (1|OBSERVER), data=m2)
    summary(RITREE.Lin.50)

    RIGROUND.Lin.50<-glmer.nb(spp~F1all4+F2all4+Seismic.n+riground1+Seismic.n*riground1+Julian.s+Time.s + (1|OBSERVER), data=m2)
    summary(RIGROUND.Lin.50)

  }
  
  #Get prediction counts from best model when Hedwig is the observer
  newdat <- data.frame(F1all4=mean(m2$F1all4, na.rm=TRUE),#older, taller deciduous forest
                       F2all4=mean(m2$F2all4, na.rm=TRUE),#greater canopy cover, dbh, stem density
                       Julian.s=-0.09831949,#June 15
                       Time.s=-1.232137,#5 AM
                       rishrub1=c(-1,-0.9,-0.8,-0.7,-0.6,-0.5,-0.4,-0.3,-0.2,-0.1,0,0),
                       ritree1=c(seq(from=-0.9744162,to=0,by=(0-(-0.9744162))/10),0),
                       riwoody1=c(seq(from=-0.897608,to=0,by=(0-(-0.897608))/10),0),
                       riground1=c(seq(from=-0.6666667,to=0,by=(0-(-0.6666667))/10),0),
                       riall=c(seq(from=-0.7545604,to=0,by=(0-(-0.7545604))/10),0),
                       Seismic.n=c(1,1,1,1,1,1,1,1,1,1,1,0),
                       Seismic=c("1","1","1","1","1","1","1","1","1","1","1","0"))
  
  newdat$riall.c<-newdat$riall-mean(m2$riall)
  newdat$riall.q<-newdat$riall.c^2
  newdat$rishrub1.c<-newdat$rishrub1-mean(m2$rishrub1)
  newdat$rishrub1.q<-newdat$rishrub1.c^2
  newdat$riwoody1.c<-newdat$riwoody1-mean(m2$riwoody1)
  newdat$riwoody1.q<-newdat$riwoody1.c^2
  newdat$ritree1.c<-newdat$ritree1-mean(m2$ritree1)
  newdat$ritree1.q<-newdat$ritree1.c^2
  newdat$riground1.c<-newdat$riground1-mean(m2$riground1)
  newdat$riground1.q<-newdat$riground1.c^2
  
  #Best Model
  dd0 <- model.sel(RIALL.Lin.50, 
                   RITREE.Lin.50, 
                   RISHRUB.Lin.50, 
                   RIGROUND.Lin.50, 
                   FOREST.50, 
                   LINE.50, rank=AIC) 
  bestModel<-get.models(dd0, subset = 1)[[1]]
  secondbestModel<-get.models(dd0, subset = 2)[[1]]
  thirdbestModel<-get.models(dd0, subset = 3)[[1]]
  #gets best model in terms of lowest AICc, highest Akaike weight

  fits<-predictSE(bestModel, newdata=newdat, type="link", se.fit=TRUE)
  newdat$bestModelFit<-exp(fits$fit)
  newdat$bestModelFitLCL<-exp(fits$fit-1.96*fits$se.fit)
  newdat$bestModelFitUCL<-exp(fits$fit+1.96*fits$se.fit)
  
  newdat$bestModelFitUCL<-ifelse(newdat$bestModelFitUCL=="Inf",10,newdat$bestModelFitUCL)
  
  p1a<-ggplot(data=newdat, aes(x=riall, y=bestModelFit)) +
    geom_point(aes(x=riall, y=bestModelFit, col=Seismic, shape=Seismic), size=4)+
    geom_line(aes(x=riall, y=bestModelFit, col=Seismic))+
    geom_errorbar(aes(ymin=bestModelFitLCL, ymax=bestModelFitUCL, col=Seismic), width=.075)+
    ylim(0,(1.1*max(newdat$bestModelFitUCL)))+
    labs(x="Recovery Index (All veg.)", y=paste0("Predicted ",i," Count (50 m)"))+
    theme_classic(base_family = "serif") +                        #theme_minimal Apply a minimalistic theme with serif font
    theme(axis.title = element_text(size = 24, family = "serif"),  # Increase axis title font size and use serif font
          axis.text = element_text(size = 20, family = "serif"),   # Increase axis label font size and use serif font
          plot.title = element_blank(),
          legend.position="none")    
  ggsave(p1a, file=paste0("2_outputs/December 2023/",i,"predcountbestmodel_50m.png"), units="in", width=10, height=8)
  
  #get coefficients from best model for each species/point count size
  mydataFrame<-data.frame(summary(bestModel)$coefficients)
  mydataFrame$Species<-i
  mydataFrame$PCradius<-50
  mydataFrame$ModelName<-row.names(dd0)[1]
  mydataFrame$Predictor<-row.names(mydataFrame)
  mydataFrame$AIC<-AIC(bestModel)
  mydataFrame$AICweight<-dd0$weight[1]
  mydataFrame$marginalR2<-r.squaredGLMM(bestModel)[2,1]
  mydataFrame$condR2<-r.squaredGLMM(bestModel)[2,2]
  mydataFrame$LCL<-mydataFrame$Estimate-1.96*mydataFrame$Std..Error
  mydataFrame$UCL<-mydataFrame$Estimate+1.96*mydataFrame$Std..Error
  #reorder data frame
  mydataFrame2<-mydataFrame%>%
    dplyr::select(Species,PCradius,ModelName,Predictor,Estimate,Std..Error,LCL,UCL,z.value,Pr...z..,AIC,AICweight,marginalR2,condR2)
  write.csv(mydataFrame2, file=paste0("2_outputs/December 2023/",i,".50mbestmodelcoefs.csv"))
  mydataFrame3<-data.frame(dd0)  
  write.csv(mydataFrame3, file=paste0("2_outputs/December 2023/",i,".50mbestmodeltable.csv"))
  
  #get coefficients from second best model for each species/point count size
  mydataFrame<-data.frame(summary(secondbestModel)$coefficients)
  mydataFrame$Species<-i
  mydataFrame$PCradius<-50
  mydataFrame$ModelName<-row.names(dd0)[2]
  mydataFrame$Predictor<-row.names(mydataFrame)
  mydataFrame$AIC<-AIC(secondbestModel)
  mydataFrame$AICweight<-dd0$weight[2]
  mydataFrame$marginalR2<-r.squaredGLMM(secondbestModel)[2,1]
  mydataFrame$condR2<-r.squaredGLMM(secondbestModel)[2,2]
  mydataFrame$LCL<-mydataFrame$Estimate-1.96*mydataFrame$Std..Error
  mydataFrame$UCL<-mydataFrame$Estimate+1.96*mydataFrame$Std..Error
  #reorder data frame
  mydataFrame2<-mydataFrame%>%
    dplyr::select(Species,PCradius,ModelName,Predictor,Estimate,Std..Error,LCL,UCL,z.value,Pr...z..,AIC,AICweight,marginalR2,condR2)
  write.csv(mydataFrame2, file=paste0("2_outputs/December 2023/",i,".50msecondbestModelcoefs.csv"))
  
  #get coefficients from third best model for each species/point count size
  mydataFrame<-data.frame(summary(thirdbestModel)$coefficients)
  mydataFrame$Species<-i
  mydataFrame$PCradius<-50
  mydataFrame$ModelName<-row.names(dd0)[3]
  mydataFrame$Predictor<-row.names(mydataFrame)
  mydataFrame$AIC<-AIC(thirdbestModel)
  mydataFrame$AICweight<-dd0$weight[3]
  mydataFrame$marginalR2<-r.squaredGLMM(thirdbestModel)[2,1]
  mydataFrame$condR2<-r.squaredGLMM(thirdbestModel)[2,2]
  mydataFrame$LCL<-mydataFrame$Estimate-1.96*mydataFrame$Std..Error
  mydataFrame$UCL<-mydataFrame$Estimate+1.96*mydataFrame$Std..Error
  #reorder data frame
  mydataFrame2<-mydataFrame%>%
    dplyr::select(Species,PCradius,ModelName,Predictor,Estimate,Std..Error,LCL,UCL,z.value,Pr...z..,AIC,AICweight,marginalR2,condR2)
  write.csv(mydataFrame2, file=paste0("2_outputs/December 2023/",i,".50mthirdbestModelcoefs.csv"))
  
  print(paste0("Starting 100-m models for ",i))
  
  #100-m analysis
  counts<-read.csv("0_data/1_processed/point counts/100mJoinEverything_MoreLatLong.csv", header=TRUE)
  offsets<-read.csv("0_data/1_processed/point counts/100mJoinEverything_OFF.csv", header=TRUE)
  offsets<-offsets %>%
    rename_with(.fn = function(.x){paste0(.x,"off")}) 
  offsets$PKEY<-offsets$Xoff
  offsets$Xoff<-NULL
  
  m1<-merge(counts, offsets, by=c("PKEY"))
  
  vegBird<-read.csv("0_data/1_processed/point counts/vegBirdDataHedwigUsed.csv", header=TRUE)
  vegBird$PKEY<-vegBird$pkey
  vegBird$pkey<-NULL
  vegBirdF<-vegBird%>%
    dplyr::select(PKEY,landtype2,F1all4,F2all4,riall,ritree1,riwoody1,rishrub1,riground1)
  #vegBirdF PKEYs: replace string "HEDW" with string "NWTSLR"
  vegBirdF$PKEY<-gsub("HEDW","NWTSLR",vegBirdF$PKEY)
  m2<-merge(m1, vegBirdF, by=c("PKEY"), all.x=TRUE)
  m2<-m2[m2$landtype2=="Lowland",]#just use lowland point counts
  m2<-m2[!is.na(m2$OBSERVER),]
  m2$OBSERVER<-as.factor(m2$OBSERVER)
  
  m2$spp<-m2[,i]
  m2$sppoff<-m2[,paste0(i,"off")]
  mean(m2$spp)
  var(m2$spp)#Poisson error distribution
  m2$Julian.s<-(m2$JULIAN_DAY-mean(m2$JULIAN_DAY))/sd(m2$JULIAN_DAY)
  m2$Time.s<-(m2$Time-mean(m2$Time))/sd(m2$Time)
  
  m2$Seismic<-as.factor(ifelse(m2$Veg_Plot.Type=="Interior",0,1))
  m2$Seismic.n<-ifelse(m2$Veg_Plot.Type=="Interior",0,1)
  m2$riall.c<-m2$riall-mean(m2$riall)
  m2$riall.q<-m2$riall.c^2
  m2$rishrub1.c<-m2$rishrub1-mean(m2$rishrub1)
  m2$rishrub1.q<-m2$rishrub1.c^2
  m2$ritree1.c<-m2$ritree1-mean(m2$ritree1)
  m2$ritree1.q<-m2$ritree1.c^2
  m2$riwoody1.c<-m2$riwoody1-mean(m2$riwoody1)
  m2$riwoody1.q<-m2$riwoody1.c^2
  m2$riground1.c<-m2$riground1-mean(m2$riground1)
  m2$riground1.q<-m2$riground1.c^2
  
  if (var(m2$spp,na.rm=TRUE)/mean(m2$spp,na.rm=TRUE)<2) {
    FOREST.100<-glmer(spp~F1all4+F2all4+Julian.s+Time.s + (1|OBSERVER), data=m2, family=poisson)
    summary(FOREST.100)
    
    LINE.100<-glmer(spp~F1all4+F2all4+Seismic+Julian.s+Time.s + (1|OBSERVER), data=m2, family=poisson)
    summary(LINE.100)
    
    RIALL.Lin.100<-glmer(spp~F1all4+F2all4+Seismic.n+riall+Seismic.n*riall+Julian.s+Time.s + (1|OBSERVER), data=m2, family=poisson)
    summary(RIALL.Lin.100)

    RISHRUB.Lin.100<-glmer(spp~F1all4+F2all4+Seismic.n+rishrub1+Seismic.n*rishrub1+Julian.s+Time.s + (1|OBSERVER), data=m2, family=poisson)
    summary(RISHRUB.Lin.100)

    RITREE.Lin.100<-glmer(spp~F1all4+F2all4+Seismic.n+ritree1+Seismic.n*ritree1+Julian.s+Time.s + (1|OBSERVER), data=m2, family=poisson)
    summary(RITREE.Lin.100)

    RIGROUND.Lin.100<-glmer(spp~F1all4+F2all4+Seismic.n+riground1+Seismic.n*riground1+Julian.s+Time.s + (1|OBSERVER), data=m2, family=poisson)
    summary(RIGROUND.Lin.100)
  }
  
  if (!var(m2$spp,na.rm=TRUE)/mean(m2$spp,na.rm=TRUE)<2) {
    FOREST.100<-glmer.nb(spp~F1all4+F2all4+Julian.s+Time.s + (1|OBSERVER), data=m2)
    summary(FOREST.100)
    
    LINE.100<-glmer.nb(spp~F1all4+F2all4+Seismic+Julian.s+Time.s + (1|OBSERVER), data=m2)
    summary(LINE.100)
    
    RIALL.Lin.100<-glmer.nb(spp~F1all4+F2all4+Seismic.n+riall+Seismic.n*riall+Julian.s+Time.s + (1|OBSERVER), data=m2)
    summary(RIALL.Lin.100)

    RISHRUB.Lin.100<-glmer.nb(spp~F1all4+F2all4+Seismic.n+rishrub1+Seismic.n*rishrub1+Julian.s+Time.s + (1|OBSERVER), data=m2)
    summary(RISHRUB.Lin.100)

    RITREE.Lin.100<-glmer.nb(spp~F1all4+F2all4+Seismic.n+ritree1+Seismic.n*ritree1+Julian.s+Time.s + (1|OBSERVER), data=m2)
    summary(RITREE.Lin.100)

    RIGROUND.Lin.100<-glmer.nb(spp~F1all4+F2all4+Seismic.n+riground1+Seismic.n*riground1+Julian.s+Time.s + (1|OBSERVER), data=m2)
    summary(RIGROUND.Lin.100)

  }
  
  #Get prediction counts from best model when Hedwig is the observer
  newdat <- data.frame(F1all4=mean(m2$F1all4, na.rm=TRUE),#older, taller deciduous forest
                       F2all4=mean(m2$F2all4, na.rm=TRUE),#greater canopy cover, dbh, stem density
                       Julian.s=-0.09831949,#June 15
                       Time.s=-1.232137,#5 AM
                       rishrub1=c(-1,-0.9,-0.8,-0.7,-0.6,-0.5,-0.4,-0.3,-0.2,-0.1,0,0),
                       ritree1=c(seq(from=-0.9744162,to=0,by=(0-(-0.9744162))/10),0),
                       riwoody1=c(seq(from=-0.897608,to=0,by=(0-(-0.897608))/10),0),
                       riground1=c(seq(from=-0.6666667,to=0,by=(0-(-0.6666667))/10),0),
                       riall=c(seq(from=-0.7545604,to=0,by=(0-(-0.7545604))/10),0),
                       Seismic.n=c(1,1,1,1,1,1,1,1,1,1,1,0),
                       Seismic=c("1","1","1","1","1","1","1","1","1","1","1","0"))
  
  newdat$riall.c<-newdat$riall-mean(m2$riall)
  newdat$riall.q<-newdat$riall.c^2
  newdat$rishrub1.c<-newdat$rishrub1-mean(m2$rishrub1)
  newdat$rishrub1.q<-newdat$rishrub1.c^2
  newdat$riwoody1.c<-newdat$riwoody1-mean(m2$riwoody1)
  newdat$riwoody1.q<-newdat$riwoody1.c^2
  newdat$ritree1.c<-newdat$ritree1-mean(m2$ritree1)
  newdat$ritree1.q<-newdat$ritree1.c^2
  newdat$riground1.c<-newdat$riground1-mean(m2$riground1)
  newdat$riground1.q<-newdat$riground1.c^2
  
  #Best Model
  dd0 <- model.sel(RIALL.Lin.100, 
                   RITREE.Lin.100, 
                   RISHRUB.Lin.100, 
                   RIGROUND.Lin.100, 
                   FOREST.100, 
                   LINE.100, rank=AIC) 
  bestModel<-get.models(dd0, subset = 1)[[1]]
  secondbestModel<-get.models(dd0, subset = 2)[[1]]
  thirdbestModel<-get.models(dd0, subset = 3)[[1]]
  #gets best model in terms of lowest AICc, highest Akaike weight

  fits<-predictSE(bestModel, newdata=newdat, type="link", se.fit=TRUE)
  newdat$bestModelFit<-exp(fits$fit)
  newdat$bestModelFitLCL<-exp(fits$fit-1.96*fits$se.fit)
  newdat$bestModelFitUCL<-exp(fits$fit+1.96*fits$se.fit)
  
  newdat$bestModelFitUCL<-ifelse(newdat$bestModelFitUCL=="Inf",10,newdat$bestModelFitUCL)
  
  p1b<-ggplot(data=newdat, aes(x=riall, y=bestModelFit)) +
    geom_point(aes(x=riall, y=bestModelFit, col=Seismic, shape=Seismic), size=4)+
    geom_line(aes(x=riall, y=bestModelFit, col=Seismic))+
    geom_errorbar(aes(ymin=bestModelFitLCL, ymax=bestModelFitUCL, col=Seismic), width=.075)+
    ylim(0,(1.1*max(newdat$bestModelFitUCL)))+
    labs(x="Recovery Index (All veg.)", y=paste0("Predicted ",i," Count (100 m)"))+
    theme_classic(base_family = "serif") +                        #theme_minimal Apply a minimalistic theme with serif font
    theme(axis.title = element_text(size = 24, family = "serif"),  # Increase axis title font size and use serif font
          axis.text = element_text(size = 20, family = "serif"),   # Increase axis label font size and use serif font
          plot.title = element_blank(),
          legend.position = "none")    
  ggsave(p1b, file=paste0("2_outputs/December 2023/",i,"predcountbestmodel_100m.png"), units="in", width=10, height=8)
  
  
  #get coefficients from best model for each species/point count size
  mydataFrame<-data.frame(summary(bestModel)$coefficients)
  mydataFrame$Species<-i
  mydataFrame$PCradius<-100
  mydataFrame$ModelName<-row.names(dd0)[1]
  mydataFrame$Predictor<-row.names(mydataFrame)
  mydataFrame$AIC<-AIC(bestModel)
  mydataFrame$AICweight<-dd0$weight[1]
  mydataFrame$marginalR2<-r.squaredGLMM(bestModel)[2,1]
  mydataFrame$condR2<-r.squaredGLMM(bestModel)[2,2]
  mydataFrame$LCL<-mydataFrame$Estimate-1.96*mydataFrame$Std..Error
  mydataFrame$UCL<-mydataFrame$Estimate+1.96*mydataFrame$Std..Error
  #reorder data frame
  mydataFrame2<-mydataFrame%>%
    dplyr::select(Species,PCradius,ModelName,Predictor,Estimate,Std..Error,LCL,UCL,z.value,Pr...z..,AIC,AICweight,marginalR2,condR2)
  write.csv(mydataFrame2, file=paste0("2_outputs/December 2023/",i,".100mbestmodelcoefs.csv"))
  mydataFrame3<-data.frame(dd0)
  write.csv(mydataFrame3, file=paste0("2_outputs/December 2023/",i,".100mbestmodeltable.csv"))
  
  #get coefficients from second best model for each species/point count size
  mydataFrame<-data.frame(summary(secondbestModel)$coefficients)
  mydataFrame$Species<-i
  mydataFrame$PCradius<-100
  mydataFrame$ModelName<-row.names(dd0)[2]
  mydataFrame$Predictor<-row.names(mydataFrame)
  mydataFrame$AIC<-AIC(secondbestModel)
  mydataFrame$AICweight<-dd0$weight[2]
  mydataFrame$marginalR2<-r.squaredGLMM(secondbestModel)[2,1]
  mydataFrame$condR2<-r.squaredGLMM(secondbestModel)[2,2]
  mydataFrame$LCL<-mydataFrame$Estimate-1.96*mydataFrame$Std..Error
  mydataFrame$UCL<-mydataFrame$Estimate+1.96*mydataFrame$Std..Error
  #reorder data frame
  mydataFrame2<-mydataFrame%>%
    dplyr::select(Species,PCradius,ModelName,Predictor,Estimate,Std..Error,LCL,UCL,z.value,Pr...z..,AIC,AICweight,marginalR2,condR2)
  write.csv(mydataFrame2, file=paste0("2_outputs/December 2023/",i,".100msecondbestModelcoefs.csv"))
  
  #get coefficients from third best model for each species/point count size
  mydataFrame<-data.frame(summary(thirdbestModel)$coefficients)
  mydataFrame$Species<-i
  mydataFrame$PCradius<-100
  mydataFrame$ModelName<-row.names(dd0)[3]
  mydataFrame$Predictor<-row.names(mydataFrame)
  mydataFrame$AIC<-AIC(thirdbestModel)
  mydataFrame$AICweight<-dd0$weight[3]
  mydataFrame$marginalR2<-r.squaredGLMM(thirdbestModel)[2,1]
  mydataFrame$condR2<-r.squaredGLMM(thirdbestModel)[2,2]
  mydataFrame$LCL<-mydataFrame$Estimate-1.96*mydataFrame$Std..Error
  mydataFrame$UCL<-mydataFrame$Estimate+1.96*mydataFrame$Std..Error
  #reorder data frame
  mydataFrame2<-mydataFrame%>%
    dplyr::select(Species,PCradius,ModelName,Predictor,Estimate,Std..Error,LCL,UCL,z.value,Pr...z..,AIC,AICweight,marginalR2,condR2)
  write.csv(mydataFrame2, file=paste0("2_outputs/December 2023/",i,".100mthirdbestModelcoefs.csv"))
  
  print(paste0("Starting unlimited-distance models for ",i))
  
  #Unlimited distance analysis
  counts<-read.csv("0_data/1_processed/point counts/UnlimJoinEverything_MoreLatLong.csv", header=TRUE)
  offsets<-read.csv("0_data/1_processed/point counts/UnlimJoinEverything_OFF.csv", header=TRUE)
  offsets<-offsets %>%
    rename_with(.fn = function(.x){paste0(.x,"off")}) 
  offsets$PKEY<-offsets$Xoff
  offsets$Xoff<-NULL
  
  m1<-merge(counts, offsets, by=c("PKEY"))#, by=c("PKEY")
  vegBird<-read.csv("0_data/1_processed/point counts/vegBirdDataHedwigUsed.csv", header=TRUE)
  vegBird$PKEY<-vegBird$pkey
  vegBird$pkey<-NULL
  vegBirdF<-vegBird%>%
    dplyr::select(PKEY,landtype2,F1all4,F2all4,riall,ritree1,riwoody1,rishrub1,riground1)
  #vegBirdF PKEYs: replace string "HEDW" with string "NWTSLR"
  vegBirdF$PKEY<-gsub("HEDW","NWTSLR",vegBirdF$PKEY)
  m2<-merge(m1, vegBirdF, by=c("PKEY"), all.x=TRUE)
  m2<-m2[m2$landtype2=="Lowland",]#just use lowland point counts
  m2<-m2[!is.na(m2$OBSERVER),]
  
  m2$spp<-m2[,i]
  m2$sppoff<-m2[,paste0(i,"off")]
  mean(m2$spp)
  var(m2$spp)#Poisson error distribution
  m2$Julian.s<-(m2$JULIAN_DAY-mean(m2$JULIAN_DAY))/sd(m2$JULIAN_DAY)
  m2$Time.s<-(m2$Time-mean(m2$Time))/sd(m2$Time)
  
  m2$Seismic<-as.factor(ifelse(m2$Veg_Plot.Type=="Interior",0,1))
  m2$Seismic.n<-ifelse(m2$Veg_Plot.Type=="Interior",0,1)
  m2$riall.c<-m2$riall-mean(m2$riall)
  m2$riall.q<-m2$riall.c^2
  m2$rishrub1.c<-m2$rishrub1-mean(m2$rishrub1)
  m2$rishrub1.q<-m2$rishrub1.c^2
  m2$ritree1.c<-m2$ritree1-mean(m2$ritree1)
  m2$ritree1.q<-m2$ritree1.c^2
  m2$riwoody1.c<-m2$riwoody1-mean(m2$riwoody1)
  m2$riwoody1.q<-m2$riwoody1.c^2
  m2$riground1.c<-m2$riground1-mean(m2$riground1)
  m2$riground1.q<-m2$riground1.c^2
  
  if (var(m2$spp,na.rm=TRUE)/mean(m2$spp,na.rm=TRUE)<2) {
    FOREST.UNL<-glmer(spp~F1all4+F2all4+Julian.s+Time.s + (1|OBSERVER), data=m2, family=poisson)
    summary(FOREST.UNL)
    
    LINE.UNL<-glmer(spp~F1all4+F2all4+Seismic+Julian.s+Time.s + (1|OBSERVER), data=m2, family=poisson)
    summary(LINE.UNL)
    
    RIALL.Lin.UNL<-glmer(spp~F1all4+F2all4+Seismic.n+riall+Seismic.n*riall+Julian.s+Time.s + (1|OBSERVER), data=m2, family=poisson)
    summary(RIALL.Lin.UNL)

    RISHRUB.Lin.UNL<-glmer(spp~F1all4+F2all4+Seismic.n+rishrub1+Seismic.n*rishrub1+Julian.s+Time.s + (1|OBSERVER), data=m2, family=poisson)
    summary(RISHRUB.Lin.UNL)

    RITREE.Lin.UNL<-glmer(spp~F1all4+F2all4+Seismic.n+ritree1+Seismic.n*ritree1+Julian.s+Time.s + (1|OBSERVER), data=m2, family=poisson)
    summary(RITREE.Lin.UNL)

    RIGROUND.Lin.UNL<-glmer(spp~F1all4+F2all4+Seismic.n+riground1+Seismic.n*riground1+Julian.s+Time.s + (1|OBSERVER), data=m2, family=poisson)
    summary(RIGROUND.Lin.UNL)
  }
  
  if (!var(m2$spp,na.rm=TRUE)/mean(m2$spp,na.rm=TRUE)<2) {
    FOREST.UNL<-glmer.nb(spp~F1all4+F2all4+Julian.s+Time.s + (1|OBSERVER), data=m2)
    summary(FOREST.UNL)
    
    LINE.UNL<-glmer.nb(spp~F1all4+F2all4+Seismic+Julian.s+Time.s + (1|OBSERVER), data=m2)
    summary(LINE.UNL)
    
    RIALL.Lin.UNL<-glmer.nb(spp~F1all4+F2all4+Seismic.n+riall+Seismic.n*riall+Julian.s+Time.s + (1|OBSERVER), data=m2)
    summary(RIALL.Lin.UNL)

    RISHRUB.Lin.UNL<-glmer.nb(spp~F1all4+F2all4+Seismic.n+rishrub1+Seismic.n*rishrub1+Julian.s+Time.s + (1|OBSERVER), data=m2)
    summary(RISHRUB.Lin.UNL)

    RITREE.Lin.UNL<-glmer.nb(spp~F1all4+F2all4+Seismic.n+ritree1+Seismic.n*ritree1+Julian.s+Time.s + (1|OBSERVER), data=m2)
    summary(RITREE.Lin.UNL)

    RIGROUND.Lin.UNL<-glmer.nb(spp~F1all4+F2all4+Seismic.n+riground1+Seismic.n*riground1+Julian.s+Time.s + (1|OBSERVER), data=m2)
    summary(RIGROUND.Lin.UNL)
  }
  
  #Get prediction counts from best model when Hedwig is the observer
  newdat <- data.frame(F1all4=mean(m2$F1all4, na.rm=TRUE),#older, taller deciduous forest
                       F2all4=mean(m2$F2all4, na.rm=TRUE),#greater canopy cover, dbh, stem density
                       Julian.s=-0.09831949,#June 15
                       Time.s=-1.232137,#5 AM
                       rishrub1=c(-1,-0.9,-0.8,-0.7,-0.6,-0.5,-0.4,-0.3,-0.2,-0.1,0,0),
                       ritree1=c(seq(from=-0.9744162,to=0,by=(0-(-0.9744162))/10),0),
                       riwoody1=c(seq(from=-0.897608,to=0,by=(0-(-0.897608))/10),0),
                       riground1=c(seq(from=-0.6666667,to=0,by=(0-(-0.6666667))/10),0),
                       riall=c(seq(from=-0.7545604,to=0,by=(0-(-0.7545604))/10),0),
                       Seismic.n=c(1,1,1,1,1,1,1,1,1,1,1,0),
                       Seismic=c("1","1","1","1","1","1","1","1","1","1","1","0"))
  
  newdat$riall.c<-newdat$riall-mean(m2$riall)
  newdat$riall.q<-newdat$riall.c^2
  newdat$rishrub1.c<-newdat$rishrub1-mean(m2$rishrub1)
  newdat$rishrub1.q<-newdat$rishrub1.c^2
  newdat$riwoody1.c<-newdat$riwoody1-mean(m2$riwoody1)
  newdat$riwoody1.q<-newdat$riwoody1.c^2
  newdat$ritree1.c<-newdat$ritree1-mean(m2$ritree1)
  newdat$ritree1.q<-newdat$ritree1.c^2
  newdat$riground1.c<-newdat$riground1-mean(m2$riground1)
  newdat$riground1.q<-newdat$riground1.c^2
  
  #Best Model
  dd0 <- model.sel(RIALL.Lin.UNL, 
                   RITREE.Lin.UNL, 
                   RISHRUB.Lin.UNL, 
                   RIGROUND.Lin.UNL, 
                   FOREST.UNL, 
                   LINE.UNL, rank=AIC) 
  bestModel<-get.models(dd0, subset = 1)[[1]]
  secondbestModel<-get.models(dd0, subset = 2)[[1]]
  thirdbestModel<-get.models(dd0, subset = 3)[[1]]
  #gets best model in terms of lowest AICc, highest Akaike weight

  fits<-predictSE(bestModel, newdata=newdat, type="link", se.fit=TRUE)
  newdat$bestModelFit<-exp(fits$fit)
  newdat$bestModelFitLCL<-exp(fits$fit-1.96*fits$se.fit)
  newdat$bestModelFitUCL<-exp(fits$fit+1.96*fits$se.fit)
  
  newdat$bestModelFitUCL<-ifelse(newdat$bestModelFitUCL=="Inf",10,newdat$bestModelFitUCL)
  
  p1c<-ggplot(data=newdat, aes(x=riall, y=bestModelFit)) +
    geom_point(aes(x=riall, y=bestModelFit, col=Seismic, shape=Seismic), size=4)+
    geom_line(aes(x=riall, y=bestModelFit, col=Seismic))+
    geom_errorbar(aes(ymin=bestModelFitLCL, ymax=bestModelFitUCL, col=Seismic), width=.075)+
    ylim(0,(1.1*max(newdat$bestModelFitUCL)))+
    labs(x="Recovery Index (All veg.)", y=paste0("Predicted ",i," Count (Unlim.)"))+
    theme_classic(base_family = "serif") +                        #theme_minimal Apply a minimalistic theme with serif font
    theme(axis.title = element_text(size = 24, family = "serif"),  # Increase axis title font size and use serif font
          axis.text = element_text(size = 20, family = "serif"),   # Increase axis label font size and use serif font
          plot.title = element_blank(),
          legend.position="none")    
  ggsave(p1c, file=paste0("2_outputs/December 2023/",i,"predcountbestmodel_UNL.png"), units="in", width=10, height=8)
  
  #get coefficients from best model for each species/point count size
  mydataFrame<-data.frame(summary(bestModel)$coefficients)
  mydataFrame$Species<-i
  mydataFrame$PCradius<-"UnlimDist"
  mydataFrame$ModelName<-row.names(dd0)[1]
  mydataFrame$Predictor<-row.names(mydataFrame)
  mydataFrame$AIC<-AIC(bestModel)
  mydataFrame$AICweight<-dd0$weight[1]
  mydataFrame$marginalR2<-r.squaredGLMM(bestModel)[2,1]
  mydataFrame$condR2<-r.squaredGLMM(bestModel)[2,2]
  mydataFrame$LCL<-mydataFrame$Estimate-1.96*mydataFrame$Std..Error
  mydataFrame$UCL<-mydataFrame$Estimate+1.96*mydataFrame$Std..Error
  #reorder data frame
  mydataFrame2<-mydataFrame%>%
    dplyr::select(Species,PCradius,ModelName,Predictor,Estimate,Std..Error,LCL,UCL,z.value,Pr...z..,AIC,AICweight,marginalR2,condR2)
  write.csv(mydataFrame2, file=paste0("2_outputs/December 2023/",i,".UnlimDistbestmodelcoefs.csv"))
  mydataFrame3<-data.frame(dd0)
  write.csv(mydataFrame3, file=paste0("2_outputs/December 2023/",i,".UnlimDistbestmodeltable.csv"))
  
  #get coefficients from second best model for each species/point count size
  mydataFrame<-data.frame(summary(secondbestModel)$coefficients)
  mydataFrame$Species<-i
  mydataFrame$PCradius<-"UnlimDist"
  mydataFrame$ModelName<-row.names(dd0)[2]
  mydataFrame$Predictor<-row.names(mydataFrame)
  mydataFrame$AIC<-AIC(secondbestModel)
  mydataFrame$AICweight<-dd0$weight[2]
  mydataFrame$marginalR2<-r.squaredGLMM(secondbestModel)[2,1]
  mydataFrame$condR2<-r.squaredGLMM(secondbestModel)[2,2]
  mydataFrame$LCL<-mydataFrame$Estimate-1.96*mydataFrame$Std..Error
  mydataFrame$UCL<-mydataFrame$Estimate+1.96*mydataFrame$Std..Error
  #reorder data frame
  mydataFrame2<-mydataFrame%>%
    dplyr::select(Species,PCradius,ModelName,Predictor,Estimate,Std..Error,LCL,UCL,z.value,Pr...z..,AIC,AICweight,marginalR2,condR2)
  write.csv(mydataFrame2, file=paste0("2_outputs/December 2023/",i,".UnlimDistsecondbestModelcoefs.csv"))
  
  #get coefficients from third best model for each species/point count size
  mydataFrame<-data.frame(summary(thirdbestModel)$coefficients)
  mydataFrame$Species<-i
  mydataFrame$PCradius<-"UnlimDist"
  mydataFrame$ModelName<-row.names(dd0)[3]
  mydataFrame$Predictor<-row.names(mydataFrame)
  mydataFrame$AIC<-AIC(thirdbestModel)
  mydataFrame$AICweight<-dd0$weight[3]
  mydataFrame$marginalR2<-r.squaredGLMM(thirdbestModel)[2,1]
  mydataFrame$condR2<-r.squaredGLMM(thirdbestModel)[2,2]
  mydataFrame$LCL<-mydataFrame$Estimate-1.96*mydataFrame$Std..Error
  mydataFrame$UCL<-mydataFrame$Estimate+1.96*mydataFrame$Std..Error
  #reorder data frame
  mydataFrame2<-mydataFrame%>%
    dplyr::select(Species,PCradius,ModelName,Predictor,Estimate,Std..Error,LCL,UCL,z.value,Pr...z..,AIC,AICweight,marginalR2,condR2)
  write.csv(mydataFrame2, file=paste0("2_outputs/December 2023/",i,".UnlimDistthirdbestModelcoefs.csv"))
  
  mpplot2<-grid.arrange(p1a,p1b,p1c,
                        ncol=1,
                        nrow=3)
  ggsave(mpplot2, file=paste0("2_outputs/December 2023/",i,"predseachmodelBestModelEachScale.png"), units="in", width=20, height=24)
  
  print(paste0("Finished analysis for ",i))
  
}

#Concatenate Best Model Results, All Species and Point Count Sizes
names1<-list.files(path="2_outputs/December 2023/", pattern="bestmodelcoefs.csv")
names2<-list.files(path="2_outputs/December 2023/", pattern="secondbestModelcoefs.csv")
names3<-list.files(path="2_outputs/December 2023/", pattern="thirdbestModelcoefs.csv")

topThree<-c(names1,names2,names3)
#Concatenate Best Model Results, All Species and Point Count Sizes
modelresults<-list()#empty list each time we draw a new number of samples
for (i in names1){
  #read in model coefficients from best model for each species
  spptdf<-read.csv(paste0("2_outputs/December 2023/",i), header=TRUE)
  #add to model list
  modelresults[[i]]<-spptdf#append temporary data frame at each loop iteration to the list
  print(paste0("Species ",i," added to list"))
  
}
drawnresults = do.call(rbind, modelresults)#bind data frames together
write.csv(drawnresults, file="2_outputs/December 2023/bestModelResultsAllSpeciesPointCountSizes.csv")

drawnresults<-read.csv("2_outputs/December 2023/bestModelResultsAllSpeciesPointCountSizes.csv", header=TRUE)
drawnresults$PCradius<-factor(drawnresults$PCradius, levels = c("50", "100", "UnlimDist"))
modelresultsWider<-drawnresults%>%
  tidyr::pivot_wider(names_from = Predictor, values_from = Estimate)%>%
  dplyr::select(Species,PCradius,ModelName,F1all4,F2all4,Seismic1,Seismic.n,riall,riground1,rishrub1,ritree1)%>%
  mutate(across(where(is.numeric), ~replace(., is.na(.), 0)))%>%
  group_by(Species,PCradius,ModelName)%>%
  summarise(across(everything(), ~ sum(., na.rm = TRUE)))
write.csv(modelresultsWider, file="2_outputs/December 2023/bestModelResultsAllSpeciesPointCountSizes_Wider.csv")


#Concatenate Top Three Model Results For Each Species and Point Count Sizes
modelresults<-list()#empty list each time we draw a new number of samples
for (i in topThree){
  #read in model coefficients from best model for each species
  spptdf<-read.csv(paste0("2_outputs/December 2023/",i), header=TRUE)
  spptdf$PCradius<-as.character(spptdf$PCradius)
  #add to model list
  modelresults[[i]]<-spptdf#append temporary data frame at each loop iteration to the list
  print(paste0("Species ",i," added to list"))
  
}
drawnresults = do.call(bind_rows, modelresults)#bind data frames together
write.csv(drawnresults, file="2_outputs/December 2023/topThreeModelResultsAllSpeciesPointCountSizes.csv")

drawnresults<-read.csv("2_outputs/December 2023/topThreeModelResultsAllSpeciesPointCountSizes.csv", header=TRUE)
drawnresults$PCradius<-factor(drawnresults$PCradius, levels = c("50", "100", "UnlimDist"))
modelresultsWider<-drawnresults%>%
  tidyr::pivot_wider(names_from = Predictor, values_from = Estimate)%>%
  dplyr::select(Species,PCradius,ModelName,AIC,AICweight,marginalR2,condR2,F1all4,F2all4,Seismic1,Seismic.n,riall,riground1,rishrub1,ritree1)%>%
  mutate(across(where(is.numeric), ~replace(., is.na(.), 0)))%>%
  group_by(Species,PCradius,ModelName,AIC,AICweight,marginalR2,condR2)%>%
  summarise(across(everything(), ~ sum(., na.rm = TRUE)))
write.csv(modelresultsWider, file="2_outputs/December 2023/topThreeModelResultsAllSpeciesPointCountSizes_Wider.csv")


#Create a plot showing how species respond to forest variables in different point count analyses
drawnresults<-read.csv("2_outputs/December 2023/bestModelResultsAllSpeciesPointCountSizes.csv", header=TRUE)
str(drawnresults)
#what we need is long data format for the variables Species and PCradius but wide
#format for each variable and maybe Pr...z.. of each variable
modelresultsWider1<-drawnresults%>%
  tidyr::pivot_wider(names_from = Predictor, values_from = Estimate)%>%
  dplyr::select(Species,PCradius,F1all4,F2all4)%>%
  mutate(across(where(is.numeric), ~replace(., is.na(.), 0)))%>%
  group_by(Species,PCradius)%>%
  summarise(across(everything(), ~ sum(., na.rm = TRUE)))

modelresultsWider2<-drawnresults%>%
  tidyr::pivot_wider(names_from = Predictor, values_from = Pr...z..)%>%
  dplyr::select(Species,PCradius,F1all4,F2all4)%>%
  mutate(across(where(is.numeric), ~replace(., is.na(.), 0)))%>%
  group_by(Species,PCradius)%>%
  summarise(across(everything(), ~ sum(., na.rm = TRUE)))%>%
  rename(Pr_F1all4=F1all4,
         Pr_F2all4=F2all4)

modelresultsWiderFinal<-merge(modelresultsWider1,
                              modelresultsWider2,
                              by=c("Species","PCradius"))

modelresultsWiderFinal$PCradius<-as.factor(modelresultsWiderFinal$PCradius)
modelresultsWiderFinal$PCradius<-factor(modelresultsWiderFinal$PCradius, levels = c("50", "100", "UnlimDist"))
modelresultsWiderFinal$MinValue<-ifelse(modelresultsWiderFinal$Pr_F1all4<modelresultsWiderFinal$Pr_F2all4,modelresultsWiderFinal$Pr_F1all4,modelresultsWiderFinal$Pr_F2all4)
modelresultsWiderFinal$MaxValue<-ifelse(modelresultsWiderFinal$Pr_F1all4>modelresultsWiderFinal$Pr_F2all4,modelresultsWiderFinal$Pr_F1all4,modelresultsWiderFinal$Pr_F2all4)
range(modelresultsWiderFinal$MinValue)
modelresultsWiderFinal$Signif<-ifelse(modelresultsWiderFinal$MaxValue<0.10,"Both axes",
                                      ifelse(modelresultsWiderFinal$Pr_F1all4<0.10,"First PCA axis",#"Nonsignificant"))
                                             ifelse(modelresultsWiderFinal$Pr_F2all4<0.10,"Second PCA axis","Nonsignificant")))
modelresultsWiderFinal$Signif<-factor(modelresultsWiderFinal$Signif, levels = c("Both axes", "First PCA axis", "Second PCA axis", "Nonsignificant"))

library(ggrepel)
p1<-ggplot(data=modelresultsWiderFinal, aes(x=F1all4, y=F2all4, group=PCradius)) +
  geom_point(aes(shape=PCradius, color=Signif))+
  labs(x="PCA axis 1 effect size", y="PCA axis 2 effect size")+
  my.theme+
  geom_text_repel(aes(x = F1all4, 
                      y = F2all4, 
                      label = Species))
ggsave(p1, file="2_outputs/December 2023/SpeciesResponseToForestVegPCA_vsPointCountRadius.png", units="in", width=10, height=8)

