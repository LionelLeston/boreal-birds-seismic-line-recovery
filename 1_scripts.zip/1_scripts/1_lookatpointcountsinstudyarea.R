library(foreign)
library(haven)

pc50 <- read.dta("0_data/0_raw/point counts/stata files/50m_edited11Apr2016.dta")
pc.unl <- read_dta("0_data/0_raw/point counts/stata files/Unlimand50-edited14Jan03.dta")

str(pc50)
write.csv(pc50, file="0_data/0_raw/point counts/50m_edited11Apr2016.csv")

str(pc.unl)
write.csv(pc.unl, file="0_data/0_raw/point counts/Unlimand50-edited14Jan03.csv")

