#The purpose of this script is to get veg data and calculate recovery indices for the point count
#data in Hedwig Lankau's seismic line study of boreal bird communities.

library(foreign)
library(haven)

veg <- read.dta("0_data/0_raw/veg from Hedwig/drive-download-20230814T154759Z-001/VegChapterCollapsebySubplot.dta")
names(veg)

ri <- read.dta("0_data/0_raw/veg from Hedwig/VegetationRecoveryIndexPaper-20230814T161826Z-001/VegetationRecoveryIndexPaper/RecoveryIndexVEG-emb.dta")
names(ri)

fa <- read.dta("0_data/0_raw/veg from Hedwig/VegetationRecoveryIndexPaper-20230814T161826Z-001/VegetationRecoveryIndexPaper/qryThesisAllVegSuplot_use_2014JAN25.dta")
names(fa)

vegBird <- read.dta("0_data/0_raw/veg from Hedwig/drive-download-20230814T154759Z-001/Unlim-edited13Dec30.dta")
names(vegBird)
write.csv(vegBird, file="0_data/1_processed/point counts/vegBirdDataHedwigUsed.csv")
#This file appears to have the PCA scores and RI values needed for bird models.